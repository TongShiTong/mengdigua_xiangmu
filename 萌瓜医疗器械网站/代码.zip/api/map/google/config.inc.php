<?php
#https://developers.google.com/maps/documentation/javascript/tutorial
$map_mid = '39.92184916337801,116.39190673828125';
$map_key = 'ABQIAAAAb1rdrywaPMIzUAxQVZbofxQQB02_2CW8l9FjnHNl84-Up3RsKxTkfA2a09d3O75M9j1xfBcOAvf0_w';
?>