SWFErr(str) {
	//
}