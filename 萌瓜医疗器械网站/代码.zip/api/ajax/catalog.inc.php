<?php
defined('IN_DESTOON') or exit('Access Denied');
isset($MODULE[$mid]) or exit;
include template('catalog', 'chip');
?>