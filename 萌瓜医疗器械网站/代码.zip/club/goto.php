<?php
$moduleid = 18;
require '../common.inc.php';
require DT_ROOT.'/module/'.$module.'/goto.inc.php';
?>