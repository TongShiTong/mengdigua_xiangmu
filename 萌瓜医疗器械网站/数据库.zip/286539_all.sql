﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `destoon_404`;
CREATE TABLE `destoon_404` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL DEFAULT '',
  `refer` varchar(255) NOT NULL,
  `robot` varchar(20) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='404日志';

DROP TABLE IF EXISTS  `destoon_ad`;
CREATE TABLE `destoon_ad` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` float NOT NULL DEFAULT '0',
  `currency` varchar(20) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `stat` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `note` text NOT NULL,
  `code` text NOT NULL,
  `text_name` varchar(100) NOT NULL DEFAULT '',
  `text_url` varchar(255) NOT NULL DEFAULT '',
  `text_title` varchar(100) NOT NULL DEFAULT '',
  `text_style` varchar(50) NOT NULL DEFAULT '',
  `image_src` varchar(255) NOT NULL DEFAULT '',
  `image_url` varchar(255) NOT NULL DEFAULT '',
  `image_alt` varchar(100) NOT NULL DEFAULT '',
  `flash_src` varchar(255) NOT NULL DEFAULT '',
  `flash_url` varchar(255) NOT NULL DEFAULT '',
  `flash_loop` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `key_moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `key_catid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `key_word` varchar(100) NOT NULL DEFAULT '',
  `key_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='广告';

insert into `destoon_ad`(`aid`,`title`,`pid`,`typeid`,`areaid`,`amount`,`currency`,`url`,`introduce`,`hits`,`username`,`addtime`,`editor`,`edittime`,`fromtime`,`totime`,`stat`,`note`,`code`,`text_name`,`text_url`,`text_title`,`text_style`,`image_src`,`image_url`,`image_alt`,`flash_src`,`flash_url`,`flash_loop`,`key_moduleid`,`key_catid`,`key_word`,`key_id`,`listorder`,`status`) values
('1','网站首页图片轮播1','14','5','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/player_1.jpg','http://www.destoon.com/','','','','1','0','0','','0','0','3'),
('2','网站首页图片轮播2','14','5','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/player_2.jpg','http://www.destoon.com/','','','','1','0','0','','0','0','3'),
('3','首页旗帜A1','21','3','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/a1.jpg','','','','','1','0','0','','0','0','3'),
('4','首页旗帜A2','22','3','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/a2.jpg','','','','','1','0','0','','0','0','3'),
('5','首页旗帜A3','23','3','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/a3.jpg','','','','','1','0','0','','0','0','3'),
('6','首页旗帜A4','24','3','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/a4.jpg','','','','','1','0','0','','0','0','3'),
('7','首页旗帜A5','25','3','0','0','','http://www.destoon.com/','','0','admin','1569851008','admin','1569851008','1262275200','1577894399','0','','','','','','','file/image/a5.jpg','','','','','1','0','0','','0','0','3');
DROP TABLE IF EXISTS  `destoon_ad_place`;
CREATE TABLE `destoon_ad_place` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `typeid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `open` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `code` text NOT NULL,
  `width` smallint(5) unsigned NOT NULL DEFAULT '0',
  `height` smallint(5) unsigned NOT NULL DEFAULT '0',
  `price` float unsigned NOT NULL DEFAULT '0',
  `ads` smallint(4) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='广告位';

insert into `destoon_ad_place`(`pid`,`moduleid`,`typeid`,`open`,`name`,`thumb`,`style`,`introduce`,`code`,`width`,`height`,`price`,`ads`,`listorder`,`addtime`,`editor`,`edittime`,`template`) values
('1','5','6','1','供应排名','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('2','6','6','1','求购排名','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('3','16','6','1','商城排名','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('4','4','6','1','公司排名','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('14','0','5','1','首页图片轮播','','','','','660','300','0','2','0','1569851008','admin','1569851008',''),
('15','5','7','1','供应赞助商链接','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('17','4','7','1','公司赞助商链接','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('18','0','7','1','求购赞助商链接','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('19','8','7','1','展会赞助商链接','','','','','0','0','0','0','0','1569851008','admin','1569851008',''),
('21','0','3','1','首页旗帜A1','','','','','116','212','0','1','0','1569851008','admin','1569851008',''),
('22','0','3','1','首页旗帜A2','','','','','116','212','0','1','0','1569851008','admin','1569851008',''),
('23','0','3','1','首页旗帜A3','','','','','116','212','0','1','0','1569851008','admin','1569851008',''),
('24','0','3','1','首页旗帜A4','','','','','116','212','0','1','0','1569851008','admin','1569851008',''),
('25','0','3','1','首页旗帜A5','','','','','116','212','0','1','0','1569851008','admin','1569851008','');
DROP TABLE IF EXISTS  `destoon_address`;
CREATE TABLE `destoon_address` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `truename` varchar(30) NOT NULL DEFAULT '',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL DEFAULT '',
  `postcode` varchar(10) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='收货地址';

DROP TABLE IF EXISTS  `destoon_admin`;
CREATE TABLE `destoon_admin` (
  `adminid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `title` varchar(30) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `moduleid` smallint(6) NOT NULL DEFAULT '0',
  `file` varchar(20) NOT NULL DEFAULT '',
  `action` varchar(255) NOT NULL DEFAULT '',
  `catid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='管理员';

insert into `destoon_admin`(`adminid`,`userid`,`listorder`,`title`,`url`,`style`,`moduleid`,`file`,`action`,`catid`) values
('1','1','0','生成首页','?action=html','','0','','',''),
('2','1','0','更新缓存','?action=cache','','0','','',''),
('3','1','0','网站设置','?file=setting','','0','','',''),
('4','1','0','模块管理','?file=module','','0','','',''),
('5','1','0','数据维护','?file=database','','0','','',''),
('6','1','0','模板管理','?file=template','','0','','',''),
('7','1','0','会员管理','?moduleid=2','','0','','',''),
('8','1','0','单页管理','?moduleid=3&file=webpage','','0','','',''),
('9','1','0','排名推广','?moduleid=3&file=spread','','0','','',''),
('10','1','0','广告管理','?moduleid=3&file=ad','','0','','','');
DROP TABLE IF EXISTS  `destoon_admin_log`;
CREATE TABLE `destoon_admin_log` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qstring` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `logtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COMMENT='管理日志';

insert into `destoon_admin_log`(`logid`,`qstring`,`username`,`ip`,`logtime`) values
('139','file=module&action=edit&modid=22','admin','171.214.236.112','1591311491'),
('138','file=module&action=edit&modid=6','admin','171.214.236.112','1591311472'),
('137','rand=46&moduleid=1&file=setting&tab=1','admin','171.214.236.112','1591311362'),
('136','moduleid=1&file=setting&action=html&tab=1','admin','171.214.236.112','1591311362'),
('135','rand=17&moduleid=1&file=setting&tab=0','admin','171.214.236.112','1591311353'),
('134','moduleid=1&file=setting&action=html&tab=0','admin','171.214.236.112','1591311353'),
('133','file=setting','admin','171.214.236.112','1591310996'),
('132','rand=22&moduleid=1&file=setting&tab=0','admin','171.214.236.112','1591309621'),
('131','moduleid=1&file=setting&action=html&tab=0','admin','171.214.236.112','1591309621'),
('130','file=setting','admin','171.214.236.112','1591309602'),
('140','file=setting','admin','223.198.226.112','1592062273'),
('141','moduleid=1&file=setting&action=html&tab=0','admin','223.198.226.112','1592062289'),
('142','rand=53&moduleid=1&file=setting&tab=0','admin','223.198.226.112','1592062289'),
('143','moduleid=1&file=setting&action=html&tab=1','admin','223.198.226.112','1592062298'),
('144','rand=89&moduleid=1&file=setting&tab=1','admin','223.198.226.112','1592062298'),
('145','moduleid=6&action=add','admin','223.198.226.112','1592062540'),
('146','rand=37&moduleid=6&action=add','admin','223.198.226.112','1592062662'),
('147','moduleid=6&file=index&action=edit&itemid=13','admin','223.198.226.112','1592062732'),
('148','moduleid=6&action=add','admin','223.198.226.112','1592062773'),
('149','rand=54&moduleid=6&action=add','admin','223.198.226.112','1592062823'),
('150','rand=32&moduleid=6&action=add','admin','223.198.226.112','1592062903'),
('151','rand=28&moduleid=6&action=add','admin','223.198.226.112','1592062979'),
('152','moduleid=2&action=edit&userid=2','admin','223.198.224.17','1592198285'),
('153','file=module&action=edit&modid=4','admin','223.198.224.17','1592198535'),
('154','moduleid=6&file=index&action=move','admin','171.214.237.159','1592451254'),
('155','moduleid=6&file=index&action=delete','admin','171.214.237.159','1592451272'),
('156','moduleid=6&file=index&action=delete&recycle=1','admin','171.214.237.159','1592456446');
DROP TABLE IF EXISTS  `destoon_admin_online`;
CREATE TABLE `destoon_admin_online` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `moduleid` int(10) unsigned NOT NULL DEFAULT '0',
  `qstring` varchar(255) NOT NULL DEFAULT '',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `sid` (`sid`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='在线管理员';

insert into `destoon_admin_online`(`sid`,`username`,`ip`,`moduleid`,`qstring`,`lasttime`) values
('98976924b844358aa4bc24f8f9e939b3','admin','122.234.13.59','1','file=logout','1592551571'),
('7de8c12ee4420cf29d5a1cab7eb7088d','admin','122.234.13.59','1','file=logout','1592551478');
DROP TABLE IF EXISTS  `destoon_alert`;
CREATE TABLE `destoon_alert` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `word` varchar(100) NOT NULL DEFAULT '',
  `rate` smallint(4) unsigned NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `sendtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='贸易提醒';

DROP TABLE IF EXISTS  `destoon_announce`;
CREATE TABLE `destoon_announce` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公告';

DROP TABLE IF EXISTS  `destoon_area`;
CREATE TABLE `destoon_area` (
  `areaid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `areaname` varchar(50) NOT NULL DEFAULT '',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `child` tinyint(1) NOT NULL DEFAULT '0',
  `arrchildid` text NOT NULL,
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`areaid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='地区';

insert into `destoon_area`(`areaid`,`areaname`,`parentid`,`arrparentid`,`child`,`arrchildid`,`listorder`) values
('1','默认地区','0','0','0','1','1'),
('2','湖北','0','0','0','2','2'),
('3','南京','0','0','0','3','3'),
('4','南昌','0','0','0','4','4'),
('5','太原','0','0','0','5','5'),
('6','武汉','0','0','0','6','6'),
('7','湖南','0','0','0','7','7'),
('8','江苏','0','0','0','8','8'),
('9','陕西','0','0','0','9','9'),
('10','广东','0','0','0','10','10');
DROP TABLE IF EXISTS  `destoon_article_21`;
CREATE TABLE `destoon_article_21` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `subtitle` mediumtext NOT NULL,
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `author` varchar(50) NOT NULL DEFAULT '',
  `copyfrom` varchar(30) NOT NULL DEFAULT '',
  `fromurl` varchar(255) NOT NULL DEFAULT '',
  `voteid` varchar(100) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='资讯';

DROP TABLE IF EXISTS  `destoon_article_data_21`;
CREATE TABLE `destoon_article_data_21` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='资讯内容';

DROP TABLE IF EXISTS  `destoon_ask`;
CREATE TABLE `destoon_ask` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `qid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL,
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply` mediumtext NOT NULL,
  `star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='客服中心';

DROP TABLE IF EXISTS  `destoon_banip`;
CREATE TABLE `destoon_banip` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='IP禁止';

DROP TABLE IF EXISTS  `destoon_banword`;
CREATE TABLE `destoon_banword` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `replacefrom` varchar(255) NOT NULL DEFAULT '',
  `replaceto` varchar(255) NOT NULL DEFAULT '',
  `deny` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='词语过滤';

DROP TABLE IF EXISTS  `destoon_brand_13`;
CREATE TABLE `destoon_brand_13` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `homepage` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `fax` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`),
  KEY `edittime` (`edittime`),
  KEY `editdate` (`editdate`,`vip`,`edittime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='品牌';

DROP TABLE IF EXISTS  `destoon_brand_data_13`;
CREATE TABLE `destoon_brand_data_13` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='品牌内容';

DROP TABLE IF EXISTS  `destoon_buy_6`;
CREATE TABLE `destoon_buy_6` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(2) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `n1` varchar(100) NOT NULL,
  `n2` varchar(100) NOT NULL,
  `n3` varchar(100) NOT NULL,
  `v1` varchar(100) NOT NULL,
  `v2` varchar(100) NOT NULL,
  `v3` varchar(100) NOT NULL,
  `amount` varchar(10) NOT NULL DEFAULT '',
  `price` varchar(10) NOT NULL DEFAULT '',
  `pack` varchar(20) NOT NULL DEFAULT '',
  `days` smallint(3) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `thumb1` varchar(255) NOT NULL DEFAULT '',
  `thumb2` varchar(255) NOT NULL DEFAULT '',
  `thumbs` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `editdate` (`editdate`,`vip`,`edittime`),
  KEY `edittime` (`edittime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='求购';

insert into `destoon_buy_6`(`itemid`,`catid`,`typeid`,`areaid`,`level`,`title`,`style`,`fee`,`introduce`,`n1`,`n2`,`n3`,`v1`,`v2`,`v3`,`amount`,`price`,`pack`,`days`,`tag`,`keyword`,`pptword`,`hits`,`comments`,`thumb`,`thumb1`,`thumb2`,`thumbs`,`username`,`groupid`,`company`,`vip`,`validated`,`truename`,`telephone`,`mobile`,`address`,`email`,`qq`,`wx`,`ali`,`skype`,`totime`,`editor`,`edittime`,`editdate`,`addtime`,`adddate`,`ip`,`template`,`status`,`linkurl`,`filepath`,`note`) values
('1','13','0','4','1','医用红外热像仪/医用红外热成像仪','','0','ZR-2010医用红外热像仪【以下简称ZR-2010】是集医学技术、红外影像技术、电子技术和计算机图像处理技术一体的高科技产品。它采用','','','','','','','','','','0','','医用红外热像仪/医用红外热成像仪,求购,求购','','36','0','http://www.mengdigua.com/file/upload/201910/02/003526681.jpg.thumb.jpg','','','','a238128822','7','南昌华康医疗科技有限公司','2','0','张先生','0791-85297776','','江西省南昌市小蓝工业园玉湖路8号','','','','','','0','admin','1569947733','2019-10-02','1591200000','2019-10-02','182.148.91.176','','0','show.php?itemid=1','',''),
('2','13','0','5','1','经颅磁治疗仪刺激仪','','0','小儿专用rTMS经颅磁治疗仪是针对治疗小儿神经损伤和大脑发育迟缓专门研制开发的变频式重复性rTMS磁刺激治疗设备，适合小儿早期干','','','','','','','','','','0','','经颅磁治疗仪刺激仪,求购,求购','','31','0','http://www.mengdigua.com/file/upload/201910/02/003623291.jpg.thumb.jpg','','','','37237712','7','太原市怀诚医疗器械有限公司','2','0','李小姐','0351-3389929','','山西省太原市阳曲县东黄水镇故县村(314省道路南)','','','','','','0','admin','1569947795','2019-10-02','1591200028','2019-10-02','182.148.91.176','','0','show.php?itemid=2','',''),
('3','13','0','9','1','德国赫美斯臭氧治疗仪','','0','臭氧医学发源于十九世纪末叶，那时人们就已经采用简易的臭氧发生设施进行医用臭氧的制备，开展战斗创伤的治疗，好比外科传染，战','','','','','','','','','','0','','德国赫美斯臭氧治疗仪,求购,求购','','32','0','http://www.mengdigua.com/file/upload/201910/02/003704661.jpg.thumb.jpg','','','','93323988932','6','济南涵康医疗器械有限公司','0','0','张先生','13969177723','','山东省济南市历城区华龙路2号科技城大厦501室','','','','','','0','admin','1569947836','2019-10-02','1591200090','2019-10-02','182.148.91.176','','0','show.php?itemid=3','',''),
('4','13','0','9','1','射频穿刺针/射频穿刺套管针','','0','德国进口英诺曼德射频治疗穿刺针（射频套管针）【产品性能结构及组成】 产品中的伞形杆、伞簧片、针管采用GB1220-1992中规定的1G','','','','','','','','','','0','','射频穿刺针/射频穿刺套管针,求购,求购','','34','0','http://www.mengdigua.com/file/upload/201910/02/003740631.jpg.thumb.jpg','','','','93323988932','6','济南涵康医疗器械有限公司','0','0','张先生','13969177723','','山东省济南市历城区华龙路2号科技城大厦501室','','','','','','0','admin','1569947869','2019-10-02','1591200131','2019-10-02','182.148.91.176','','0','show.php?itemid=4','',''),
('5','13','0','4','1','吲哚美辛巴布膏','','0','【产品名称】：吲哚美辛巴布膏【批准文号】：国药准字H20113287【产品剂型】：贴剂【产品规格】：每贴（14cm10cm），含膏体13g：','','','','','','','','','','0','','吲哚美辛巴布膏,求购,求购','','38','0','http://www.mengdigua.com/file/upload/201910/10/111859111.jpg.thumb.jpg','','','','a238128822','7','南昌华康医疗科技有限公司','2','0','张先生','0791-85297776','','江西省南昌市小蓝工业园玉湖路8号','','','','','','0','admin','1570677547','2019-10-10','1591929780','2019-10-10','182.151.233.54','','3','show.php?itemid=5','',''),
('6','13','0','3','1','冷敷凝胶','','0','【产品名称】：冷敷凝胶【批准文号】：鄂十堰械备20180002号【产品剂型】：凝胶剂【产品规格】：20g／瓶、30g／瓶、50g／瓶【用','','','','','','','','','','0','','冷敷凝胶,求购,求购','','38','0','http://www.mengdigua.com/file/upload/201910/10/112017511.jpg.thumb.jpg','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1570677632','2019-10-10','1591929842','2019-10-10','182.151.233.54','','3','show.php?itemid=6','',''),
('7','13','0','2','1','吲哚美辛巴布膏','','0','【产品名称】：吲哚美辛巴布膏【批准文号】：国药准字H20113287【产品剂型】：贴剂【产品规格】：每贴（14cm10cm），含膏体13g：','','','','','','','','','','0','','吲哚美辛巴布膏,求购,求购','','39','0','http://www.mengdigua.com/file/upload/201910/10/112112581.jpg.thumb.jpg','','','','a238128821','7','湖北肽尔生物医疗科技有限公司','2','0','张','13307183061/13307189625/13307197292','','湖北省仙桃市刘口工业园现代中加科技城','','','','','','0','admin','1570677682','2019-10-10','1591929927','2019-10-10','182.151.233.54','','3','show.php?itemid=7','',''),
('9','13','0','3','1','牡蛎碳酸钙颗粒','','0','【生产厂家】福建省泉州罗裳山制药厂【成　　分】本品每袋含钙50毫克。辅料为：蔗糖、柠檬酸、食用色素、食用香精。【用法用量】','','','','','','','','','','0','','牡蛎碳酸钙颗粒,求购,求购','','41','0','http://www.mengdigua.com/file/upload/201910/10/112346861.jpg.thumb.jpg','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1570677832','2019-10-10','1591930059','2019-10-10','182.151.233.54','','3','show.php?itemid=9','',''),
('10','13','0','2','1','宝宝牛黄散','','0','【生产厂家】白云山和记黄埔莱达制药（汕头）有限公司【成　　分】僵蚕(制)、胆南星、地龙(制)、钩藤、沉香、鱼腥草、人工牛黄、','','','','','','','','','','0','','宝宝牛黄散,求购,求购','','73','0','http://www.mengdigua.com/file/upload/201910/10/112424351.jpg.thumb.jpg','','','','a238128821','7','湖北肽尔生物医疗科技有限公司','2','0','张','13307183061/13307189625/13307197292','','湖北省仙桃市刘口工业园现代中加科技城','','','','','','0','admin','1570677870','2019-10-10','1591930127','2019-10-10','182.151.233.54','','3','show.php?itemid=10','',''),
('11','13','0','3','1','胃热清胶囊','','0','【生产厂家】广州白云山中一药业有限公司【成　　分】救必应、大黄、延胡索（醋制）、甘松、青黛、珍珠层粉、甘草。【用法用量】','','','','','','','','','','0','','胃热清胶囊,求购,求购','','75','0','http://www.mengdigua.com/file/upload/201910/10/112523591.jpg.thumb.jpg','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1570678045','2019-10-10','1591930165','2019-10-10','182.151.233.54','','3','show.php?itemid=11','',''),
('12','13','0','3','1','肚痛丸','','0','【生产厂家】广州白云山中一药业有限公司【成　　分】豆蔻（去壳）、干姜、砂仁、荜茇、厚朴（姜制）、罂粟壳、肉桂、枳实（麸炒','','','','','','','','','','0','','肚痛丸,求购,求购','','73','0','http://www.mengdigua.com/file/upload/201910/10/112836831.jpg.thumb.jpg','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1570678121','2019-10-10','1591930375','2019-10-10','182.151.233.54','','3','show.php?itemid=12','',''),
('13','13','0','10','1','黄芪片','','0','产品特点超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保','','','','','','','','','','0','','黄芪片,求购,求购','','7','0','http://www.mengdigua.com/file/upload/202006/13/233906921.gif.thumb.gif','','','','92732832','7','广州市安辅健医疗器械有限公司','2','0','周','020-29830688','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','','','','0','admin','1592062753','2020-06-13','1592062601','2020-06-13','223.198.226.112','','3','show.php?itemid=13','',''),
('14','13','0','0','1','茵山莲颗粒','','0','产品特点超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保','','','','','','','','','','0','','茵山莲颗粒,求购,求购','','6','0','http://www.mengdigua.com/file/upload/202006/13/234012781.gif.thumb.gif','','','','32883232','0','','0','0','','','','','','','','','','0','admin','1592062823','2020-06-13','1592062773','2020-06-13','223.198.226.112','','3','show.php?itemid=14','',''),
('15','13','0','3','1','乳宁片','','0','产品特点超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保','','','','','','','','','','0','','乳宁片,求购,求购','','3','0','','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1592062903','2020-06-13','1592062823','2020-06-13','223.198.226.112','','3','show.php?itemid=15','',''),
('16','13','0','3','1','耳聋通窍丸','','0','【是否中标】：否【是否独家】：否【生产企业】：陕西华西制药股份有限公司【招商区域】：全国【招商条件】：【药品备注】：药品','','','','','','','','','','0','','耳聋通窍丸,求购,求购','','8','0','http://www.mengdigua.com/file/upload/202006/13/234249771.jpg.thumb.jpg','','','','a238128824','7','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','南京市秣周东路12号4号楼10层','','','','','','0','admin','1592062979','2020-06-13','1592062903','2020-06-13','223.198.226.112','','3','show.php?itemid=16','','');
DROP TABLE IF EXISTS  `destoon_buy_data_6`;
CREATE TABLE `destoon_buy_data_6` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='求购内容';

insert into `destoon_buy_data_6`(`itemid`,`content`) values
('1','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 24pt;">ZR-2010医用红外热像仪【以下简称ZR-2010】是集医学技术、红外影像技术、电子技术和计算机图像处理技术一体的高科技产品。它采用世界先进的非致冷焦平面阵列作为探测器，无需致冷，使用方便快捷，图像清晰，温度分辨率高。</span>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 24pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">ZR-2010 专用于记录人体热场的分布，动态地、客观地监控人体由于功能变化而引起的热场分布的变化，通过自带的软件进行分析比较，实现热诊断，热测定，热研究的功能，为临床诊断、治疗、保健、预防提供客观的热场变化信息。适用于对人体热像测温，以辅助诊断腰椎间盘突出症及腰臀腿软组织损伤等组织损伤源性病变。它<span style="margin: 0px; padding: 0px;">能早期发现疾病在出现病灶区之前发生的温度改变，使许多疾病规律得到更全面认识，疾病性质得到更确切诊断，对于肿瘤特别是乳腺肿瘤的早期发现时间比</span>CT等影像技术在形成2mm以上实质病灶后方可辨别的时间可提前6-12个月，是对恶性肿瘤的预防性普查的有效方法。对于恶性肿瘤的早期发现和提前治疗以及延长肿瘤患者生命赢得了宝贵时间。真正实现了预警的作用。</p>'),
('2','&nbsp;<span style="font-family: 宋体; font-size: 10.5pt; color: rgb(102, 100, 100); margin: 0px; padding: 0px;">小儿专用</span><span style="font-family: 宋体; font-size: 10.5pt; color: rgb(102, 100, 100);">rTMS</span><span style="font-family: 宋体; font-size: 10.5pt; color: rgb(102, 100, 100); margin: 0px; padding: 0px;">经颅磁治疗仪是针对治疗小儿神经损伤和大脑发育迟缓专门研制开发的变频式重复性</span><span style="font-family: 宋体; font-size: 10.5pt; color: rgb(102, 100, 100); margin: 0px; padding: 0px;">rTMS</span><span style="font-family: 宋体; font-size: 10.5pt; color: rgb(102, 100, 100); margin: 0px; padding: 0px;">磁刺激治疗设备，适合小儿早期干预和小儿神经损伤、大脑发育迟缓及脑瘫相关症状的治疗。</span>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">产品特点：</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">rTMS<span style="margin: 0px; padding: 0px;">经颅磁治疗仪采用了变频重复性</span><span style="margin: 0px; padding: 0px;">rTMS</span><span style="margin: 0px; padding: 0px;">经颅磁刺激治疗技术，根据低频刺激有抑制神经兴奋，高频磁刺激有促进神经兴奋的特点，主机具备自动变频和频率选择及输出强度调节功能，治疗时根据需要可选择自动变频和定频治疗，以达到更好的治疗效果。专用治疗帽按</span><span style="margin: 0px; padding: 0px;">3-12</span><span style="margin: 0px; padding: 0px;">岁分别制成，治疗帽对大脑多个部位同时刺激。</span></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">治疗效果：</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">1<span style="margin: 0px; padding: 0px;">、修复损伤脑细胞，促进新的神经元发育成长、加快神经网络重建。</span></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">2<span style="margin: 0px; padding: 0px;">、激发神经自身保护机制、加快神经功能修复。</span></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">3<span style="margin: 0px; padding: 0px;">、抑制异常脑电脑磁，改善睡眠质量。</span></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">适应症：</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 0px; color: rgb(102, 100, 100);"><span style="margin: 0px; padding: 0px; font-family: 宋体; font-size: 10.5pt;">改善儿童脑瘫和大脑发育迟缓引起的相关症状。</span></p>'),
('3','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">臭氧医学发源于十九世纪末叶，那时人们就已经采用简易的臭氧发生设施进行医用臭氧的制备，开展战斗创伤的治疗，好比外科传染，战壕足等的光疗，治疗方式主要利用临时制备的臭化合水开展清创，其效用主导是广谱杀菌、抗炎、促成局部组织再生等机理，因为成效良好，从而极大唤起了人们对臭氧医学的兴趣。</span>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">德国赫美斯臭氧治疗仪作为世界医用臭氧联合会与中国医用臭氧联合会品牌，产品遍布欧洲、美洲、亚洲等许多国家和地区。性能稳定可靠，技术在同行业始终保持领先地位。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">德国赫美斯臭氧治疗仪的作用</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">1. 有扩张血管的作用，可降低胆固醇，防止高血压，动脉硬化及心脏有关的并发症。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">2. 可排除沉积在肝肾中的毒素，并保障肝肾功能的正常工作。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">3. 促进新陈代谢，调整内分泌及垂体副肾功能的正常工作，排除更年期障碍。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">4. 舒筋活血，迅速恢复运动、工作所造成的疲劳，对肩颈部酸痛，手脚冰冷等效果显著。</p>'),
('4','&nbsp;<span style="font-size: 14pt; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">德国进口英诺曼德射频治疗穿刺针（射频套管针）</span>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-size: 14pt;">【产品性能结构及组成】 &emsp;&emsp;产品中的伞形杆、伞簧片、针管采用GB1220-1992中规定的1Gr18Ni9Ti不锈钢制成。 主要技术指标： 1、针尖荷重30克顶压后，其穿刺力应不大于24克； 2、伞形杆、伞簧片、针管的表面粗糙度应不大于Ra3.2&mu;m； 3、产品应无菌。</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-size: 14pt;">【产品适用范围】 &emsp;&emsp; 作为射频发生器的配件，供临床单位用于与射频发生器配套使用 北琪射频电极套管针，西洁安科射频电极套管针，射频穿刺针，北琪西洁安科射频针 北琪射频穿刺针、西洁射频穿刺针、安科射频穿刺针</span></p>'),
('5','&nbsp;
<ul class="content" style="margin: 0px; padding: 46px 0px 0px 25px; outline: 0px; list-style: none; width: 550px; line-height: 24px; height: 220px; color: rgb(51, 51, 51); font-family: 微软雅黑; font-size: 12px;">
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品名称】：<strong style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; color: rgb(255, 0, 0); font-size: 16px;"><a href="http://www.3156.cn/product/69414844.shtml" target="_blank" style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; text-decoration-line: none; color: rgb(0, 0, 0);">吲哚美辛巴布膏</a></strong></li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【批准文号】：国药准字H20113287</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品剂型】：贴剂</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品规格】：每贴（14cm&times;10cm），含膏体13g：每克膏体含吲哚美辛3．5mg</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【用法用量】：局部外用，除去塑料衬膜，贴敷于患部关节或疼痛部位，也可根据患部关节或疼痛部位的不同，裁剪成易与患部关节或疼痛部位接合紧密的适宜形状、大小，每日1～2次。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【药品成分】：本品每贴含美辛45．5mg。辅料为乙二醇400、聚山梨酯80、甘油、氮酮、苯氧乙醇、聚丙烯酸（部分中和物）、甘羥铝、薄荷脑、乙醇、二氧化钛、高岭土、诱惑红铝色淀、聚维酮（K－90）、酒石酸、乙二胺四乙酸－四钠及纯化水。主药化学名称：2－甲基－1－（4－氯苯甲酰基）5－甲氧基－1H－吲哚&mdash;3－乙酸。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【生产厂家】：武汉兵兵药业有限公司</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 48px; overflow: hidden;">【主治功能】：用于缓解局部软组织疼痛，如（1）运动创伤（如扭伤、拉伤、肌腱损伤等）引起的局部软组织疼痛。（2）慢性软组织劳损（如颈部、肩背、腰腿等）所致的局</li>
</ul>'),
('6','&nbsp;
<ul class="content" style="margin: 0px; padding: 46px 0px 0px 25px; outline: 0px; list-style: none; width: 550px; line-height: 24px; height: 220px; color: rgb(51, 51, 51); font-family: 微软雅黑; font-size: 12px;">
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品名称】：<strong style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; color: rgb(255, 0, 0); font-size: 16px;"><a href="http://www.3156.cn/product/69414718.shtml" target="_blank" style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; text-decoration-line: none; color: rgb(0, 0, 0);">冷敷凝胶</a></strong></li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【批准文号】：鄂十堰械备20180002号</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品剂型】：凝胶剂</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品规格】：20g／瓶、30g／瓶、50g／瓶</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【用法用量】：使用前请清洁皮肤表面，先打开瓶盖，瓶口朝下，将滚珠走珠瓶置于额头、阳穴、左右颈总动脉、左右股动脉、腋窝、肚脐、脚心、手心、前胸、后背等处皮肤表面来回涂抹，每个部位可反复涂抹2～3次，多个部位同时使用效果更佳。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【药品成分】：本品由滚珠走珠器和凝胶组成，凝胶由卡波姆、甘油、薄荷脑、乙醇、苯氧乙醇、依地酸二钠、氢氧化钠及纯化水等组成。所含成分不具有药理学作用。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【生产厂家】：兵兵药业（湖北）有限公司</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 48px; overflow: hidden;">【主治功能】：用于物理退热、冷敷理疗。仅用于闭合性软组织。</li>
</ul>'),
('7','&nbsp;
<ul class="content" style="margin: 0px; padding: 46px 0px 0px 25px; outline: 0px; list-style: none; width: 550px; line-height: 24px; height: 220px; color: rgb(51, 51, 51); font-family: 微软雅黑; font-size: 12px;">
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品名称】：<strong style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; color: rgb(255, 0, 0); font-size: 16px;"><a href="http://www.3156.cn/product/69414717.shtml" target="_blank" style="margin: 0px; padding: 0px; outline: 0px; list-style-type: none; text-decoration-line: none; color: rgb(0, 0, 0);">吲哚美辛巴布膏</a></strong></li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【批准文号】：国药准字H20113287</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品剂型】：贴剂</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【产品规格】：每贴（14cm&times;10cm），含膏体13g：每克膏体含吲哚美辛3．5mg</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【用法用量】：局部外用，除去塑料衬膜，贴敷于患部关节或疼痛部位，也可根据患部关节或疼痛部位的不同，裁剪成易与患部关节或疼痛部位接合紧密的适宜形状、大小，每日1～2次。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【药品成分】：本品每贴含美辛45．5mg。辅料为乙二醇400、聚山梨酯80、甘油、氮酮、苯氧乙醇、聚丙烯酸（部分中和物）、甘羥铝、薄荷脑、乙醇、二氧化钛、高岭土、诱惑红铝色淀、聚维酮（K－90）、酒石酸、乙二胺四乙酸－四钠及纯化水。主药化学名称：2－甲基－1－（4－氯苯甲酰基）5－甲氧基－1H－吲哚&mdash;3－乙酸。</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 24px; overflow: hidden;">【生产厂家】：武汉兵兵药业有限公司</li>
    <li style="margin: 0px; padding: 0px; outline: 0px; list-style: none; font-size: 14px; height: 48px; overflow: hidden;">【主治功能】：用于缓解局部软组织疼痛，如（1）运动创伤（如扭伤、拉伤、肌腱损伤等）引起的局部软组织疼痛。（2）慢性软组织劳损（如颈部、肩背、腰腿等）</li>
</ul>'),
('9','&nbsp;<span style="text-align: center; color: rgb(51, 51, 51); font-family: 宋体;">【生产厂家】</span>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);">
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">福建省泉州罗裳山制药厂</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【成　　分】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">本品每袋含钙50毫克。辅料为：蔗糖、柠檬酸、食用色素、食用香精。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【用法用量】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">口服。一次1～2袋，一日3次，用温开水冲服。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【产品用途】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">用于预防和治疗钙缺乏症，如骨质疏松、手足抽搐症、骨发育不完全、拘偻病以及儿童、妊娠和哺乳期妇女、绝经期妇女、老年人钙的补充。</p>
</div>'),
('10','&nbsp;<span style="text-align: center; color: rgb(51, 51, 51); font-family: 宋体;">【生产厂家】</span>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);">
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">白云山和记黄埔莱达制药（汕头）有限公司</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【成　　分】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">僵蚕(制)、胆南星、地龙(制)、钩藤、沉香、鱼腥草、人工牛黄、冰片、珍珠。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【用法用量】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">口服，一次半岁 1/4瓶；半岁以上 1/2瓶；三岁以上 1瓶，一日3 次。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【产品用途】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">清热镇惊，祛风，化痰。用于小儿风痰壅盛，腹痛。</p>
</div>'),
('11','&nbsp;<span style="text-align: center; color: rgb(51, 51, 51); font-family: 宋体;">【生产厂家】</span>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);">
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">广州白云山中一药业有限公司</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【成　　分】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">救必应、大黄、延胡索（醋制）、甘松、青黛、珍珠层粉、甘草。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【用法用量】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">口服。一次4粒，一日4次，6周为一疗程。或遵医嘱。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【功能主治】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">清热理气，活血止痛。用于郁热或兼有气滞血瘀所致的胃脘胀痛，有灼热感，痛势急迫，食入痛重，口干而苦，便秘易怒，舌红苔黄等症；胃及十二指肠溃疡见上述证候者。</p>
</div>'),
('12','&nbsp;<span style="text-align: center; color: rgb(51, 51, 51); font-family: 宋体;">【生产厂家】</span>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);">
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">广州白云山中一药业有限公司</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【成　　分】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">豆蔻（去壳）、干姜、砂仁、荜茇、厚朴（姜制）、罂粟壳、肉桂、枳实（麸炒）、木香、乌药。辅料为滑石粉、乙醇、蜂蜜、糊精。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【用法用量】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">口服。一次60粒，一日2次。</p>
</div>
<div style="margin: 0px 0px 10px; padding: 0px; list-style: none; width: 930px; height: auto; overflow: hidden; font-family: 宋体; line-height: 24px; color: rgb(51, 51, 51);"><span style="margin: 0px; padding: 0px; list-style: none; float: left; width: 100px; text-align: center;">【功能主治】</span>
<p style="margin: 0px; padding: 0px; list-style: none; float: left; width: 807px;">温中散寒，理气止痛。用于寒凝气滞所致的腹中冷痛，胸胁胀闷，呕逆吐酸。</p>
</div>'),
('13','<br />
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391139.html#">产品特点</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px">超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保护，严格监控货物流向，积极配合区域代理的销售工作，提供一切的市场信息。</p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="2"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391139.html#">医药招商信息</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否中标】：</span>是</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否独家】：</span>否</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【生产企业】：</span>四川国康药业有限公司</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商区域】：</span>全国</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商条件】：</span>有长期合作的决心；具有较强的责任心和信心；完善的销售网络；具有一定的经济实力和良好的商业信誉；具有丰富的市场操作经验，较强的市场开发能力；具备终端（OTC，RX）推广能力的公司和个人；</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【药品备注】：</span>产品优势： 国家医保，部分省增补基药。全国仅两家</p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="3"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391139.html#">药品使用说明</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【用法用量】：</span>口服。一次4片，一日2次。</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【功能主治】：</span>补气固表，利尿，托毒排脓，生肌。用于气短心悸，虚脱，自汗，体虚浮肿，肿瘤化放疗以及手术后，慢性肾病，久泻，脱肛，子宫脱垂，妇科疾病，痈疽难溃，疮口久不愈合。</p>
</div>'),
('14','<br />
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391138.html#">产品特点</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px">超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保护，严格监控货物流向，积极配合区域代理的销售工作，提供一切的市场信息。</p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="2"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391138.html#">医药招商信息</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否中标】：</span>是</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否独家】：</span>是</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【生产企业】：</span>四川国康药业有限公司</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商区域】：</span>全国</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商条件】：</span>有长期合作决心；有较强的责任心和信心；通畅市场渠道；良好的商业网信誉；有丰富的市场操作经验，较强的市场开发能力</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【药品备注】：</span>产品优势： 国家医保，能够治疗胰腺炎的茵山莲颗粒</p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="3"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391138.html#">药品使用说明</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【用法用量】：</span>开水冲服一次3-9g，一日两次，或尊医嘱。</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【功能主治】：</span>清热解毒利湿。用于慢性乙型肝炎、胆囊炎、胰腺炎，而见湿热蕴毒之症者。</p>
</div>'),
('15','<br />
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391140.html#">产品特点</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px">超低折扣的供货价，空间大、易操作、利润丰厚、前景广阔。全国实行统一的招商价格，销售政策持续稳定。提供严格的区域保护，严格监控货物流向，积极配合区域代理的销售工作，提供一切的市场信息。</p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="2"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391140.html#">医药招商信息</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否中标】：</span>是</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否独家】：</span>否</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【生产企业】：</span>四川国康药业有限公司</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商区域】：</span>全国</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商条件】：</span>有长期合作的决心；具有较强的责任心和信心；具有一定的经济实力和良好的商业信誉； 具有丰富的市场操作经验，较强的市场开发能力；具备终端（OTC，RX）推广能力的公司和个人；</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【药品备注】：</span></p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="3"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="https://www.100yiyao.com/product/391140.html#">药品使用说明</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【用法用量】：</span>口服。一次4～6片，一日3～4次，2～3个月为一疗程。</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【功能主治】：</span>温肺祛痰，活血化瘀。用于痰瘀互结，肿胀疼痛及乳腺小叶增生属上述证侯者。</p>
</div>'),
('16','<br />
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否中标】：</span>否</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【是否独家】：</span>否</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【生产企业】：</span>陕西华西制药股份有限公司</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商区域】：</span>全国</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【招商条件】：</span></p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【药品备注】：</span></p>
</div>
<ul class="kmenu2" style="border-left-width: 0px; list-style-type: none; font-size: 13px; overflow: auto; font-family: Arial, Helvetica, sans-serif; border-right-width: 0px; border-top-color: ; width: 693px; white-space: normal; word-spacing: 0px; border-bottom: rgb(235,235,235) 1px solid; text-transform: none; border-left-color: ; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 0px; padding-left: 0px; orphans: 2; widows: 2; margin: 20px 0px 0px; border-right-color: ; letter-spacing: normal; padding-right: 0px; border-top-width: 0px; background-color: rgb(255,255,255); text-indent: 0px; border-image: initial; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial"><a style="text-decoration: none; color: rgb(51,51,51); padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px" name="3"></a>
    <li style="list-style-type: none; border-top: rgb(235,235,235) 1px solid; border-right: rgb(235,235,235) 1px solid; border-bottom: medium none; float: left; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: rgb(235,235,235) 1px solid; margin: 0px; line-height: 30px; padding-right: 0px; border-image: initial"><a class="on" style="font-size: 14px; text-decoration: none; background: rgb(247,247,247); font-weight: bold; color: rgb(0,153,0); padding-bottom: 0px; padding-top: 0px; padding-left: 25px; margin: 0px; display: block; line-height: 33px; padding-right: 25px" href="http://www.100yiyao.com/product/368501.html#">药品使用说明</a></li>
</ul>
<div class="conpt20" style="list-style-type: none; font-size: 14px; overflow: auto; border-top: 0px; font-family: Arial, Helvetica, sans-serif; border-right: 0px; white-space: normal; word-spacing: 0px; border-bottom: 0px; text-transform: none; font-weight: 400; color: rgb(68,68,68); padding-bottom: 0px; font-style: normal; padding-top: 20px; padding-left: 0px; border-left: 0px; orphans: 2; widows: 2; margin: 0px; letter-spacing: normal; line-height: 30px; padding-right: 0px; background-color: rgb(255,255,255); text-indent: 0px; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial">
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【用法用量】：</span>口服。一次5克，一日1次。</p>
<p class="pp1 f14" style="list-style-type: none; font-size: 14px; border-top: 0px; border-right: 0px; border-bottom: 0px; padding-bottom: 0px; padding-top: 0px; padding-left: 0px; border-left: 0px; margin: 0px; line-height: 30px; padding-right: 0px"><span style="padding-bottom: 0px; padding-top: 0px; padding-left: 0px; margin: 0px; padding-right: 0px">【功能主治】：</span>清热泻火，利湿通便。用于肝胆火盛，头眩目胀，耳聋耳鸣，耳内流脓，大便干燥，小便赤黄。</p>
</div>');
DROP TABLE IF EXISTS  `destoon_cache`;
CREATE TABLE `destoon_cache` (
  `cacheid` varchar(32) NOT NULL DEFAULT '',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `cacheid` (`cacheid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件缓存';

DROP TABLE IF EXISTS  `destoon_cart`;
CREATE TABLE `destoon_cart` (
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='购物车';

DROP TABLE IF EXISTS  `destoon_category`;
CREATE TABLE `destoon_category` (
  `catid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `catname` varchar(50) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `catdir` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `letter` varchar(4) NOT NULL DEFAULT '',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `item` bigint(20) unsigned NOT NULL DEFAULT '0',
  `property` smallint(6) unsigned NOT NULL DEFAULT '0',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `child` tinyint(1) NOT NULL DEFAULT '0',
  `arrchildid` text NOT NULL,
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `template` varchar(30) NOT NULL DEFAULT '',
  `show_template` varchar(30) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  `group_list` varchar(255) NOT NULL DEFAULT '',
  `group_show` varchar(255) NOT NULL DEFAULT '',
  `group_add` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='栏目分类';

insert into `destoon_category`(`catid`,`moduleid`,`catname`,`style`,`catdir`,`linkurl`,`letter`,`level`,`item`,`property`,`parentid`,`arrparentid`,`child`,`arrchildid`,`listorder`,`template`,`show_template`,`seo_title`,`seo_keywords`,`seo_description`,`group_list`,`group_show`,`group_add`) values
('10','8','展会','','10','list.php?catid=10','','1','5','0','0','0','0','10','10','','','','','','','',''),
('2','6','求购默认分类','','1','list.php?catid=2','','1','0','0','0','0','0','2','1','','','','','','','',''),
('3','4','公司默认分类','','1','list.php?catid=3','','1','0','0','0','0','0','3','1','','','','','','','',''),
('4','22','医用耗材','','4','list.php?catid=4','','1','4','0','0','0','0','4','4','','','','','','','',''),
('5','22','医疗设备','','5','list.php?catid=5','','1','4','0','0','0','0','5','5','','','','','','','',''),
('6','22','医疗器械','','6','list.php?catid=6','','1','4','0','0','0','0','6','6','','','','','','','',''),
('7','22','家用器械','','7','list.php?catid=7','','1','3','0','0','0','0','7','7','','','','','','','',''),
('8','22','诊断试剂','','8','list.php?catid=8','','1','1','0','0','0','0','8','8','','','','','','','',''),
('9','22','膏药凝胶','','9','list.php?catid=9','','1','0','0','0','0','0','9','9','','','','','','','',''),
('11','4','医疗器械','','11','11-c11-1.html','','1','9','0','0','0','0','11','11','','','','','','','',''),
('13','6','求购','','13','list.php?catid=13','','1','11','0','0','0','0','13','13','','','','','','','',''),
('14','7','行情','','14','list.php?catid=14','','1','4','0','0','0','0','14','14','','','','','','','','');
DROP TABLE IF EXISTS  `destoon_category_option`;
CREATE TABLE `destoon_category_option` (
  `oid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `search` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `extend` text NOT NULL,
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`oid`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分类属性';

DROP TABLE IF EXISTS  `destoon_category_value`;
CREATE TABLE `destoon_category_value` (
  `oid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `moduleid` smallint(6) NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `value` text NOT NULL,
  KEY `moduleid` (`moduleid`,`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分类属性值';

DROP TABLE IF EXISTS  `destoon_chat`;
CREATE TABLE `destoon_chat` (
  `chatid` varchar(32) NOT NULL,
  `fromuser` varchar(30) NOT NULL,
  `fgettime` int(10) unsigned NOT NULL DEFAULT '0',
  `freadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fnew` int(10) unsigned NOT NULL DEFAULT '0',
  `touser` varchar(30) NOT NULL,
  `tgettime` int(10) unsigned NOT NULL DEFAULT '0',
  `treadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `tnew` int(10) unsigned NOT NULL DEFAULT '0',
  `lastmsg` varchar(255) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `forward` varchar(255) NOT NULL,
  UNIQUE KEY `chatid` (`chatid`),
  KEY `fromuser` (`fromuser`),
  KEY `touser` (`touser`),
  KEY `lasttime` (`lasttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='在线聊天';

DROP TABLE IF EXISTS  `destoon_chat_data_0`;
CREATE TABLE `destoon_chat_data_0` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_0';

DROP TABLE IF EXISTS  `destoon_chat_data_1`;
CREATE TABLE `destoon_chat_data_1` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_1';

DROP TABLE IF EXISTS  `destoon_chat_data_2`;
CREATE TABLE `destoon_chat_data_2` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_2';

DROP TABLE IF EXISTS  `destoon_chat_data_3`;
CREATE TABLE `destoon_chat_data_3` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_3';

DROP TABLE IF EXISTS  `destoon_chat_data_4`;
CREATE TABLE `destoon_chat_data_4` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_4';

DROP TABLE IF EXISTS  `destoon_chat_data_5`;
CREATE TABLE `destoon_chat_data_5` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_5';

DROP TABLE IF EXISTS  `destoon_chat_data_6`;
CREATE TABLE `destoon_chat_data_6` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_6';

DROP TABLE IF EXISTS  `destoon_chat_data_7`;
CREATE TABLE `destoon_chat_data_7` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_7';

DROP TABLE IF EXISTS  `destoon_chat_data_8`;
CREATE TABLE `destoon_chat_data_8` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_8';

DROP TABLE IF EXISTS  `destoon_chat_data_9`;
CREATE TABLE `destoon_chat_data_9` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` varchar(32) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `chatid` (`chatid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='聊天记录_9';

DROP TABLE IF EXISTS  `destoon_city`;
CREATE TABLE `destoon_city` (
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `iparea` mediumtext NOT NULL,
  `domain` varchar(255) NOT NULL DEFAULT '',
  `letter` varchar(4) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `template` varchar(50) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `areaid` (`areaid`),
  KEY `domain` (`domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='城市分站';

DROP TABLE IF EXISTS  `destoon_club_18`;
CREATE TABLE `destoon_club_18` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `video` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ontop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `reply` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `replyuser` varchar(30) NOT NULL,
  `replyer` varchar(30) NOT NULL,
  `replytime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈帖子';

DROP TABLE IF EXISTS  `destoon_club_data_18`;
CREATE TABLE `destoon_club_data_18` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈帖子内容';

DROP TABLE IF EXISTS  `destoon_club_fans_18`;
CREATE TABLE `destoon_club_fans_18` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `reason` mediumtext NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `gid` (`gid`),
  KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈粉丝';

DROP TABLE IF EXISTS  `destoon_club_group_18`;
CREATE TABLE `destoon_club_group_18` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `style` varchar(50) NOT NULL DEFAULT '',
  `post` int(10) unsigned NOT NULL DEFAULT '0',
  `fans` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL,
  `manager` varchar(255) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `template` varchar(30) NOT NULL,
  `show_template` varchar(30) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `join_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `list_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `show_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `post_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reply_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reason` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈圈子';

DROP TABLE IF EXISTS  `destoon_club_manage_18`;
CREATE TABLE `destoon_club_manage_18` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `reason` mediumtext NOT NULL,
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈管理';

DROP TABLE IF EXISTS  `destoon_club_reply_18`;
CREATE TABLE `destoon_club_reply_18` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `gid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `tid` (`tid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商圈回复';

DROP TABLE IF EXISTS  `destoon_comment`;
CREATE TABLE `destoon_comment` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_mid` smallint(6) NOT NULL DEFAULT '0',
  `item_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_username` varchar(30) NOT NULL DEFAULT '',
  `star` tinyint(1) NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `qid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `quotation` mediumtext NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `reply` mediumtext NOT NULL,
  `editor` varchar(30) NOT NULL DEFAULT '',
  `replyer` varchar(30) NOT NULL DEFAULT '',
  `replytime` int(10) unsigned NOT NULL DEFAULT '0',
  `agree` int(10) unsigned NOT NULL DEFAULT '0',
  `against` int(10) unsigned NOT NULL DEFAULT '0',
  `quote` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `item_mid` (`item_mid`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论';

DROP TABLE IF EXISTS  `destoon_comment_ban`;
CREATE TABLE `destoon_comment_ban` (
  `bid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` smallint(6) NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论禁止';

DROP TABLE IF EXISTS  `destoon_comment_stat`;
CREATE TABLE `destoon_comment_stat` (
  `sid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` smallint(6) NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment` int(10) unsigned NOT NULL DEFAULT '0',
  `star1` int(10) unsigned NOT NULL DEFAULT '0',
  `star2` int(10) unsigned NOT NULL DEFAULT '0',
  `star3` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论统计';

DROP TABLE IF EXISTS  `destoon_company`;
CREATE TABLE `destoon_company` (
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `validator` varchar(100) NOT NULL DEFAULT '',
  `validtime` int(10) unsigned NOT NULL DEFAULT '0',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `vipt` smallint(2) unsigned NOT NULL DEFAULT '0',
  `vipr` smallint(2) NOT NULL DEFAULT '0',
  `type` varchar(100) NOT NULL DEFAULT '',
  `catid` varchar(100) NOT NULL DEFAULT '',
  `catids` varchar(100) NOT NULL DEFAULT '',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `mode` varchar(100) NOT NULL DEFAULT '',
  `capital` float unsigned NOT NULL DEFAULT '0',
  `regunit` varchar(15) NOT NULL DEFAULT '',
  `size` varchar(100) NOT NULL DEFAULT '',
  `regyear` varchar(4) NOT NULL DEFAULT '',
  `regcity` varchar(30) NOT NULL DEFAULT '',
  `sell` varchar(255) NOT NULL DEFAULT '',
  `buy` varchar(255) NOT NULL DEFAULT '',
  `business` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `fax` varchar(50) NOT NULL DEFAULT '',
  `mail` varchar(50) NOT NULL DEFAULT '',
  `gzh` varchar(50) NOT NULL DEFAULT '',
  `gzhqr` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `postcode` varchar(20) NOT NULL DEFAULT '',
  `homepage` varchar(255) NOT NULL DEFAULT '',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `styletime` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '',
  `skin` varchar(30) NOT NULL DEFAULT '',
  `domain` varchar(100) NOT NULL DEFAULT '',
  `icp` varchar(100) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  KEY `domain` (`domain`),
  KEY `vip` (`vip`),
  KEY `areaid` (`areaid`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司';

insert into `destoon_company`(`userid`,`username`,`groupid`,`company`,`level`,`validated`,`validator`,`validtime`,`vip`,`vipt`,`vipr`,`type`,`catid`,`catids`,`areaid`,`mode`,`capital`,`regunit`,`size`,`regyear`,`regcity`,`sell`,`buy`,`business`,`telephone`,`fax`,`mail`,`gzh`,`gzhqr`,`address`,`postcode`,`homepage`,`fromtime`,`totime`,`styletime`,`thumb`,`introduce`,`hits`,`comments`,`keyword`,`template`,`skin`,`domain`,`icp`,`linkurl`) values
('1','admin','1','DESTOON B2B网站管理系统','0','0','','0','0','0','0','企业单位','','','1','','0','人民币','','','','','','','','','','','','','','','0','0','0','','','0','0','DESTOON B2B网站管理系统默认地区','','','','','http://www.mengdigua.com/index.php?homepage=admin'),
('2','a238128821','7','湖北肽尔生物医疗科技有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','2','','0','人民币','','2016','','','','医疗器械生产、销售；生物技术研发、转让；保健食品、日用品、化妆品及消毒用品的销售。（涉及许可经营项目，应取得相关部门许可后方可经营）','13307183061/13307189625/13307197292','','','','','湖北省仙桃市刘口工业园现代中加科技城','','','1569859200','1601481599','0','','','531','0','湖北肽尔生物医疗科技有限公司湖北医疗器械生产、销售；生物技术研发、转让；保健食品、日用品、化妆品及消毒用品的销售。（涉及许可经营项目，应取得相关部门许可后方可经营）','','','','','http://www.mengdigua.com/index.php?homepage=a238128821'),
('3','a238128824','7','南京瑞普森生物科技有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','3','','0','人民币','','2014','','','','技术推广服务：销售医疗器材、计算机、软件及辅助设备、机械设备、电子产品','025-52137655','','','','','南京市秣周东路12号4号楼10层','','','1569859200','1601481599','0','','','503','0','南京瑞普森生物科技有限公司南京技术推广服务：销售医疗器材、计算机、软件及辅助设备、机械设备、电子产品','','','','','http://www.mengdigua.com/index.php?homepage=a238128824'),
('4','a238128822','7','南昌华康医疗科技有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','4','','0','人民币','','2015','','','','医疗器械的生产、销售（在许可证核定的范围内经营，许可证的有效期限至2019年1月19日止）；健身器械、日用百货生产、销售；计生用品（药品除外）的销售（以上项目依法需经批准的项目，需经相关部门批准后方可开展经营活动）**','0791-85297776','','','','','江西省南昌市小蓝工业园玉湖路8号','','','1569859200','1601481599','0','','','530','0','南昌华康医疗科技有限公司南昌医疗器械的生产、销售（在许可证核定的范围内经营，许可证的有效期限至2019年1月19日止）；健身器械、日用百货生产、销售；计生用品（药品除外）的销售（以上项目依法需经批准的项目，需经相关部门批准后方可开展经营活动）**','','','','','http://www.mengdigua.com/index.php?homepage=a238128822'),
('5','9282733','7','北京格润来福医药科技有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','6','','0','人民币','','2016','','','','润赛恩生物敷料，润赛恩生物敷料是美国Oculus创新科技公司运用高科技和专利技术研制的创伤护理液','010-57129657','','','','','北京市海淀区上地十街辉煌国际广场','','','1569859200','1601481599','0','','','524','0','北京格润来福医药科技有限公司武汉润赛恩生物敷料，润赛恩生物敷料是美国Oculus创新科技公司运用高科技和专利技术研制的创伤护理液','','','','','http://www.mengdigua.com/index.php?homepage=9282733'),
('6','37237712','7','太原市怀诚医疗器械有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','5','','0','人民币','','2014','','','','一类医疗器械的销售；冷疗贴、泥疗液体覆膜、穴位敷料固定贴的生产及销售；二类6826物理治疗及康复设备（远红外穴位敷贴、烫熨贴、定向透药治疗仪）的生产及销售；二类6827中医器具（自热型泥疗敷料、滚针、定向透药治疗仪专用电极、鼻用脱敏凝胶）的生产及销售。（依法须经批准的项目，经相关部门批准后方可开展经营活动）','0351-3389929','','','','','山西省太原市阳曲县东黄水镇故县村(314省道路南)','','','1569859200','1601481599','0','','','514','0','太原市怀诚医疗器械有限公司太原一类医疗器械的销售；冷疗贴、泥疗液体覆膜、穴位敷料固定贴的生产及销售；二类6826物理治疗及康复设备（远红外穴位敷贴、烫熨贴、定向透药治疗仪）的生产及销售；二类6827中医器具（自热型泥疗敷料、滚针、定向透药治疗仪专用电极、鼻用脱敏凝胶）的生产及销售。（依法须经批准的项目，经相关部门批准后方可开展经营活动）','','','','','http://www.mengdigua.com/index.php?homepage=37237712'),
('7','82378238','7','武汉安士泰医疗科技有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','6','','0','人民币','','2017','','','','医疗器械及配套耗材','027-87780958','','','','','武汉市东湖开发区关东工业园七号地块','','','1569859200','1601481599','0','','','507','0','武汉安士泰医疗科技有限公司武汉医疗器械及配套耗材','','','','','http://www.mengdigua.com/index.php?homepage=82378238'),
('8','91872822412','7','江苏海智生物医药有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','8','','0','人民币','','2014','','','','生物医药研发；医疗器械研发及科研成果转让；医疗科技咨询；市场营销；消毒产品、医疗器械、化工产品、洗化用品生产与销售；食品、化妆品、玻璃仪器、计量仪器的销售。（依法须经批准的项目，经相关部门批准后方可开展经营活动）','025-68750823','','','','','南京市高新开发区星火路10号，鼎业百泰生物大楼C座3楼','','','1569859200','1601481599','0','','','38','0','江苏海智生物医药有限公司江苏生物医药研发；医疗器械研发及科研成果转让；医疗科技咨询；市场营销；消毒产品、医疗器械、化工产品、洗化用品生产与销售；食品、化妆品、玻璃仪器、计量仪器的销售。（依法须经批准的项目，经相关部门批准后方可开展经营活动）','','','','','http://www.mengdigua.com/index.php?homepage=91872822412'),
('9','92732832','7','广州市安辅健医疗器械有限公司','1','0','','1569859200','2','2','0','企业单位',',11,',',11,','10','','0','人民币','','2016','','','','公司主营一次性使用精密过滤输液器（全国专利保护结构，自动三排气、双重止液防回血保护），其他一、二、三类医疗器械。','020-29830688','','','','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','1569859200','1601481599','0','','','37','0','广州市安辅健医疗器械有限公司广东公司主营一次性使用精密过滤输液器（全国专利保护结构，自动三排气、双重止液防回血保护），其他一、二、三类医疗器械。','','','','','http://www.mengdigua.com/index.php?homepage=92732832'),
('10','93323988932','6','济南涵康医疗器械有限公司','0','0','','0','0','0','0','企业单位',',11,',',11,','9','','0','人民币','','2016','','','','一类医疗器械的生产与销售；II、III类：6854手术室、急救室、诊疗室设备及器具、6865医用缝合材料及粘合剂、6866医用高分子材料及制品（一次性使用无菌医疗器械除外），II类：6840临床检验分析仪器（体外诊断试剂除外）、6841医用化验和基础设备器具、6864医用卫生材料及敷料、化妆品、工艺品、日用品、家具、仪器仪表、洗涤','13969177723','','','','','山东省济南市历城区华龙路2号科技城大厦501室','','','0','0','0','','','38','0','济南涵康医疗器械有限公司陕西一类医疗器械的生产与销售；II、III类：6854手术室、急救室、诊疗室设备及器具、6865医用缝合材料及粘合剂、6866医用高分子材料及制品（一次性使用无菌医疗器械除外），II类：6840临床检验分析仪器（体外诊断试剂除外）、6841医用化验和基础设备器具、6864医用卫生材料及敷料、化妆品、工艺品、日用品、家具、仪器仪表、洗涤','','','','','http://www.mengdigua.com/index.php?homepage=93323988932');
DROP TABLE IF EXISTS  `destoon_company_data`;
CREATE TABLE `destoon_company_data` (
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司内容';

insert into `destoon_company_data`(`userid`,`content`) values
('1',''),
('2','&nbsp;<span style="color: rgb(68, 68, 68); font-family: &quot;Microsoft Yahei&quot;;">湖北肽尔生物医疗科技有限公司成立于2016年，</span><span style="margin: 0px; padding: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: inherit; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; color: rgb(68, 68, 68); text-indent: 2em;">以创新生物医疗为依托，为生产优质专业的医疗产品为己任，务实创新，将优的产品服务于全社会，实现公司的社会价值。</span>'),
('3','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">南京瑞普森生物科技有限公司是南京高新技术企业，创办于2014年，主要业务涉及&ldquo;绿叶&rdquo;新型医用胶片、医用计算机图文报告胶片、新型打印介质的生产销售及oem加工。拥有先进的生产车间、生产设备和检测设备，具备完善的质量管理体系。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">公司秉承&ldquo;以质量求生存，以诚信求合作，以创新求发展&rdquo;的宗旨，针对用户的需求，不断加大科技投入，依靠技术创新，形成和提高企业的核心竞争力；同时以的人才、先进的技术、优质的产品和服务，赢得合作伙伴和临床医生的信赖，打造极具核心价值的行业知名品牌。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">瑞普森&mdash;&mdash;您值得信赖的合作伙伴！</p>
</ul>'),
('4','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 1.5; font-family: inherit; vertical-align: baseline; text-indent: 2em;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">南昌华康医疗科技有限公司成立于2011年</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">，座落于山清水秀，人杰地灵的赣江之滨&mdash;&mdash;美丽的英雄城南昌，专注于妇科科、普外科、皮肤科、放疗科、肿瘤科、烧伤科、</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">新生儿科等医疗器械产品的研发生产</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">。</span></span></p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">公司是一家集研发、生产、销售医疗器械的专业化高科技股份制企业，公司具备的产品研发团队，不断创新，开发新品； 的生产环境，10万级无菌净化车间，2012年已经通过gmp认证；的经营理念，互惠共赢，合作共赢。</span></p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">公司凭借高科技的优势产品在较高的起点上不断创新，不断研发出更新、更好的高科技、高疗效，质量可靠，更具特色的医疗器械产品。目前，公司主要产品有</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">脐康胎毒清、生物活性脐康宝、壳聚糖妇科栓、壳聚糖妇科凝胶、医用油性擦拭巾、特殊暖宫康复敷料、爱贝乐亲水宝、壳聚糖创面敷料、银克创必清、生物流体敷料、一次性脐带剪夹器、爱贝乐月子宝、远红外愈脐带、体腔器械导入润滑剂、阴道pH缓冲凝胶、医用消毒超声耦合剂、医用射线防护喷剂、</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">隔物灸等</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">。</span></p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">公司始终坚持&ldquo;以产品质量求生存、以产品疗效求效益、以产品创新求发展&rdquo;的宗旨，以科持为先导，以市场为导向。优质的产品，专业化的团队，高效的学术推广，良好的售后服务，以及&ldquo;诚信、创新、和谐、发展&rdquo;的企业文化是南昌华康医疗科技有限公司不竭的动力。让我们满载希望，为人类健康事业而不断努力，做出应有的一份贡献。</span></p>
</ul>'),
('5','&nbsp; &nbsp; &nbsp; &nbsp;<span style="font-family: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit; text-indent: 2em; color: rgb(68, 68, 68);">北京格润来福医药科技有限公司位于北京市中关村软件科技园区，是一家集基础研究、技术开发、市场服务为一体的医药高科技公司，经技术中心潜心研制开发出一系列医用医疗器械用品，把中关村的先进技术和医疗行业相结合，我公司一直相信：科学技术是首要生产力。</span>
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">公司主营：润赛恩生物敷料，润赛恩生物敷料是美国Oculus创新科技公司运用高科技和专利技术研制的创伤护理液。</p>
</ul>'),
('6','&nbsp;<span style="font-family: inherit; font-style: inherit; font-variant-ligatures: inherit; font-variant-caps: inherit; font-weight: inherit; text-indent: 2em; color: rgb(68, 68, 68);">太原市怀诚医疗器械有限公司成立于2012年11月，落座于太原市阳曲小微园区。占地13333平方米，研发中心3816.33平方米，和2个厂房10480.38平方米从事中医器具医疗器械的研发和生产，是国家高新技术企业。</span>
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">目前拥有二类医疗器械生产资质15个，一类生产资质的有5个。定向透药治疗仪、烫熨贴、远红外穴位敷贴、滚针、自热型泥疗敷料、定向透药专用电极、自动灸疗仪、灸具、光量子治疗仪、负压游走罐理疗仪等产品已经取得了国家食品药品监督局的生产注册许可，产品已经能够规模化生产。</p>
</ul>'),
('7','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">武汉安士泰医疗科技有限公司成立于2011年，坐落在国家自主创新示范区&mdash;&mdash;武汉光谷，是一家专业从事超声透药设备及其辅助产品研发与生产的新型医疗器械公司。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">本公司由一批博士、硕士高级技术人员组成的产品开发队伍与多家院校合作。开发生产出国内 以&ldquo;超声透药&rdquo;命名的超声类药物导入医疗产品&mdash;&mdash;多功能超声透药仪。公司将在现有产品基础上不断推出不同病原、不同药物的专业透药设备。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">&ldquo;科技改变生活，创新成就未来&rdquo;将指导我们打造该领域国内，国际的高端专用超声药物导入及辅助产品研发、生产、销售高科技企业。为降低药物副作用、减少药物用量、减轻病人痛苦、作出我们的贡献！</p>
</ul>'),
('8','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">江苏海智生物医药有限公司是一家集研发、生产、销售为一体的现代综合性生物医药企业，2017年11月获省高新技术企业培育库首批入库企业名单公示。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">公司以自主研发为主，研发团队由南京大学、南京医科大学、中国药科大学的来自医学、生物学和药学等不同学科领域的教授、博士和硕士组成。公司以生物医药、医疗器械为经营方向，业务涵盖体外诊断试剂、功能性保健食品、医用卫生护创材料等几大领域。拥有授权的发明专利2项、实用新型专利1项，著作权版要1项，注册商标4项，申请受理发明专利1项。</p>
</ul>'),
('9','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　广州市安辅健医疗器械有限公司，成立于2014年元月，注册资本2008万元人民币。本著&ldquo;、健康、创新、科技、合作&rdquo;的十全原则理念，服务病人，令他们得到佳的治疗，享受美满的人生。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　同时公司自主研发的一次性使用精密过滤输液器（专利号：ZL 201420649779.5）具有全国专利保护结构，与现时市场使用的同类输液器相比，具有明显的竞争优势，现正面向全国火爆招商。</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">&nbsp;</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　我司产品的重大优势：</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　1、全国专利结构的精密输液器，竞争能力出众；</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　2、自动三排气（无盲点全程排空输液管内空气）；</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　3、自动下液；</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　4、自动控制滴斗液面（全程无需挤压滴斗）；</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　5、自动双止液保护（有效地解决目前其他品种可能存在的止液失效问题）；</p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;">　　6、止液后防止血液回流（专利核心技术；形成一定的管内压力，真正做到防止血液回流）。</p>
</ul>'),
('10','&nbsp;
<ul style="margin: 0px; padding: 20px 0px 40px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 28px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: baseline; list-style: none; width: 722px; height: auto; color: rgb(68, 68, 68);">
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">济南涵康医疗器械有限公司是山东省专业的</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">液基细胞检测试剂盒、</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">细胞保存液、</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">医用消毒超声耦合剂等医疗器械产品生产厂家，公司</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; vertical-align: baseline;">成立于2011年，</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; vertical-align: baseline;">是一家研发、生产、销售一体的高技术企业，</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; vertical-align: baseline;">座落于美丽的泉城&mdash;&mdash;济南。</span></span></p>
    <p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 28px; font-family: inherit; vertical-align: baseline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">公司在成立之初就确定了研发为先的发展理念，先后与中国科学院、山东大学、齐鲁医院等等多家机构建立了合作关系，公司现在的主要优势产品有液基细胞检测盒</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">、医用超声耦合剂、一次性使用捆扎止血带、光子冷凝胶、一次性使用备皮包、医用打印胶片、HPV分型检测保存液、</span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 2; font-family: SimSun; vertical-align: baseline;">液基细胞制片染色一体机等产品，</span></p>
</ul>');
DROP TABLE IF EXISTS  `destoon_company_setting`;
CREATE TABLE `destoon_company_setting` (
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `item_key` varchar(100) NOT NULL DEFAULT '',
  `item_value` text NOT NULL,
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司设置';

DROP TABLE IF EXISTS  `destoon_cron`;
CREATE TABLE `destoon_cron` (
  `itemid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `schedule` varchar(255) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  `nexttime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `note` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `nexttime` (`nexttime`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COMMENT='计划任务';

insert into `destoon_cron`(`itemid`,`title`,`type`,`name`,`schedule`,`lasttime`,`nexttime`,`status`,`note`) values
('1','更新在线状态','1','online','10','1592551336','1592551936','0',''),
('2','内容分表创建','1','split','0,0','1592551336','1592582400','0',''),
('3','清理过期文件缓存','0','cache','30','1592551336','1592553136','0',''),
('20','清理过期禁止IP','0','banip','0,10','1592551336','1592583000','0',''),
('21','清理系统临时文件','0','temp','0,20','1592551336','1592583600','0',''),
('40','清理3天前未付款充值记录','0','charge','1,0','1592551336','1592586000','0',''),
('41','清理30天前404日志','0','404','1,10','1592551336','1592586600','0',''),
('42','清理30天前登录日志','0','loginlog','1,20','1592551336','1592587200','0',''),
('43','清理30天前管理日志','0','adminlog','1,30','1592551336','1592587800','0',''),
('44','清理30天前站内交谈','0','chat','1,40','1592551336','1592588400','0',''),
('60','清理90天前已读信件','0','message','2,0','0','0','1',''),
('61','清理90天前资金流水','0','money','2,10','0','0','1',''),
('62','清理90天前积分流水','0','credit','2,20','0','0','1',''),
('63','清理90天前短信流水','0','sms','2,30','0','0','1',''),
('64','清理90天前短信记录','0','smssend','2,40','0','0','1',''),
('65','清理90天前邮件记录','0','maillog','2,50','0','0','1','');
DROP TABLE IF EXISTS  `destoon_down_15`;
CREATE TABLE `destoon_down_15` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `tag` varchar(255) NOT NULL DEFAULT '',
  `album` varchar(100) NOT NULL,
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `download` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `filesize` float NOT NULL DEFAULT '0',
  `unit` varchar(10) NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `album` (`album`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='下载';

DROP TABLE IF EXISTS  `destoon_down_data_15`;
CREATE TABLE `destoon_down_data_15` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='下载内容';

DROP TABLE IF EXISTS  `destoon_exhibit_8`;
CREATE TABLE `destoon_exhibit_8` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `orders` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `city` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `postcode` varchar(20) NOT NULL DEFAULT '',
  `homepage` varchar(255) NOT NULL DEFAULT '',
  `hallname` varchar(100) NOT NULL DEFAULT '',
  `sponsor` varchar(100) NOT NULL DEFAULT '',
  `undertaker` varchar(100) NOT NULL DEFAULT '',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `addr` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(100) NOT NULL DEFAULT '',
  `mobile` varchar(20) NOT NULL DEFAULT '',
  `fax` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `remark` mediumtext NOT NULL,
  `sign` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='展会';

insert into `destoon_exhibit_8`(`itemid`,`catid`,`areaid`,`level`,`title`,`style`,`fee`,`introduce`,`keyword`,`pptword`,`hits`,`comments`,`orders`,`thumb`,`username`,`addtime`,`fromtime`,`totime`,`city`,`address`,`postcode`,`homepage`,`hallname`,`sponsor`,`undertaker`,`truename`,`addr`,`telephone`,`mobile`,`fax`,`email`,`qq`,`wx`,`remark`,`sign`,`editor`,`edittime`,`ip`,`template`,`status`,`linkurl`,`filepath`,`note`) values
('1','10','0','1','HDFS 2019湖南口腔展-2019第五届中国（湖南）口腔医疗设备器材展览会','','0','','HDFS 2019湖南口腔展-2019第五届中国（湖南）口腔医疗设备器材展览会,展会,长沙,湖南省医疗器械行业协会口腔医疗器械专业委员会','','0','0','0','','admin','1569941071','1572537600','1573833599','长沙','长沙市开福区营盘东路19号','','','湖南省展览馆','湖南省医疗器械行业协会口腔医疗器械专业委员会','','张先生','','13308227765','','','','','','','0','admin','1569941467','182.148.91.176','','3','show.php?itemid=1','',''),
('2','10','0','1','2019第83届APIChina中国国际医药原料、中间体、包装、设备交易会展会','','0','','2019第83届APIChina中国国际医药原料、中间体、包装、设备交易会展会,展会,南昌,国药励展展览有限责任公司','','0','0','0','','admin','1569941135','1574265600','1575129599','南昌','南昌国际博览中心','','','南昌国际博览中心','国药励展展览有限责任公司','','张先生','','13308227765','','','','','','','0','admin','1569941216','182.148.91.176','','3','show.php?itemid=2','',''),
('3','10','0','1','第83届中国国际医药原料药/中间体/包材/设备交易会','','0','','第83届中国国际医药原料药/中间体/包材/设备交易会,展会,南昌,中国食品药品国际交流中心','','0','0','0','','admin','1569941217','1573574400','1574351999','南昌','南昌国际博览中心','','','南昌国际博览中心','中国食品药品国际交流中心','','张先生','','13308227765','','','','','','','0','admin','1569941457','182.148.91.176','','3','show.php?itemid=3','',''),
('4','10','0','1','第82届中国国际医疗器械（秋季）博览会（2019CMEF）','','0','','第82届中国国际医疗器械（秋季）博览会（2019CMEF）,展会,青岛,上海沪旭会展服务有限公司','','0','0','0','','admin','1569941264','1573142400','1574179199','青岛','青岛世界博览城','','','青岛世界博览城','上海沪旭会展服务有限公司','','张先生','','13308227765','','','','','','','0','admin','1569941449','182.148.91.176','','3','show.php?itemid=4','',''),
('5','10','0','2','2019 中健婴（HMCC）·全国母婴大健康产业博览会','','0','','2019 中健婴（HMCC）·全国母婴大健康产业博览会,展会,上海,钧泽展览服务有限公司','','4','0','0','http://qingchuangjie.gotoip2.com/file/upload/201910/01/225343331.jpg','admin','1569941355','1573660800','1573747199','上海','上海市闵行区罗阳路168号A座409室','','','上海光大会展中心','钧泽展览服务有限公司','','张先生','','13308227765','','','','','','','0','admin','1569941625','182.148.91.176','','3','show.php?itemid=5','','');
DROP TABLE IF EXISTS  `destoon_exhibit_data_8`;
CREATE TABLE `destoon_exhibit_data_8` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='展会内容';

insert into `destoon_exhibit_data_8`(`itemid`,`content`) values
('1',' <strong style="font-family: "Microsoft Yahei"; color: rgb(9, 110, 154);">展会名称：</strong><span style="font-family: "Microsoft Yahei";">HDFS 2019湖南口腔展-2019第五届中国（湖南）口腔医疗设备器材展览会</span><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展时间：</strong>2019/10/10至2019/10/12</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展城市：</strong>湖南长沙</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">详细地址：</strong>长沙市开福区营盘东路19号</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展馆名称：</strong>湖南省展览馆</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联 系 人：</strong>辜珊珊</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系单位：</strong>广州日晖会展服务有限公司</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系电话：</strong>18320067300</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系Q　Q：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系传真：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系地址：</strong>广东省广州市天河区</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展会介绍：</strong></dt><dd style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;">
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline; text-align: center;"><strong><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);">2019第五届中国（湖南）口腔医疗设备器材展览会</span></strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline; text-align: center;"><strong><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);">暨口腔学术研讨会</span></strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline; text-align: center;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>Hunan Dental Forum＆Show 2019(HDFS 2019湖南)</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline; text-align: center;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>2019年10月10-12日 长沙·湖南省展览馆</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">主办单位:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">湖南省医疗器械行业协会口腔医疗器械专业委员会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">南方牙科联盟</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">承办单位:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">湖南芙蓉口腔医疗集团</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">广州日晖会展服务有限公司</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">协办单位：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">南方牙科联盟</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">（上海、广东、福建、江西、广西、云南、海南、贵州、重庆等省民营牙科协会）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">支持单位:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中南大学湘雅口腔医学院、中南大学湘雅口腔医院、湖南省人民医院口腔医疗中</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">心等69家口腔医学院、口腔医院、口腔科、口腔诊所、协会。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">媒体支持:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">康强网、好展会、口腔招聘网、环球医疗器械网、E展网、中国健康咨询网、</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">3618医疗器械网、口腔网、去展网</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>一、湖南省口腔医疗是华中地区发展**快的省份之一</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">湖南省地处中国南方15省市的中心位置, 接壤江西、广东、广西、贵州、四川、重庆周边六个省市。据2016年统计, 湖南省全省总人口8418万人， 2016年全省GDP 31244.7亿元人民币，位居全国35省区前十名, 是全国中部经济发展**快的省份之一。湖南经济的高速发展促进了口腔医疗的快速发展, 近三年, 湖南口腔医疗发展更为快速, 口腔医疗机构、口腔医院和牙科诊所由三年前的4000多家增加到5000多家, 口腔医生9000多人增加到10000多人。医生学习、交流、提升口腔医疗技术水平的气氛越来越浓厚, 因而在湖南长沙市办口腔会展, 其效果显而易见。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>二、HDFS湖南口腔展 往届回顾</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2014年5月16～18日和 2016年5月20～22日,2018年5月18-20日 在长沙市湖南省展览馆成功举办了三届 “湖南口腔医学大会暨口腔医疗设备与器材展览会”(SDFS 2014湖南、HDFS 2016湖南 HDFS 2018湖南)。HDFS 湖南是湖南史上**大规模的口腔医疗界的专业盛会。 三届会展,共举办了112专题场次研讨会,演讲专家来自北大、武大、川大、中大等七十多家知名大学和和口腔医院、医学院、学会、协会以及台湾、香港、韩国、加拿大的知名口腔专家。 三届展会的参展企业305家次, 参会参观的专业观众10018人, 他们来自湖南、湖北、福建、江西、广西、云南、贵州、广东、海南、湖北等十省市。HDFS 2018湖南比SDFS 2014湖南和HDFS 2016湖南展展商数增加了13.9%, 专业观众增加了32.8%。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>三、H</strong></span><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>DFS 2019 湖南的内容和规模:</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">1、年会:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">湖南省医疗器械行业协会口腔医疗器械专业委员会2019年会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2、技术研讨会:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">选20至25个热门专题, 专题范围含牙周、牙体、牙髓、种植、修复、正畸、牙槽外科、义齿 加工、数字化牙科、诊所管理等; 邀请知名口腔专家演讲。预计参会的专家、口腔医生、口腔医务工作者5000人以上。参加研讨会者可获国家或省医学继续教育学分。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">3、同期举办:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ø 管理和技术论坛、特色高峰论坛、沙龙活动</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ø 湖南口腔病例展示竞赛</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ø 操作班及培训班</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ø 口腔医疗设备器械展览会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">4、展会规模:</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">HDFS 2019湖南预设标准展位300--400个,邀请国内国外口腔医疗器械、器材与耗材生产企业、经销代理商展示其技术产品。预计参观的专家、口腔医生、口腔医务工作和采购商将有5000人以上。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);"><strong>四、组委会联系方式:</strong></span></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">1.人才招聘：湖南省口腔医学会民营口腔医疗分会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：谢岳13107114618</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2.参展咨询：广州日晖会展服务有限公司</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：陈小姐13570109723（微信同号）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：郭小姐18825066285（微信同号）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：徐先生15626227176（微信同号）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：骆先生13570400515（微信同号）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">3.媒体合作</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">骆小姐：18825097554</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">4.参会咨询</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">辜小姐:15812436547</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">官网:www.dentalshow.com.cn</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">公众号:南方牙科展</p>
</dd>'),
('2','&nbsp;<strong style="font-family: &quot;Microsoft Yahei&quot;; color: rgb(9, 110, 154);">展会名称：</strong><span style="font-family: &quot;Microsoft Yahei&quot;;">​；；2019第83届APIChina中国国际医药原料、中间体、包装、设备交易会展会</span><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展时间：</strong>2019/10/10至2019/10/12</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展城市：</strong>江西南昌</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">详细地址：</strong>南昌</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展馆名称：</strong>南昌国际博览中心</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联 系 人：</strong>郑敏</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系单位：</strong>国药励展展览有限责任公司</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系电话：</strong>021-54378039|18621307312</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系Q　Q：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系传真：</strong>021-54378039</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系地址：</strong>上海闵行区景联路</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展会介绍：</strong></dt><dd style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: &quot;Microsoft Yahei&quot;; vertical-align: ba<em></em>seline;">
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">第二十三届中国国际医药（工业）展览会暨技术交流会（ 简称CHINA- PHARM ) 与第83届中国国际医药原料药／中间 体I包装／设备交易会（简称 API China ) 将千2019年10月在南昌国际博览中心举办。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">打造中国制药工业领域</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">规模**大的全产业链盛会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">全面覆盖药品全产业链、全生命周期的行业盛会，制药工业领域新趋势、新技术、新理念、新模式的旗舰展示平台</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">国际品牌开拓中国制药和健康营养品市场的**平台</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">超97%的中国制药工业百强企业视为采购原辅料、包装、设备的**平台</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2019.10月10-12日 南昌国际博览中心</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">主办单位：国药励展展览有限责任公司</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展会规模：70000平方米，参展企业：1800+ 现场观众预计：60000+</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展品范围：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">设备;原料药设备，医药包装机械，环保与净化设备，药物检测设备，制剂设备，药品电子监管设备，药用粉碎设备，制药用水设备，中药设备，制冷设备，流体设备，</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">实验室设备及耗材，药品包装设备，生物工程，自动化与信息化系统与设备</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">原料药：制药原料药，中间体，精细化工、化工原料，兽药原料，生物技术，化 学试剂，中药原料，饲料原料及添加剂，保健品原料及添加剂，食品原 料及添加剂，化妆品原料及添加剂，</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">合同外包生产及服务</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">辅料：包衣材料， 胶襄、明胶， 增塑剂， 赋形剂 ， 润滑剂， 崩解剂 ， 助流剂 ， 表面活性剂，溶媒，抗氧剂，遮光剂，矫味剂，甜味剂，香精，着色剂，防腐剂 ， PH调节剂</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">包材：大输液包装，胶囊、明胶，洁净服装及材料，瓶盖，瓶塞，药品PVC硬片，药用软管，药用塑料瓶，医药原料包装容器，药用玻璃，干燥机，定量阀，喷雾泵，塑料托，铝箱、铝塑包装，包装印刷</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">特色会议</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国制药工程大会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国化学制药行业年度峰会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国国际制药工业环保发展论坛</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国智能制药2025峰会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">国药励展</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Reed Smopharm Exhibitions</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国食品药品国际交流中心是国家药品监督管理局直属事业单位，开展食品药品相关的国际交流与合作， 开展与港、澳、台地区食品药品方面的交流与合作。组织实施非官方的食品药品国际交流与合作项目。举 办食品药品涉外会议、展览，开展咨询服务、培训及技术交流等。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">国药励展是中国**的医药健康产业集团&mdash;中国医药集团和世界**的博览集团&mdash;励展博览集团的合资企 业。旗下拥有26个展会品牌， 覆盖整个大健康产业链， 并延伸至科研、教育等领域。由国药励展主办的API</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">China, 始创千1968年， 经过50年的发展，已 经成为亚太区颇具规模， 提供服务制药工业全产业链解决方案的专业平台， API China专注于提高中国医药原料药、中间体、医药包装材料、制药设备企业生产、研发的整体水平， 吸引来自全球20多个国家和地区的6万名制药企业到会参观， 是中国制药工业新产品、新技术展示的旗舰展会。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">I</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展位咨询</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">传真：021-54378039</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">E-mail: 2766797402@qq.com</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">联系人：郑敏 18621307312（微信同号）</p>
</dd>'),
('3',' <strong style="font-family: "Microsoft Yahei"; color: rgb(9, 110, 154);">展会名称：</strong><span style="font-family: "Microsoft Yahei";">第83届中国国际医药原料药/中间体/包材/设备交易会</span><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展时间：</strong>2019/10/10至2019/10/12</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展城市：</strong>江西南昌</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">详细地址：</strong>南昌国际博览中心</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展馆名称：</strong>南昌国际博览中心</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联 系 人：</strong>朱敏</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系单位：</strong>组委会</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系电话：</strong>021-54700927</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系Q　Q：</strong>64080981</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系传真：</strong>021-54700907</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系地址：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展会介绍：</strong></dt><dd style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;">
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">第二十三届中国国际医药（工业）展览会暨技术交流会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">第83届中国国际医药原料药/中间体/包材/设备交易会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">主办单位：中国食品药品国际交流中心 国药励展展览有限责任公司</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">时 间：2019年10月10-12 日</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">地 点：南昌国际博览中心</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展会概述：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">第二十三届中国国际医药（工业）展览会暨技术交流会（ 简称CHINA- PHARM ) 与第83届中国国际医药原料药／中间体/包材／设备交易会（简称 API China ) 将于2019年10月在南昌国际博览中心举办。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">打造中国制药工业领域，规模**大的全产业链盛会，全面覆盖药品全产业链、全生命周期的行业盛会，制药工业领域新趋势、新技术、新理念、新模式的旗舰展示平台，国际品牌开拓中国制药和健康营养品市场的**平台超97%的中国制药工业百强企业视为采购原辅料、包装、设备的**平台。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展会规模：70000平方米，参展企业：1800+ 现场观众预计：60000+</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展品范围：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">设备：原料药设备，医药包装机械，环保与净化设备，药物检测设备，制剂设备，药品电子监管设备，药用粉碎设备，制药用水设备，中药设备，制冷设备，流体设备，</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">实验室设备及耗材，药品包装设备，生物工程，自动化与信息化系统与设备</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">原料药：制药原料药，中间体，精细化工、化工原料，兽药原料，生物技术，化 学试剂，中药原料，饲料原料及添加剂，保健品原料及添加剂，食品原 料及添加剂，化妆品原料及添加剂，合同外包生产及服务</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">辅料：包衣材料， 胶襄、明胶， 增塑剂， 赋形剂 ， 润滑剂， 崩解剂 ， 助流剂 ， 表面活性剂，溶媒，抗氧剂，遮光剂，矫味剂，甜味剂，香精，着色剂，防腐剂 ， PH调节剂</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">包材：大输液包装，胶囊、明胶，洁净服装及材料，瓶盖，瓶塞，药品PVC硬片，药用软管，药用塑料瓶，医药原料包装容器，药用玻璃，干燥机，定量阀，喷雾泵，塑料托，铝箱、铝塑包装，包装印刷</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">特色会议</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国制药工程大会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国化学制药行业年度峰会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国国际制药工业环保发展论坛</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国智能制药2025峰会</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">国药励展Reed Smopharm Exhibitions</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">中国食品药品国际交流中心是国家药品监督管理局直属事业单位，开展食品药品相关的国际交流与合作， 开展与港、澳、台地区食品药品方面的交流与合作。组织实施非官方的食品药品国际交流与合作项目。举 办食品药品涉外会议、展览，开展咨询服务、培训及技术交流等。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">国药励展是中国**的医药健康产业集团—中国医药集团和世界**的博览集团—励展博览集团的合资企业。旗下拥有26个展会品牌，覆盖整个大健康产业链，并延伸至科研、教育等领域。由国药励展主办的API China,始创于1968年，经过50年的发展，已经成为亚太区颇具规模，提供服务制药工业全产业链解决方案的专业平台，API China专注于提高中国医药原料药、中间体、医药包装材料、制药设备企业生产、研发的整体水平，吸引来自全球20多个国家和地区的6万名制药企业到会参观，是中国制药工业新产品、新技术展示的旗舰展会。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">展位咨询：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">朱敏 女士</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">移动电话：15618090005（兼微信）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">固定电话：021-54700927</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">QQ：64080981</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Email:shanghai_zm@126.com</p>
</dd>'),
('4',' <strong style="font-family: "Microsoft Yahei"; color: rgb(9, 110, 154);">展会名称：</strong><span style="font-family: "Microsoft Yahei";">第82届中国国际医疗器械（秋季）博览会（2019CMEF）</span><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展时间：</strong>2019/10/19至2019/10/22</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展城市：</strong>山东青岛</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">详细地址：</strong>青岛世界博览城</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展馆名称：</strong>青岛世界博览城</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联 系 人：</strong>王女士</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系单位：</strong>上海沪旭会展服务有限公司</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系电话：</strong>|17712414086</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系Q　Q：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系传真：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系地址：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展会介绍：</strong></dt><dd style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;">
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><img src="http://www-x-china-show-x-net.img.abc188.com/file/upload/201909/18/09-46-11-48-39318.png" alt="" style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; border: 0px;" /></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>第82届中国国际医疗器械（秋季）博览会（2019CMEF）</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>第29届中国国际医疗器械设计与制造技术（秋季）展览会（2019ICMD）</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>山东博览城 10.19-10.22</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2019年注定是不平凡的一年。随着6月6日工信部正式向中国电信、中国移动、中国联通、中国广电发放5G商用牌照，中国正式进入5G商用元年。科技赋能大健康，<span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(229, 51, 51);">CMEF</span> 作为亚太地区覆盖医疗器械全产业链，集产品技术、服务创新、商贸合作、教育培训与学术交流为一体的行业综合服务平台，十月青岛，我们将继续智能医疗精彩！</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2019CMEF秋的特色产业分区将汇集<span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(0, 213, 255);">智慧健康、IVD、康复、医疗影像、消毒感控、医疗耗材、医院建设、医光、医电、骨科、手术室、医疗服务等领域</span>，旗下CMEF品牌展区涵盖：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>CMEF影像区：</strong>放射产品、超声产品、核医学产品、分子影像、介入产品等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>CMEF手术室区：</strong>整体手术设备、手术器械、麻醉机、呼吸机、监护仪、手术室工程、手术灯等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>CMEF IVD：</strong>整体实验室解决方案、临床诊断设备、诊断试剂、POCT、家用诊断设备等</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>智慧健康区：</strong>信息系统、人工智能、移动及远程医疗、大数据及物联网、可穿戴设备、3D打印、VR＆AR等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>CMEF-Orthiopaedics 骨科：</strong>关节、创伤、脊柱三大类别的骨科植入耗材、骨科手术器械与设备、以及骨动力工具等其他骨科相关产品等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>医用耗材：</strong>穿刺注射类、卫生材料及辅料、高分子耗材、消毒及清洁等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>康复及家庭医疗：</strong>康复工程、ICF治疗、家庭医疗、辅助器具、中医诊断、预防保健等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>医用光学：</strong>胶囊胃镜、电子内窥镜系统、激光手术治疗设备等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>医院建设及净化工程：</strong>医用病床、感控设备、药房自动化、医院家具等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>消毒感控：</strong>医疗感控设备、医用消毒设备等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>医疗服务：</strong>医疗服务设备、医疗保障等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><img src="http://www-x-china-show-x-net.img.abc188.com/file/upload/201909/18/09-47-58-52-39318.png" alt="" style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; border: 0px;" /></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">CMEF携手各大权威机构，力邀行业权威亲临82届展会现场，开启学术盛宴，将为大家带来：</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>全球医院精益运营论坛暨第二届HIA大数据峰会</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>中国临床医学影像高端论坛暨“J10”峰会</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>2019 第十一届中国体外诊断产业高峰论坛</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>第二届中国医学转化创新创业大赛总决赛</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>医疗器械注册人制度暨医学成果转化高峰论坛</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>2019医院清洗消毒灭菌设备**管理高峰论坛</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>第十四届医疗器械产业创新服务论坛</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>第八届中国智慧健康医疗发展高峰论坛主题：智能化慢病闭环管理及其应用</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong>中国医疗器械制造定制服务创新论坛之第十二届医用塑料制造技术研讨会</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"><strong><br />
</strong></p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">几乎覆盖行业全产业链的专业论坛及会议，在CMEF现场将学术与产业链接。你想听的专家声音，你想看的**新产品，在CMEF满足你所有需求！快来现场解锁更多专家论坛！</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">还是在青岛的海边，第29届中国国际医疗器械设计与制造技术（秋季）展览会，在N5馆与CMEF同期举行。本次ICMD带来了<span style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: inherit; font-family: inherit; vertical-align: ba<em></em>seline; color: rgb(0, 213, 255);">智能制造芯片、新材料集群、设计及研发、包装及打印区、流体控制集群、气动控制集群、电池电源集群、电机集群、传动控制集群、制造设备及OEM集群、光学元件集群</span>等等集群分区。CMEF与ICMD携手为你打通医疗器械制造与产品上下游，打造医疗器械制造商与服务供应商交流平台。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;"> </p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">专业观众以及组团观众参观联系人：王女士手机17712414086 QQ：1074271044</p>
</dd>'),
('5',' <strong style="font-family: "Microsoft Yahei"; color: rgb(9, 110, 154);">展会名称：</strong><span style="font-family: "Microsoft Yahei";">2019 中健婴（HMCC）·全国母婴大健康产业博览会</span><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展时间：</strong>2019/10/30至2019/11/1</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">参展城市：</strong>上海闵行</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">详细地址：</strong>上海市闵行区罗阳路168号A座409室</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展馆名称：</strong>上海光大会展中心</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联 系 人：</strong>周敏</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系单位：</strong>钧泽展览服务有限公司</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系电话：</strong>13782958957</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系Q　Q：</strong>1326939482</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系传真：</strong></dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">联系地址：</strong>上海市闵行区罗阳路168号A座409室</dt><dt style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;"><strong style="color: rgb(9, 110, 154);">展会介绍：</strong></dt><dd style="margin: 0px; padding: 2px 10px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; line-height: 24px; font-family: "Microsoft Yahei"; vertical-align: ba<em></em>seline;">
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2019 中健婴（HMCC）·全国母婴大健康产业博览会2019 第五届产后修复及月子健康用品博览会主办单位：中国商业经济学会中商妇幼产业研究院承办单位：上海钧泽展览有限公司时间：2019 年 10 月 30 日-11 月 1 日地点：上海光大会展中心</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">【展会规模】 预计参会企业:700+家论坛参会: 2000+人展会：40000+人</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">【媒体支持】 CCTV/中国教育电视台/中国国际广播电台/地方卫视频道/喜马拉雅</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">爱奇艺母婴/优酷亲子/今日头条/新浪育儿/腾讯育儿/搜狐母婴/网易/凤凰网/中国网/中国新闻网 中华网/摇篮网/宝宝树/育儿网/太平洋亲子网/好太太网/妈妈网/中国婴童网/芥末堆</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">父母必读/母子健康/妈咪宝贝/父母世界/妈妈宝宝/妈妈帮/幼儿教育/母婴商情/中童传媒/母婴视界/中国婴童 网/中国妇女报/齐鲁晚报/扬子晚报/中国教育报/北京商报/中国财经时报/消费日报等</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">【直播支持】魔都直播</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 招商范围Ÿ 基因技术、产品及服务商：Ÿ 相关的仪器设备、试剂、耗材生产商、研发商；试验服务、生信分析服务商等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 辅助生殖相关的药物（如生长素、尿提取人促卵泡素、头孢嗪脒钠等）生产商、品牌商和技术服务商（如 相关药物研发、不孕不育医疗服务商、辅助医疗技术服务商等）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 经期管理平台、产品和服务商、经期调理产品/药物；Ÿ 预防宫颈癌的产品和服务Ÿ （如默沙东HPV 疫苗），女性私护产品与服务商；Ÿ 营养保健食品：Ÿ 生产商、技术服务商，包括但不限于膳食补充剂、有机食品、运动营养品、养生滋补品、维生素、蛋 白粉、鱼油类产品、葡萄籽胶囊、螺旋藻、保健酒、保健茶产品、参类产品、冬虫夏草、灵芝、牛樟芝、 阿胶、绿藻产品、胚芽产品、蜂产品、芦荟产品、益生菌类、燕窝产品等；Ÿ 母婴健康护理仪器设备生产商和技术服务商：Ÿ 家用护理、医疗仪器：按摩器具、足疗药浴、健康体检仪器、理疗仪器、康复运动器材、户外健身器材、 水疗设备、桑拿设备及相关耗材、门店管理软件平台；生育及产后修复的医疗设备、器械（如婴儿培养箱、 婴儿辐射保暖台、黄疸治疗设备等）及耗材医疗信息化软件及设备等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 全国连锁/整店输出的护理服务机构：月子中心、早教中心、产后修复中心、小儿推拿馆、儿童游泳馆及 家政服务公司等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 母婴护理人才培训机构：月嫂、育婴师、护理人员、营养师、催乳师、产后恢复师等护理人才的培训、认 证机构/平台商。Ÿ 参观人群Ÿ 母婴健康领域相关的行业协会的领导、专家、技术人员；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 公立医院、民营医院的院士、专家及采购负责人；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 基因技术、产品及相关仪器设备、试剂、耗材的技术专家、渠道商、品牌商、资本方和自媒体平台商；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 辅助生殖相关的药物的技术专家、生产商、渠道商；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 月子中心、产后修复等母婴护、理服务机构的品牌商、加盟商；美容院创业者、经营者；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 母婴大健康产业领域的资本方、行业研究者；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">Ÿ 其他母婴大健康产业采购商、渠道商。各级妇幼协会、营养协会、母婴协会等主管领导、专家、企业高层 及行业媒体；全国月子会所、产后修复机构、妇产医院、妇幼保健院、0-3岁早教机构等；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">全国母婴连锁店/美容养生机构/母婴服务生态链机构及个人从业者。全国母婴产品的批发商、代理商、经 销商；孕育期/产后营养师、心理咨询师、护理师、育婴师、婴儿健康指导师、催乳师等展位费用： 展位类别展商类别参展费用备注普通标展 9 ㎡（3X3M）国内企业13800RMB铝合金围板、一张咨询桌、两把折椅、两只射灯、一个220V/500W 的电源插座、展位内满铺地毯、楣板上书中文公司名称双开口展位加收 10%展位费不包含内部装饰。 合资企业15800RMB外商企业USD3800豪华标展 9 ㎡（3X3M）国内企业17800RMB楣板上方悬挂企业LOGO 标识板基本标准配置与普通标准展位相同双开口加收 10%展位费不包含内部装饰（logo 要求；500*500mm，300dpi,png 格式） 合资企业19800RMB外商企业USD4200光地展位（36 ㎡以上）国内企业1380RMB/㎡不提供任何设施（光地地毯、水、电、气及特殊装修光地管理费等另算（36 ㎡起租）参展单位如租用光地，应另交 30 元/平方米的光地管理费）</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">合资企业1680RMB/㎡外商企业USD380/㎡【参展须知】</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">1、参展报名：拟参展单位请填写参展申请表及合同（附件一）,表中内容将刊入展览会会刊，故请提供中英文打字稿或用正楷填写清楚，连同企业营业执照、复印件（凡上述证件有虚假者，取消参展资格）及展位选 择（展位图附后）一并寄或传真扫描至展览会主办单位办公室;</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">2、申请展位一周内将参展费用[50%（订金）或全款]电汇或交至组织单位，余款于 2019 年 10 月 8 日前； 展位分配原则：“先申请，先付款，先安排”；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">3、参展商在汇出各项费用后，请将银行汇款单传真或扫描至组织单位；</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">4、组织单位在收到展台费用后，发放《参展手册》给参展商。</p>
<p style="margin: 0px; padding: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; font-family: inherit; vertical-align: ba<em></em>seline;">地址：上海市闵行区罗阳路 168 号 A 座 409 室联系人：周敏17335912755 13782958957（手机同微信） 邮箱1326939482@qq.comQQ:1326939482</p>
</dd>');
DROP TABLE IF EXISTS  `destoon_exhibit_sign_8`;
CREATE TABLE `destoon_exhibit_sign_8` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user` varchar(30) NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL,
  `truename` varchar(30) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `wx` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='展会报名';

DROP TABLE IF EXISTS  `destoon_favorite`;
CREATE TABLE `destoon_favorite` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商机收藏';

DROP TABLE IF EXISTS  `destoon_fetch`;
CREATE TABLE `destoon_fetch` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sitename` varchar(100) NOT NULL DEFAULT '',
  `domain` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `encode` varchar(30) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='单页采编';

DROP TABLE IF EXISTS  `destoon_fields`;
CREATE TABLE `destoon_fields` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tb` varchar(30) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `length` smallint(4) unsigned NOT NULL DEFAULT '0',
  `html` varchar(30) NOT NULL DEFAULT '',
  `default_value` text NOT NULL,
  `option_value` text NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `input_limit` varchar(255) NOT NULL DEFAULT '',
  `addition` varchar(255) NOT NULL DEFAULT '',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `front` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `tablename` (`tb`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='自定义字段';

DROP TABLE IF EXISTS  `destoon_finance_award`;
CREATE TABLE `destoon_finance_award` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `fee` float unsigned NOT NULL DEFAULT '0',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='打赏记录';

DROP TABLE IF EXISTS  `destoon_finance_card`;
CREATE TABLE `destoon_finance_card` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(30) NOT NULL DEFAULT '',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `number` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='充值卡';

DROP TABLE IF EXISTS  `destoon_finance_cash`;
CREATE TABLE `destoon_finance_cash` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `bank` varchar(50) NOT NULL DEFAULT '',
  `banktype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `branch` varchar(100) NOT NULL,
  `account` varchar(30) NOT NULL DEFAULT '',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='申请提现';

DROP TABLE IF EXISTS  `destoon_finance_charge`;
CREATE TABLE `destoon_finance_charge` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `bank` varchar(20) NOT NULL DEFAULT '',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `fee` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `sendtime` int(10) unsigned NOT NULL DEFAULT '0',
  `receivetime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='在线充值';

DROP TABLE IF EXISTS  `destoon_finance_coupon`;
CREATE TABLE `destoon_finance_coupon` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `seller` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `oid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL,
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='优惠券';

DROP TABLE IF EXISTS  `destoon_finance_credit`;
CREATE TABLE `destoon_finance_credit` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `amount` int(10) NOT NULL DEFAULT '0',
  `balance` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='积分流水';

insert into `destoon_finance_credit`(`itemid`,`username`,`amount`,`balance`,`addtime`,`reason`,`note`,`editor`) values
('1','admin','1','1','1569936280','登录奖励','182.148.91.176','system'),
('2','admin','2','3','1569941135','展会信息发布','ID:1','system'),
('3','admin','2','5','1569941216','展会信息发布','ID:2','system'),
('4','admin','2','7','1569941264','展会信息发布','ID:3','system'),
('5','admin','2','9','1569941355','展会信息发布','ID:4','system'),
('6','admin','2','11','1569941403','展会信息发布','ID:5','system'),
('7','a238128822','2','2','1569944615','人才招聘发布','ID:1','system'),
('8','9282733','2','2','1569944693','人才招聘发布','ID:2','system'),
('9','admin','2','13','1569944732','人才招聘发布','ID:3','system'),
('10','a238128824','2','2','1569944797','人才招聘发布','ID:4','system'),
('11','a238128822','2','4','1569944879','人才招聘发布','ID:5','system'),
('12','37237712','2','2','1569944982','人才招聘发布','ID:6','system'),
('13','91872822412','2','2','1569945020','人才招聘发布','ID:7','system'),
('14','93323988932','2','2','1569945059','人才招聘发布','ID:8','system'),
('15','a238128821','2','2','1569945398','招商信息发布','ID:1','system'),
('16','9282733','2','4','1569945457','招商信息发布','ID:2','system'),
('17','a238128821','2','4','1569945483','招商信息发布','ID:3','system'),
('18','a238128824','2','4','1569945505','招商信息发布','ID:4','system'),
('19','a238128822','2','6','1569945560','招商信息发布','ID:5','system'),
('20','82378238','2','2','1569945745','招商信息发布','ID:6','system'),
('21','9282733','2','6','1569945779','招商信息发布','ID:7','system'),
('22','admin','2','15','1569945848','招商信息发布','ID:8','system'),
('23','93323988932','2','4','1569945898','招商信息发布','ID:9','system'),
('24','92732832','2','2','1569945931','招商信息发布','ID:10','system'),
('25','91872822412','2','4','1569945985','招商信息发布','ID:11','system'),
('26','37237712','2','4','1569946075','招商信息发布','ID:12','system'),
('27','92732832','2','4','1569946168','招商信息发布','ID:13','system'),
('28','92732832','2','6','1569946235','招商信息发布','ID:14','system'),
('29','92732832','2','8','1569946331','招商信息发布','ID:15','system'),
('30','a238128822','2','8','1569946376','招商信息发布','ID:16','system'),
('31','a238128822','2','10','1569947733','求购信息发布','ID:1','system'),
('32','37237712','2','6','1569947795','求购信息发布','ID:2','system'),
('33','93323988932','2','6','1569947836','求购信息发布','ID:3','system'),
('34','93323988932','2','8','1569947869','求购信息发布','ID:4','system'),
('35','admin','2','17','1569947964','市场行情发布','ID:1','system'),
('36','admin','2','19','1569947981','市场行情发布','ID:2','system'),
('37','admin','2','21','1569948001','市场行情发布','ID:3','system'),
('38','admin','2','23','1569948033','市场行情发布','ID:4','system'),
('39','admin','1','24','1570673428','登录奖励','182.151.233.54','system'),
('40','a238128822','2','12','1570677547','求购信息发布','ID:5','system'),
('41','a238128824','2','6','1570677632','求购信息发布','ID:6','system'),
('42','a238128821','2','6','1570677682','求购信息发布','ID:7','system'),
('43','92732832','2','10','1570677763','求购信息发布','ID:8','system'),
('44','a238128824','2','8','1570677832','求购信息发布','ID:9','system'),
('45','a238128821','2','8','1570677870','求购信息发布','ID:10','system'),
('46','admin','2','26','1570677925','求购信息发布','ID:11','system'),
('47','a238128824','2','10','1570678121','求购信息发布','ID:12','system'),
('48','admin','1','27','1591309478','登录奖励','171.214.236.112','system'),
('49','admin','1','28','1592030491','登录奖励','223.198.226.112','system'),
('50','admin','2','30','1592062662','药品信息发布','ID:13','system'),
('51','32883232','2','0','1592062823','药品信息发布','ID:14','system'),
('52','a238128824','2','12','1592062903','药品信息发布','ID:15','system'),
('53','a238128824','2','14','1592062979','药品信息发布','ID:16','system'),
('54','admin','1','31','1592197967','登录奖励','223.198.224.17','system'),
('55','admin','1','32','1592451229','登录奖励','171.214.237.159','system'),
('56','92732832','-5','5','1592451272','药品信息删除','ID:8','system'),
('57','admin','1','33','1592551335','登录奖励','122.234.13.59','system');
DROP TABLE IF EXISTS  `destoon_finance_deposit`;
CREATE TABLE `destoon_finance_deposit` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='保证金';

DROP TABLE IF EXISTS  `destoon_finance_pay`;
CREATE TABLE `destoon_finance_pay` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `fee` float unsigned NOT NULL DEFAULT '0',
  `currency` varchar(20) NOT NULL DEFAULT '',
  `paytime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='支付记录';

DROP TABLE IF EXISTS  `destoon_finance_promo`;
CREATE TABLE `destoon_finance_promo` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `username` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `cost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `number` int(10) unsigned NOT NULL DEFAULT '0',
  `open` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `editor` varchar(30) NOT NULL,
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='优惠促销';

DROP TABLE IF EXISTS  `destoon_finance_record`;
CREATE TABLE `destoon_finance_record` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `bank` varchar(30) NOT NULL DEFAULT '',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='财务流水';

DROP TABLE IF EXISTS  `destoon_finance_sms`;
CREATE TABLE `destoon_finance_sms` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `amount` int(10) NOT NULL DEFAULT '0',
  `balance` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `reason` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='短信增减';

DROP TABLE IF EXISTS  `destoon_form`;
CREATE TABLE `destoon_form` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `groupid` varchar(255) NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `question` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `maxanswer` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='表单';

DROP TABLE IF EXISTS  `destoon_form_answer`;
CREATE TABLE `destoon_form_answer` (
  `aid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `rid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `qid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `other` varchar(255) NOT NULL,
  `item` varchar(100) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='表单回复';

DROP TABLE IF EXISTS  `destoon_form_question`;
CREATE TABLE `destoon_form_question` (
  `qid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `required` varchar(30) NOT NULL,
  `extend` mediumtext NOT NULL,
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='表单选项';

DROP TABLE IF EXISTS  `destoon_form_record`;
CREATE TABLE `destoon_form_record` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `item` varchar(100) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='表单回复记录';

DROP TABLE IF EXISTS  `destoon_friend`;
CREATE TABLE `destoon_friend` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `truename` varchar(20) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `company` varchar(100) NOT NULL DEFAULT '',
  `career` varchar(20) NOT NULL DEFAULT '',
  `telephone` varchar(20) NOT NULL DEFAULT '',
  `mobile` varchar(20) NOT NULL DEFAULT '',
  `homepage` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='我的商友';

DROP TABLE IF EXISTS  `destoon_gift`;
CREATE TABLE `destoon_gift` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `credit` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `groupid` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `orders` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `maxorder` int(10) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='积分换礼';

DROP TABLE IF EXISTS  `destoon_gift_order`;
CREATE TABLE `destoon_gift_order` (
  `oid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `credit` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`oid`),
  KEY `itemid` (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='积分换礼订单';

DROP TABLE IF EXISTS  `destoon_group_17`;
CREATE TABLE `destoon_group_17` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `marketprice` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `savemoney` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `discount` float unsigned NOT NULL DEFAULT '0',
  `minamount` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `logistic` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `orders` int(10) unsigned NOT NULL DEFAULT '0',
  `sales` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `process` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='团购';

DROP TABLE IF EXISTS  `destoon_group_data_17`;
CREATE TABLE `destoon_group_data_17` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='团购内容';

DROP TABLE IF EXISTS  `destoon_group_order_17`;
CREATE TABLE `destoon_group_order_17` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `buyer` varchar(30) NOT NULL DEFAULT '',
  `seller` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `number` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `logistic` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `password` varchar(6) NOT NULL DEFAULT '',
  `buyer_name` varchar(30) NOT NULL DEFAULT '',
  `buyer_address` varchar(255) NOT NULL DEFAULT '',
  `buyer_postcode` varchar(10) NOT NULL DEFAULT '',
  `buyer_mobile` varchar(30) NOT NULL DEFAULT '',
  `send_type` varchar(50) NOT NULL DEFAULT '',
  `send_no` varchar(50) NOT NULL DEFAULT '',
  `send_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `send_time` varchar(20) NOT NULL DEFAULT '',
  `send_days` int(10) unsigned NOT NULL DEFAULT '0',
  `add_time` smallint(6) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `buyer_reason` mediumtext NOT NULL,
  `refund_reason` mediumtext NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `buyer` (`buyer`),
  KEY `seller` (`seller`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='团购订单';

DROP TABLE IF EXISTS  `destoon_guestbook`;
CREATE TABLE `destoon_guestbook` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `reply` text NOT NULL,
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='留言本';

DROP TABLE IF EXISTS  `destoon_honor`;
CREATE TABLE `destoon_honor` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `authority` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='荣誉资质';

DROP TABLE IF EXISTS  `destoon_info_22`;
CREATE TABLE `destoon_info_22` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `thumb1` varchar(255) NOT NULL DEFAULT '',
  `thumb2` varchar(255) NOT NULL DEFAULT '',
  `thumbs` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `fax` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `n1` varchar(100) NOT NULL,
  `n2` varchar(100) NOT NULL,
  `n3` varchar(100) NOT NULL,
  `v1` varchar(100) NOT NULL,
  `v2` varchar(100) NOT NULL,
  `v3` varchar(100) NOT NULL,
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `edittime` (`edittime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`),
  KEY `editdate` (`editdate`,`vip`,`edittime`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='招商';

insert into `destoon_info_22`(`itemid`,`catid`,`level`,`title`,`style`,`fee`,`keyword`,`pptword`,`hits`,`comments`,`thumb`,`thumb1`,`thumb2`,`thumbs`,`username`,`groupid`,`addtime`,`adddate`,`totime`,`areaid`,`company`,`vip`,`validated`,`truename`,`telephone`,`fax`,`mobile`,`address`,`email`,`qq`,`wx`,`ali`,`skype`,`introduce`,`n1`,`n2`,`n3`,`v1`,`v2`,`v3`,`editor`,`edittime`,`editdate`,`ip`,`template`,`status`,`listorder`,`islink`,`linkurl`,`filepath`,`note`) values
('1','4','1','骨盆底补片-PR\\PR2\\PR4','','0','骨盆底补片-PR\\PR2\\PR4,医用耗材全国','','36','0','','','','','a238128821','7','1591197677','2019-10-01','0','0','湖北肽尔生物医疗科技有限公司','2','0','张','13307183061/13307189625/13307197292','','','湖北省仙桃市刘口工业园现代中加科技城','','','','','','DynaMesh-PR\\PR2\\PR4 专为盆底器官脱垂编织PVDF材质盆底补片本品适用于支撑和稳定相连组织结构和韧带，具体应用于子宫脱垂、直肠','','','','','','','admin','1569945398','2019-10-01','182.148.91.176','','3','0','0','show.php?itemid=1','',''),
('2','6','1','一体式电子皮肤镜','','0','一体式电子皮肤镜,医疗器械全国','','35','0','','','','','9282733','7','1591197693','2019-10-01','0','0','北京格润来福医药科技有限公司','2','0','张先生','010-57129657','','','北京市海淀区上地十街辉煌国际广场','','','','','','产品名称：一体式数字皮肤镜产品型号：主体：Miss Horus Scope DSC100 镜头：Miss Horus Scope DDC100主体：Miss Horus+Scope DS','','','','','','','admin','1569945457','2019-10-01','182.148.91.176','','3','0','0','show.php?itemid=2','',''),
('3','6','1','半导体激光治疗仪JLP-280','','0','半导体激光治疗仪JLP-280,医疗器械全国','','37','0','','','','','a238128821','7','1591197752','2019-10-01','0','0','湖北肽尔生物医疗科技有限公司','2','0','张','13307183061/13307189625/13307197292','','','湖北省仙桃市刘口工业园现代中加科技城','','','','','','一、应用范围：用于急慢性软组织损伤、骨关节炎及神经性疼痛,如软组织运动损伤、腰椎间盘突出、肩周炎、颈背脊筋膜炎、颈椎病、','','','','','','','admin','1569945483','2019-10-01','182.148.91.176','','3','0','0','show.php?itemid=3','',''),
('4','6','1','菲尔茵医用阴道修复液','','0','菲尔茵医用阴道修复液,医疗器械全国','','36','0','','','','','a238128824','7','1591197778','2019-10-01','0','0','南京瑞普森生物科技有限公司','2','0','李小姐','025-52137655','','','南京市秣周东路12号4号楼10层','','','','','','床报告显示：壳聚糖具有良好的吸附性，进入阴道后，可吸附于阴道壁形成保护膜，持久作用。对细菌、白色念珠菌、病毒、滴虫等多种','','','','','','','admin','1569945505','2019-10-01','182.148.91.176','','3','0','0','show.php?itemid=4','',''),
('5','6','1','产后康复治疗项目（专科仪器+耗材）','','0','产后康复治疗项目（专科仪器+耗材）,医疗器械全国','','45','0','','','','','a238128822','7','1591197800','2019-10-01','0','0','南昌华康医疗科技有限公司','2','0','张先生','0791-85297776','','','江西省南昌市小蓝工业园玉湖路8号','','','','','','更多','','','','','','','admin','1569945560','2019-10-01','182.148.91.176','','3','0','0','show.php?itemid=5','',''),
('6','7','1','产后康复治疗仪','','0','产后康复治疗仪,家用器械全国','','43','0','http://www.kdzyg.com/file/upload/201910/02/000205661.jpg.thumb.jpg','','','','82378238','7','1591197855','2019-10-01','0','0','武汉安士泰医疗科技有限公司','2','0','王先生','027-87780958','','','武汉市东湖开发区关东工业园七号地块','','','','','','工作原理；产后康复治疗仪是一项新兴的产后恢复治疗技术，它主要是利用低频脉冲，对产妇产后乳房、卵巢、子宫、盆底、阴道、形体','','','','','','','admin','1569945745','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=6','',''),
('7','8','1','液基寄生虫检测处理试剂盒','','0','液基寄生虫检测处理试剂盒,诊断试剂全国','','44','0','http://www.kdzyg.com/file/upload/201910/02/000333931.jpg.thumb.jpg','','','','9282733','7','1591198040','2019-10-02','0','0','北京格润来福医药科技有限公司','2','0','张先生','010-57129657','','','北京市海淀区上地十街辉煌国际广场','','','','','','一、产品名称：液基寄生虫检测处理试剂盒是一款针对人体内36种寄生虫筛查的液基检测耗材。湖北泰康同俄罗斯联邦知名寄生虫专家斯','','','','','','','admin','1569945815','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=7','',''),
('8','4','1','悦丝汀-医用修复敷料套装','','0','悦丝汀-医用修复敷料套装,医用耗材全国','','41','0','http://www.kdzyg.com/file/upload/201910/02/000408751.jpg.thumb.jpg','','','','admin','1','1591198129','2019-10-02','0','0','DESTOON B2B网站管理系统','0','0','姓名','','','','','','','','','','适用范围：1.日常护肤长期管理肌底温和补水、锁水，高效保湿，抗皱滋养，使肌肤呈现细腻水润状态。2.皮肤疾病辅助治疗用于红斑、','','','','','','','admin','1569945848','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=8','',''),
('9','4','1','脐比克（儿科液体敷料）','','0','脐比克（儿科液体敷料）,医用耗材全国','','38','0','http://www.kdzyg.com/file/upload/201910/02/000449871.jpg.thumb.jpg','','','','93323988932','6','1591198144','2019-10-02','0','0','济南涵康医疗器械有限公司','0','0','张先生','13969177723','','','山东省济南市历城区华龙路2号科技城大厦501室','','','','','','[产品特点]1、脐部抗菌护理产品，具有良好的防止脐部创口感染的作用。2、本品无刺激感，无疼痛感、保护婴幼儿稚嫩的肌肤。3、内','','','','','','','admin','1569945898','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=9','',''),
('10','4','1','生物光素功能性热敷贴','','0','生物光素功能性热敷贴,医用耗材全国','','40','0','http://www.kdzyg.com/file/upload/201910/02/000523181.jpg.thumb.jpg','','','','92732832','7','1591198194','2019-10-02','0','0','广州市安辅健医疗器械有限公司','2','0','周','020-29830688','','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','','','','产品名称：生物光素热敷贴贴覆各部位疼痛处使用，具有一定的辅助消炎、镇痛功效。医保收费编码：烫熨治疗：470000013穴位贴敷治','','','','','','','admin','1569945931','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=10','',''),
('11','5','1','中医定向透药治疗仪','','0','中医定向透药治疗仪,医疗设备全国','','37','0','','','','','91872822412','7','1591198226','2019-10-02','0','0','江苏海智生物医药有限公司','2','0','何','025-68750823','','','南京市高新开发区星火路10号，鼎业百泰生物大楼C座3楼','','','','','','产品介绍合正多功能数码治疗仪是依托美国丰得利国际产业集团前沿的电子信息科技，由广州丰得利实业公司携手中国中医研究院的专家','','','','','','','admin','1569945985','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=11','',''),
('12','5','1','头戴式手术摄像系统','','0','头戴式手术摄像系统,医疗设备全国','','38','0','http://www.kdzyg.com/file/upload/201910/02/000744961.jpg.thumb.jpg','','','','37237712','7','1591198280','2019-10-02','0','0','太原市怀诚医疗器械有限公司','2','0','李小姐','0351-3389929','','','山西省太原市阳曲县东黄水镇故县村(314省道路南)','','','','','','','','','','','','','admin','1569946075','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=12','',''),
('13','5','1','PT训练床（电动升降、可折叠）','','0','PT训练床（电动升降、可折叠）,医疗设备全国','','38','0','http://www.kdzyg.com/file/upload/201910/02/000917581.jpg.thumb.jpg','','','','92732832','7','1591198370','2019-10-02','0','0','广州市安辅健医疗器械有限公司','2','0','周','020-29830688','','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','','','','产品编号：DC-06产品型号：DC-06产品规格：210*77*45-82cm销售方向：各级医疗单位，康复中心销售科室：康复科，神经内，外科，儿','','','','','','','admin','1569946168','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=13','',''),
('14','5','1','医用红外热成像仪（移动型）TMT9000B','','0','医用红外热成像仪（移动型）TMT9000B,医疗设备全国','','39','0','http://www.kdzyg.com/file/upload/201910/02/001022791.jpg.thumb.jpg','','','','92732832','7','1591198463','2019-10-02','0','0','广州市安辅健医疗器械有限公司','2','0','周','020-29830688','','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','','','','红外热成像技术应用于医学领域已经有几十年的时间了。早在1913年美国就成立了研究红外热成像的学术机构，并开始运用于临床；1977','','','','','','','admin','1569946235','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=14','',''),
('15','7','1','智能艾灸-任脉灸','','0','智能艾灸-任脉灸,家用器械全国','','40','0','http://www.kdzyg.com/file/upload/201910/02/001204901.jpg.thumb.jpg','','','','92732832','7','1591198530','2019-10-02','0','0','广州市安辅健医疗器械有限公司','2','0','周','020-29830688','','','广州市荔湾区花湾路638-680号A1A2栋336。营销分部：广州市海珠区晓港东路晓阳街18号102、','','','','','','产品名称：智能艾灸-任脉灸品牌名称：一真堂产品介绍：适应病症:1.内科病症:感冒、头痛、失眠、腹泻、慢性支气管炎、哮喘、呃逆','','','','','','','admin','1569946331','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=15','',''),
('16','7','1','吸负电疗仪','','0','吸负电疗仪,家用器械全国','','49','0','http://www.kdzyg.com/file/upload/201910/02/001241731.jpg.thumb.jpg','','','','a238128822','7','1591198626','2019-10-02','0','0','南昌华康医疗科技有限公司','2','0','张先生','0791-85297776','','','江西省南昌市小蓝工业园玉湖路8号','','','','','','点穴原理：点穴疗法集针灸、按摩、开穴的优势作用于相关经穴使阻塞的经穴瞬间打通，有效的疏通了人体的经穴，同时并引起肌肉的收','','','','','','','admin','1569946376','2019-10-02','182.148.91.176','','3','0','0','show.php?itemid=16','','');
DROP TABLE IF EXISTS  `destoon_info_data_22`;
CREATE TABLE `destoon_info_data_22` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='招商内容';

insert into `destoon_info_data_22`(`itemid`,`content`) values
('1','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;"><strong style="margin: 0px; padding: 0px;">DynaMesh&reg;-&nbsp;</strong></span><strong style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">PR\\PR2\\PR4 &nbsp; &nbsp; 专为盆底器官脱垂编织PVDF材质盆底补片</strong>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">本品适用于支撑和稳定相连组织结构和韧带，具体应用于子宫脱垂、直肠脱垂、 膀胱膨出等。 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br style="margin: 0px; padding: 0px;" />
对应科室：妇科、泌尿外科<br style="margin: 0px; padding: 0px;" />
</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">DynaMesh&reg; 高品质</strong><strong style="margin: 0px; padding: 0px;">产品保证</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">第一</strong><strong style="margin: 0px; padding: 0px;">个品质</strong><strong style="margin: 0px; padding: 0px;">保证是PVDF材质的丝线：</strong>一种富有优越&ldquo;自然&rdquo;性能的单纤丝线。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">第二个品质</strong><strong style="margin: 0px; padding: 0px;">证是</strong><strong style="margin: 0px; padding: 0px;">经编针织出的纺织结构：</strong>DynaMesh&reg; 的产品都是以*经编针织织成，而不是机织或传统的针织方法。该技术与众不同的是，它能在同一补片结构内的不同位置改变编织的形状和结构，从而调整该补片在不同位置的性能。补片因此能更准确地适应特定的指征要求。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">■ &nbsp;采用了新型惰性材料：聚偏二氟乙烯( PVDF）</strong><br style="margin: 0px; padding: 0px;" />
聚偏二氟乙烯( PVDF）具有优秀的力学性能。有数据表明，植入人体7年后，聚偏二氟乙烯力学强度仅损失7%，而聚丙烯材料力学强度损失了40%。临床研究表明：聚偏二氟乙烯( PVDF）材料有减少异物反应，减少细菌的粘附，大幅度减低聚丙烯网片感染、对组织侵蚀等风险，使病人更安全舒适。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">■ &nbsp;先进的编织工艺，使补片拥有优秀的性能</b><br style="margin: 0px; padding: 0px;" />
1、 &nbsp;有效孔隙率达59.7%，允许组织通过，避免疤痕块形成，病人舒适度高。<br style="margin: 0px; padding: 0px;" />
2、 &nbsp;补片具有形状高稳定性和低弹性，且不会发生卷曲，使植入更稳固。<br style="margin: 0px; padding: 0px;" />
3、网片边缘是编织的，避免创伤人体组织，非裁切成形。有利于在人体组织拉动和定位而不刺激周围组织。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">DynaMesh&reg;-&nbsp;</strong><strong style="margin: 0px; padding: 0px;">PR&nbsp;</strong><strong style="margin: 0px; padding: 0px;">对于子宫脱垂的手术治疗</strong><br style="margin: 0px; padding: 0px;" />
使用开放或腹腔镜技术的阴道顶端补片修补。补片长度恒久稳定，不受拉伸, 压迫或皱缩影响</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">DynaMesh&reg;-&nbsp;</strong><strong style="margin: 0px; padding: 0px;">PR2<strong style="margin: 0px; padding: 0px;">&nbsp;</strong></strong><strong style="margin: 0px; padding: 0px;">对于直肠膨出的手术治疗</strong><br style="margin: 0px; padding: 0px;" />
补片体积降到更小意味着更低的异物反应，因而只有轻微的补片皱缩</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">DynaMesh&reg;-&nbsp;</strong><strong style="margin: 0px; padding: 0px;">PR4&nbsp;</strong><strong style="margin: 0px; padding: 0px;">对于直肠膨出的手术治疗</strong><br style="margin: 0px; padding: 0px;" />
补片体积降到更小意味着更低的异物反应，因而只有轻微的补片皱缩</p>'),
('2','&nbsp;<strong style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">产品名称：一体式数字皮肤镜</strong>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">产品型号：</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">主体：Miss Horus Scope DSC100&nbsp; 镜头：Miss Horus Scope DDC100</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">主体：Miss Horus+</span>&nbsp;Scope DSC200P&nbsp; 镜头：Miss Horus Scope DDC100/<span style="margin: 0px; padding: 0px;">Miss Horus Scope DDC200</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">一体式皮肤镜包含：</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">①便携式皮肤镜</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">②专用台车（液压连杆可升降）</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">③24</span><span style="margin: 0px; padding: 0px;">英寸液晶显示器</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">④高性能miniPC</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">⑤SA-1</span><span style="margin: 0px; padding: 0px;">（专用软件）</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">⑥罗技无线鼠标</span><span style="margin: 0px; padding: 0px;">-键盘</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><img src="https://static.3618med.com/resources/eg/vp/acvdvcuctkumjmjlmrjblqjb.jpg" width="300" height="450" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-size: 9px;">图片仅供参考</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">产品优势：</strong></p>
<ul style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; list-style: none; color: rgb(51, 51, 51);">
    <li style="margin: 0px; padding: 0px;">真皮抑或表皮，冷色抑或暖色，各种检查，一镜在手，可诸事无忧</li>
    <li style="margin: 0px; padding: 0px;">提升巡诊质量及效率，即使地处偏远，也可得心应手使用</li>
    <li style="margin: 0px; padding: 0px;">数字技术完成对影响或视频资料的采集，储存及处理，极大限度减少文书工作</li>
</ul>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">产品案例：</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><img src="https://static.3618med.com/resources/5n/73/jypgbmsddtnqpthkntvvyjla.png" width="762" height="549" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">产品参数：</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><img src="https://static.3618med.com/resources/g7/3u/qeackewqjmtkntnngddtbnjd.png" width="649" height="463" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>'),
('3','&nbsp;<span style="color: rgb(3, 86, 166); font-size: 15px; font-weight: bold; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">一、应用范围：</span>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">用于急慢性软组织损伤、骨关节炎及神经性疼痛,如软组织运动损伤、腰椎间盘突出、肩周炎、颈背脊筋膜炎、颈椎病、膝关节病、网球肘、腱鞘炎、糖尿病周围神经病变、糖尿病足、带状疱疹、烧烫伤、伤口感染防治、术后伤口愈合、压疮、乳腺炎、盆腔炎、附件炎、周围性面瘫、落枕、带状疱疹后遗神经痛、颞颌关节紊乱、偏头痛、缺血性脑病。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><br style="margin: 0px; padding: 0px;" />
<span style="margin: 0px; padding: 0px; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">二、适用科室：</span><br style="margin: 0px; padding: 0px;" />
疼痛科、康复医学科、外科、骨伤科、中医针灸科、神经内科、耳鼻喉科、皮肤科、烧伤科、男科、妇（产）科、肛肠科、内分泌科等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><br style="margin: 0px; padding: 0px;" />
<span style="margin: 0px; padding: 0px; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">三、禁忌症：</span><br style="margin: 0px; padding: 0px;" />
恶性肿瘤、眼睛、甲状腺、孕妇腹部等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><br style="margin: 0px; padding: 0px;" />
<span style="margin: 0px; padding: 0px; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">四、优势特点：</span><br style="margin: 0px; padding: 0px;" />
<strong style="margin: 0px; padding: 0px;">1、半导体激光疗法：</strong><br style="margin: 0px; padding: 0px;" />
又称低能量激光疗法或低功率激光疗法，英文简称：Low Level Laser Therapy，LLLT，采用纯正砷化镓半导体激光器（非LED灯），发出波长为810nm纳米的红外激光，透射深度7cm厘米以上，可直接作用于人体深浅部组织和有效穴位痛点，产生一系列生物刺激效应，调节人体的免疫系统、神经系统、血液循环系统和组织代谢系统的病理生理状态，快速镇痛消炎，改善血液循环，减轻水肿，促进细胞再生和伤口愈合，调节神经和免疫功能。<br style="margin: 0px; padding: 0px;" />
<strong style="margin: 0px; padding: 0px;">2、运用自主创新的振荡式智能控制技术（OICT）：</strong><br style="margin: 0px; padding: 0px;" />
基于多参数变量模型，高低功率振荡转换，更好地发挥半导体激光的多重治疗作用，增强疗效，治疗安全防灼伤，患者依从度好，临床操作简单！该技术已获得国家发明专利（专利号：ZL201410196162.7），具有很高的临床应用和医学研究价值。</p>
<p class="MsoNormal" align="center" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; text-align: center;"><b style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; color: rgb(0, 51, 153);"><img src="https://static.3618med.com/resources/qb/53/jcbeputfkywqwryjycnpwyff.png" width="500" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></span></b></p>
<p class="MsoNormal" align="center" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; text-align: center;">&nbsp;</p>
<div align="center" style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">&nbsp;</div>
<span style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">五、治疗方法：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1、A型点治疗头（激光针）：</strong><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">垂直贴近神经节、神经干、神经根、痛点、穴位进行治疗。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">采用振荡治疗模式，每部位5～10分钟，每天1次，10次为一疗程。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">振荡输出功率为：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(1) 若以镇痛止痛、消炎消肿为主，可以调整振荡低端功率为100mW，振荡高端功率为400mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(2) 若以组织修复调节免疫巩固治疗为主，调整振荡低端功率为0mW，振荡高端功率为300mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(3) 若两者兼顾，则可以调整振荡低端功率为0mW，振荡高端功率为500mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(4) 如果用A型点照射治疗头治疗鼻炎、中耳炎等患部，建议振荡低端功率为0mW，振荡高端功率为100mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<img src="https://static.3618med.com/resources/c5/58/brfmuuwhdwcwkvexwdfxnacg.png" alt="" width="273" height="205" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" /><strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;"><br style="margin: 0px; padding: 0px;" />
2、C型、F型面治疗头：</strong><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">垂直对准病灶区域进行治疗，距离2～5厘米。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">采用振荡治疗模式，每部位5～10分钟，每天1次，10次为一疗程。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">振荡输出功率为：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(1) 若以镇痛止痛、消炎消肿为主，可以调整振荡低端功率为300mW，振荡高端功率为500mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(2) 若以组织修复调节免疫巩固治疗为主，调整振荡低端功率为100mW，振荡高端功率为400mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">(3) 若两者兼顾，则可以调整振荡低端功率为0mW，振荡高端功率为500mW。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<img src="https://static.3618med.com/resources/5k/yv/mxubhbqtxyntjrxhdcayjabh.png" alt="" width="444" height="202" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" /><strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;"><br style="margin: 0px; padding: 0px;" />
3、关于疗程：</strong><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">具体疗程由医生根据患者治疗情况确定，如需增加疗程，应间隔3～5天。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">每次治疗时间不宜过长。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<span style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">六、脑病康复应用介绍：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1、脑性瘫痪：</strong><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">采用A型点治疗头，振荡治疗模式，垂直照射夹脊穴或双下肢的环跳、阳陵泉、委中穴，调整振荡低端功率为100mW，振荡高端功率为400mW，每次5～10分钟，每日1次，10次一个疗程，可增加颈总动脉血流量、源于副交感神经的高频率成分，以及屈肌肉放电。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">2、缺血性脑病：</strong><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">采用A型点治疗头，振荡治疗模式，垂直照射甲状软骨上缘平行的颈总动脉处，调整振荡低端功率为0mW，振荡高端功率为300mW，每次5～10分钟，每日1次，10次一个疗程，彩色经颅多普勒超声、脑地形图各项指标均有明显改善，血流速度加快，脑功能改善。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<span style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">七、糖尿病周围神经病变、糖尿病足应用介绍：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1、采用C型或F型面治疗头，垂直照射病灶部位，距离2～5厘米，振荡治疗模式，调整振荡低端功率为200mW，振荡高端功率为500mW，每次5～10分钟，每日1次，10次一个疗程。可显著改善肢体末梢循环，促进组织生长修复，溃疡愈合，减轻溃疡面的炎症反应，加速细胞的代谢，对糖尿病足溃疡具有良好的辅助治疗效果。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">2、禁忌：急性化脓性疾病、血液病患者、出血倾向者。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">3、如需增加疗程，巩固治疗，疗程间隔5天。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<span style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(3, 86, 166); font-size: 15px; font-weight: bold;">八、面神经炎（面瘫）应用介绍：</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1、急性期常用抗病毒药，如阿昔洛韦，加营养神经药物。同时采用A型点治疗头，垂直照射以下全部或部分穴位进行治疗，刺激穴位、疏风通络、活血化瘀、增强免疫功能。振荡治疗模式，振荡低端功率为0mW，振荡高端功率为300mW，治疗10～15分钟，坚持每天一次，10次一个疗程。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">可选穴位：患侧风池、翳风、颊车、地仓、阳白、四白、太冲、健侧合谷等。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">2、如需增加疗程，巩固治疗，疗程间隔5天。</span>'),
('4','&nbsp;<span style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 18px;">床报告显示：壳聚糖具有良好的吸附性，进入阴道后，可吸附于阴道壁形成保护膜，持久作用。对细菌、白色念珠菌、病毒、滴虫等多种致病微生物均有明显的抑制和杀灭效果对细菌、念珠菌引起的阴道病及其重复性感染、混合性感染疗效尤其显著。并有促进宫颈糜烂的愈合和止血止痛的作用。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 18px;">深度透化治疗作用下将专用的菲尔茵医用敷料阴道修复液雾化成直径1-5&mu;m的雾状颗粒，使其达到离子状态在病灶部位进行深部超声雾化导入可迅速渗透粘膜达病灶组织，起到深层快速杀菌消炎作用并阻断病原体DNA转录复制，形成抗菌保护膜达到长效抑菌的目的，促进伤口愈合、滋养修复粘膜等多种功效。是传统单一治疗技术疗效的十至十五倍！无耐药性，从而达到标本兼治的目的！</span>'),
('5','&nbsp;<img src="https://static.3618med.com/resources/d9/7d/gbkjhnycaeusuvbuxspfbnfh.jpg" width="750" height="1047" alt="" style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px; border: 0px; max-width: 858px;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><img src="https://static.3618med.com/resources/hc/89/rxltpxkhlxhkjwuxtlstmwwg.jpg" width="750" height="1023" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<div class="clear" style="margin: 0px; padding: 0px; clear: both; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">&nbsp;</div>
<span class="f-db f-tac" style="margin: 15px 0px 0px; padding: 0px; display: block; text-align: center; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">更多</span>'),
('6','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 28pt; margin: 0px; padding: 0px;">工作原理；</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 28pt; margin: 0px; padding: 0px;">产后康复治疗仪是一项新兴的产后恢复治疗技术，它主要是利用低频脉冲，对产妇产后乳房、卵巢、子宫、盆底、阴道、形体等变化进行全面而主动的健康恢复治疗</span>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 28pt;"><span style="margin: 0px; padding: 0px;">功能；</span><span style="margin: 0px; padding: 0px;">催乳的常规治疗、</span><span style="margin: 0px; padding: 0px;">子宫</span><span style="margin: 0px; padding: 0px;">复旧、子宫脱垂及产后恢复治疗、体形恢复治疗，产后、术后尿潴留治疗、手术镇痛及术后恢复治疗、盆腔炎的常规治疗、乳汁分泌少、乳腺管不通、乳腺小叶增生等项目。</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;">&nbsp;</p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;">一、催乳；<span style="margin: 0px; padding: 0px;">通过乳房电极使乳房内部产生机械震荡及旋转运动，并带动乳头产生婴儿吸吮效果，其强度是婴儿吸吮的</span>5-10<span style="margin: 0px; padding: 0px;">倍，同时调节内分泌，改善局部血液循环，有效地促进产妇内垂体泌乳素和催产素的分泌，使奶涨提前，减少哺乳时的痛苦。乳汁分泌提前</span><span style="margin: 0px; padding: 0px;">8-10</span><span style="margin: 0px; padding: 0px;">小时，分泌量增多。乳腺管疏通，乳汁淤积减少，剖腹产效果更加明显。复旧活化乳房，减少乳房疾病的产生，并使</span>乳房<span style="margin: 0px; padding: 0px;">坚挺，减轻乳房下坠。</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;" />
</b></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;">二</b><b style="margin: 0px; padding: 0px;">、</b><b style="margin: 0px; padding: 0px;">产后、术后尿潴留治疗</b><b style="margin: 0px; padding: 0px;">；</b><span style="margin: 0px; padding: 0px;">产后、术后由于心理、麻醉、疼痛及体位等因素的改变极易形成尿潴留。本仪器可促使腰骶部盆腔肌肉和筋膜产生规律性运动，带动膀胱肌肉节律运动，解除膀胱肌麻痹，改善局部血液循环，减轻膀胱充血水肿，促进膀胱收缩功能复原，恢复自主排尿。</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;" />
</b></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;">三</b><b style="margin: 0px; padding: 0px;">、</b><b style="margin: 0px; padding: 0px;">子宫复旧及产后恢复治疗</b><b style="margin: 0px; padding: 0px;">；</b><span style="margin: 0px; padding: 0px;">通过腹部电极作用于产妇骶尾部，促使盆腔</span>肌肉<span style="margin: 0px; padding: 0px;">收缩，筋膜张力增强，带动子宫韧带运动，消除盆腔淤血，减少产后出血，促进恶露排出，加速子宫复旧。促进肠蠕动，改善局部血液循环，调整内脏植物神经系统，促进肠排气、排便，促进子宫收缩，宫底下降，减轻产后疲劳，缓解腰酸背痛，排气时间平均提前</span>10-20<span style="margin: 0px; padding: 0px;">小时，恢复正常饮食早，保证了产妇的充足营养，体力恢复快，预防肠粘连和产后便秘，同时对盆底组织恢复和减轻产后会阴肿胀、侧切疼痛及产后痔疮有一定疗效。</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;" />
</b></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><b style="margin: 0px; padding: 0px;">四</b><b style="margin: 0px; padding: 0px;">、</b><b style="margin: 0px; padding: 0px;">手术镇痛及术后</b><b style="margin: 0px; padding: 0px;">形体</b><b style="margin: 0px; padding: 0px;">恢复治疗</b><b style="margin: 0px; padding: 0px;">；</b><span style="margin: 0px; padding: 0px;">手术镇痛</span>:<span style="margin: 0px; padding: 0px;">仪器由微电脑程序控制对手术者骶部皮表层产生刺激，干扰会阴部神经的传输，使痛感传输被阻断，疼痛被抑制</span><span style="margin: 0px; padding: 0px;">;</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;"><span style="margin: 0px; padding: 0px;">术后恢复</span>:<span style="margin: 0px; padding: 0px;">由微电脑程序控制仪器，使盆底组织产生收缩运动，从而带动子宫韧带运动，促进子宫收缩，加强毛细血管收缩，改善局部血液循环。</span></p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;">&nbsp;</p>
<p class="p" style="margin: 0px 0px 0px 0pt; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 21pt;">五、<b style="margin: 0px; padding: 0px;">盆腔炎常规治疗</b><b style="margin: 0px; padding: 0px;">；</b><span style="margin: 0px; padding: 0px;">腹部手术促排气</span>:<span style="margin: 0px; padding: 0px;">有效地促进肠蠕动，改善局部血液循环，调整内脏植物神经系统，促进肠排气。慢性盆腔炎</span><span style="margin: 0px; padding: 0px;">:</span><span style="margin: 0px; padding: 0px;">促进患者盆腔局部血液循环，改善组织的营养状态，提高新陈代谢，有利于腔内的炎症吸收。</span></p>
<div><span style="margin: 0px; padding: 0px;"><br />
</span></div>'),
('7','&nbsp;<strong style="color: rgb(51, 51, 51); margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">一、产品名称：</strong>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;"><strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);">液基寄生虫检测处理试剂盒</span></strong>是一款针对人体内</span><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">36</span><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">种寄生虫筛查的液基检测耗材。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">湖北泰康同俄罗斯联邦知名寄生虫专家斯大利金.瓦季母教授合作，成功研发出了第三代寄生虫检查技术液基寄生虫。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">目前与之配套的特殊染色已授理发明专利，并可多收费用50元左右</span><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">，回报高，空间大。</span><br style="margin: 0px; padding: 0px;" />
</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><img src="https://static.3618med.com/resources/cl/49/jgbxwjqyfedtxcgbmbxxatup.jpg" title="液基寄生虫检测处理试剂盒发明" alt="液基寄生虫检测处理试剂盒发明" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;"><strong style="margin: 0px; padding: 0px;">二、产品规格参数：</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;"><span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);"><strong style="margin: 0px; padding: 0px;">液基寄生虫检测处理试剂盒</strong></span>由湖北泰康特制的寄生虫处理试剂保存液、寄生虫染色液和申请单等组成。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:="">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: 16px;">三、产品应用范围：</span></strong></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;"><strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);">液基寄生虫检测处理试剂盒</span></strong>多用于人和动物粪便标本收集、寄生虫卵保存、运输、集卵、制片、染色、检测。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:="">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;"><strong style="margin: 0px; padding: 0px;">四、产品性能特点：</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">湖北泰康<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);">液基寄生虫检测处理试剂盒</span></strong>多用于人和动物粪便标本收集、寄生虫卵保存、运输、集卵、制片、染色、检测。制片理念先进：液基寄生虫检测试剂，解决所有检验问题</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">一瓶多能、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">检查广泛、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">高效集卵</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">室温储存、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">单一铲匙、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">一种试剂</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">操作简单、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">轻松制片、</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">结果准确</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:="">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;"><strong style="margin: 0px; padding: 0px;">五、<span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);">液基寄生虫检测处理试剂盒</span>简介：</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">液基寄生虫是用液基细胞学原理检测粪便等样本中的寄生虫技术，样本在处理试剂中被快速降解并稀释为溶液，寄生虫与卵细胞新活地分离出来，通过发明专利染色技术，色彩艳丽的寄生虫卵，在镜下一目了然。不仅提高了粪便涂片的质量、可读性、阳性率，而且没有臭味，检验人员适从度高，因而可广泛应用于所有肠道寄生虫感染的检测。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:="">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;"><strong style="margin: 0px; padding: 0px;">六、液基寄生虫染色液：</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-size: 16px; font-family: SimHei;">寄生虫大多未染色，如需染色为长久涂片染色或卢戈氏碘染液，不能充分显现各种寄生虫，效果不理想。湖北泰康通过大量实验，成功开发了一种专用于寄生虫的特殊染色液，方法简便快速，一种染液，一滴染色，固定和染色合二为一，染色力强、色彩丰富、着色清晰、形态完整、易于辨别、检出率高，能在一张片子上观察各类寄生虫卵：包括常见的原虫类和蠕虫类多项检查。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:="">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;"><strong style="margin: 0px; padding: 0px;">七、液基寄生虫检测处理试剂盒实拍展示</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><img src="https://static.3618med.com/resources/he/t7/tuuxahvkpsgdppgemsgqftqk.jpg" title="液基寄生虫检测耗材" alt="液基寄生虫检测耗材" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;"><strong style="margin: 0px; padding: 0px;">八、联系湖北泰康</strong></span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: " microsoft="" color:="" text-indent:=""><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">湖北泰康医疗设备有限公司是专业生产<strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);">液基细胞学</span></strong>和<span style="margin: 0px; padding: 0px; color: rgb(229, 51, 51);"><strong style="margin: 0px; padding: 0px;">病理组织学</strong></span>产品的高科技企业，成立于2004年，位于湖北省孝感市高新技术开发区内，占地面积30</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">亩，首期投资</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">4600</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">万元，完成</span><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;">1.2万平方米医用科研园区建设，建成了符合ISO9001和ISO13485的质量管理体系。公司主营产品包括液基细胞学和病理组织学两大类医用产品及耗材，液基细胞学类包括液基妇科和液基非妇科，产品涵盖业内几乎所有高中低档、全科室液基细胞学品种。</span></p>
<div><span style="margin: 0px; padding: 0px; font-family: SimHei; font-size: 16px;"><br />
</span></div>'),
('8','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">适用范围：</span>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">1.&nbsp;<span style="margin: 0px; padding: 0px;">日常护肤长期管理</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">肌底温和补水、锁水，高效保湿，抗皱滋养，使肌肤呈现细腻水润状态。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">2.<span style="margin: 0px; padding: 0px;">皮肤疾病辅助治疗</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">用于红斑、瘙痒、敏感、激素型皮炎等病理性肌肤的辅助治疗及问题性肌肤养护。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">3.<span style="margin: 0px; padding: 0px;">手术伤口、烧烫伤等护理</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">各种手术（如微整型）伤口护理，烧烫伤后期养护，可促进表皮新生，加速愈合，预防疤痕生成。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">4.<span style="margin: 0px; padding: 0px;">医美项目修复</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">医美术前强韧，提高肌肤抵抗；医美术中搭配，高效嫩肤；医美术后修复，缓解不适。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">产品功效：</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">超强补水锁水</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">结合水分子超强补水，形成网状结构实现超强锁水功能。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">快速渗透吸收</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">纳诺透明质酸</span>+<span style="margin: 0px; padding: 0px;">脂溶性神经酰胺都可以快速的渗透皮肤中。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">修复皮肤屏障功能</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">透明质酸及神经酰胺补充，修复受损的皮肤屏障，保证皮肤屏障功能的完善。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">促进创伤面的愈合</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">HA<span style="margin: 0px; padding: 0px;">具有上皮下基底膜样作用，使上皮细胞得以顺利移行，促进伤口的愈合。</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">增强机体免疫力</span></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px;">神经酰胺及其代谢物信号，可以调节自身防御系统并且还可以调节皮肤中的炎症反应。</span></p>'),
('9','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">[产品特点]</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1、脐部抗菌护理产品，具有良好的防止脐部创口感染的作用。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">2、本品无刺激感，无疼痛感、保护婴幼儿稚嫩的肌肤。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">3、内含多肽、卡波姆、谷物提取物组合成抗抑菌产品，形成隐形的物理阻菌保护层，起到隔离、抑菌、防感染的作用。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">4、可替代抗菌产品的全新隔离预防感染产品，并无耐药性，无刺激，安全方便。</p>'),
('10','&nbsp;<b style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">产品名称</b><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">：</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">&ldquo;生物光素热敷贴&rdquo;</span>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">贴覆各部位疼痛处使用，具有一定的辅助消炎、镇痛功效。</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><b style="margin: 0px; padding: 0px;">医保收费编码：</b></p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="margin: 0px; padding: 0px;">烫熨治疗：</span>470000013</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="margin: 0px; padding: 0px;">穴位贴敷治疗：</span>430000023</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="margin: 0px; padding: 0px;">隔物灸疗法：</span>440000002</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="margin: 0px; padding: 0px;">贴敷疗法：</span>410000001</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><b style="margin: 0px; padding: 0px;">产品</b><b style="margin: 0px; padding: 0px;">结构</b>：产品由基材（医用级高分子材料或无纺布）、生物光素复合医用材料组成。</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><b style="margin: 0px; padding: 0px;">产品性能：</b></p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="margin: 0px; padding: 0px;">生物复合医用材料能发出与人体红外波长相近的</span>5-25微米红外光，可促进局部血液循环，能使患者的多肽曲线上升，组织携氧量增加，有缓解肌肉痉挛、减低肌张力及消炎、止痛等功效；同时复合医用材料具有改善局部细胞活性，修复局部组织细胞的损伤作用，对软组织损伤，神经血管受压，植物神经功能紊乱、局部循环障碍等引起的疼痛有一定效果，可作为医学临床治疗的辅助疗法。</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><b style="margin: 0px; padding: 0px;">适用范固</b>：该产品用于热敷，适用于辅助治疗因损伤引起的肌肉、韧带、筋膜的疼痛和因肾虚引起的胃痛、胃寒等症状。贴覆各部位疼痛患处使用，具有一定的辅助消炎、镇痛功效。</p>
<p class="p" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><b style="margin: 0px; padding: 0px;">应用科室：</b>中医科、骨科、理疗科、老年科、康复科、针灸科、妇科等多科室；</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">产品型号：</b><b style="margin: 0px; padding: 0px;">YGF&mdash;TJ。注解：YG（远光），F（类别），TJ（贴剂）</b></p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">产品规格：</b>TJ（贴剂）尺寸：由医用级硅胶或无纺布为基材制作的不规则椭圆型。</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">注意事项</b><span style="margin: 0px; padding: 0px;">：</span>1、该产品是功能性产品，请在医生指导下使用；</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">使用说明</b>：使用时生物光素面点贴向肌肤。</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">禁忌症</b>：该产品的材料组合在目前，通过临床实验，尚未发现有相对的禁忌症。</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">产品维修</b>：产品出现生产质量问题由厂家负责调换。</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">储存方法</b>：常温、干燥处保存。</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">执行标准</b><span style="margin: 0px; padding: 0px;">：</span>YZB/陕0093-2014《功能性热敷贴》</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">生产许可证</b><span style="margin: 0px; padding: 0px;">：陕食药监械生产许</span>20150068号</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">医疗器械注册证</b><span style="margin: 0px; padding: 0px;">：陕食药监械（准）字</span>2014第2260073号</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">注册企业</b>：陕西远光高科技有限公司</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">注册地址</b><span style="margin: 0px; padding: 0px;">：中国</span>-西安市雁翔路99号西安交大国家大学科技园博源大厦</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">生产地址：</b><span style="margin: 0px; padding: 0px;">中国</span>-西安市田马路西二街5号</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">招商政策</b><span style="margin: 0px; padding: 0px;">：及时提供货源，确保全国范围内</span>2~10天内到货，实行区域代理单一制，确保运作者权益；提供合理的运作空间，确保投入与产出成正比；我公司会持续稳定给予代理商全面的服务工作；完成任务年终返点；提供合法的经营手续；</p>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><b style="margin: 0px; padding: 0px;">代理要求：</b><span style="margin: 0px; padding: 0px;">有丰富的市场及医院临床操作经验，较强的市场开发能力；有良好的商业信誉；有通畅的市场渠道；有成熟完善的销售网络；</span>&nbsp;<span style="margin: 0px; padding: 0px;">有较强的责任心和信心；有终端</span>(OTC,RX)推广能力；有长期合作的决心；有一定的经济实力；</p>'),
('11','&nbsp;<strong style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;"><strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: 24px;">产品介绍</span></strong></strong>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;"><span style="margin: 0px; padding: 0px; font-size: 18px;">合正多功能数码治疗仪是依托美国丰得利国际产业集团前沿的电子信息科技，由广州丰得利实业公司携手中国中医研究院的专家经过12年努力研制而成，产品有外观、实用新型发明等多项国家专利，并获得2011年广东省科技厅、省发改委等6部委认定为2011年自主创新品牌.主机采用美国FOUNDERY数字芯片，治疗效果经南方医院广州军区总医院临床试验，对多种疾病有明显的治疗效果。产品集生物电疗、药物导入、激光导、超声波导入为一体，已获得国家多项专利（专利号有如下：20111018466.0、201310166770.9、ZL201310469965.0)、同时获得国家计算机软件著作权登记证证书。证书号：(软著登字1205649号）。</span></strong></p>
<strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">产品功能：</strong>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">1.LED大屏操作界面，屏幕不闪，保护视力</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">2.符合人体工体学设计，使用简单、方便</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">3.语音导航系统，操作简单</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">4.使用关机重启后，电流模式自动切换到出厂状态，安全可靠</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">5.每种处方有24种不同强度，具有延时关机保护功能</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">6.强大离子导入、超声波治疗、650mm激光治疗、中频治疗、磁热疗</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">7.强大的4路中医透药独立控制输出、及独立的超声导入、中医封包、激光输出</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">8.正弦波、方波、指数波、三角波、等幅波、调制波、组合波等多个波形</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;"><br style="margin: 0px; padding: 0px;" />
</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">产品优势：</strong></p>
<strong style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">1.治疗仪配有一次性治疗电极，治疗电极为本公司的专利产品，专利证号：201110180466.0<br style="margin: 0px; padding: 0px;" />
2.可进医院多科室，仪器赠送（借用），不需招标，快速开发医院<br style="margin: 0px; padding: 0px;" />
3.医保报销治疗项目，可适用多种收费目录<br style="margin: 0px; padding: 0px;" />
4.&nbsp;产品已做临床，治疗效果明显<br style="margin: 0px; padding: 0px;" />
5.科室创收，效益大增，各科室乐意接受<br style="margin: 0px; padding: 0px;" />
6.工厂直接招商，无中间环节利润更大，市场保护更完善<br style="margin: 0px; padding: 0px;" />
7.投资门槛低，仪器从2.98～6.98万元不等，代商不足万元做代理<br style="margin: 0px; padding: 0px;" />
8.符合医药改革经营方向和国家政策趋势。<br style="margin: 0px; padding: 0px;" />
</strong>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;">根据现代人体生物电磁理论，结合传统中医经络学、药物学、现代医学理论，采用新的微电脑芯片数字处理技术，并辅以磁场药物离子导入技术、穴位疗技术、远红外、热敷法，根据不同的病情在芯片上设置不同的治疗输出信号，通过电磁信号刺激，激发人体组织机能的活力，提高人体新陈代谢、排除病痛，达到快速治疗和恢复人体健康的作用。</strong></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><strong style="margin: 0px; padding: 0px;"><img src="https://static.3618med.com/resources/xp/ex/eumyjussbwxrsjmnlxderxrj.jpg" width="840" height="560" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /><img src="https://static.3618med.com/resources/f6/8r/tqfndauqvprgedenxlkkylyp.jpg" width="832" height="501" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></strong></p>'),
('12',''),
('13','<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">产品编号：DC-06&nbsp;</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">产品型号：DC-06</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">产品规格：210*77*45-82cm</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">销售方向：各级医疗单位，康复中心</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">销售科室：康复科，神经内，外科，儿科，康复中心</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-family: &quot;font-size:16px;background-color:#FFFFFF;&quot;;">治疗师对患者进行PT治疗时，训练床可满足治疗师不同要求</span>。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-family: &quot;font-size:16px;background-color:#FFFFFF;&quot;;">友情提示：</span></p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><span style="margin: 0px; padding: 0px; font-family: &quot;font-size:16px;background-color:#FFFFFF;&quot;;">1.PT训练床（电动升降、可折叠）产品的使用和维护方法可参阅说明书或致电渡康医疗售后服务部</span></p>'),
('14','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">红外热成像技术应用于医学领域已经有几十年的时间了。早在</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;1913&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">年美国就成立了研究红外热成像的学术机构，并开始运用于临床；</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">1977&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">年世界上已经有</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;75&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">个医疗机构用热像仪来诊断疾病；从</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;80&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">年代到</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;90&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">年代世界各国的红外热成像会议无论数量还是规模都不断提升，范围也更广，许多发达国家相继研制了多种专供医用的红外热成像仪，比如美国的医学家利用红外热成像仪来研究肿瘤的早期诊断，尤其是在乳腺癌的早期诊断方面取得了很好的效果。如美国费城爱因斯坦医学院的爱萨德医生，他用红外热成像仪检查了数以万计的妇女的乳腺癌，准确率达到</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;92</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">％，证明它比</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">&nbsp;X&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">光要好。日本医学家利用红外热成像仪监测皮肤以确定冻伤、烧伤的面积。不仅如此，在其他的诊断应用上，如甲状腺疾病、睾丸疾病以及颈、肩、腰、腿痛等方面积累很多的经验。红外热成像仪对心脑血管疾病的观察为医生提供了很好的诊断依据。红外热成像技术在我国起步较晚，</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; margin: 0px; padding: 0px;">70&nbsp;</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">年代末国内有个别的大医院和学术机构开始引进红外热成像仪用于医学临床研究，并且发表了远红外在医疗方面运用许多文章，自此以后医用红外发展就加快了。随着医用红外热像仪的不断普及和人们对红外热成像技术认识的不断加深，红外热成像仪对于人体健康状态检测和评估的优势逐渐凸显出来，加上其检测过程中的无辐射、无创、无痛等诸多优势，越来越多的医疗机构、体检机构、健康管理机构等开始使用医用红外热成像仪开启人们对身体功能状态的检测、评估以及对重大疾病的早期预警和筛查。</span>
<p class="MsoNormal" style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><u style="margin: 0px; padding: 0px;">TMT红外热成像的特点:<br style="margin: 0px; padding: 0px;" />
</u></p>
<p style="margin: 0px 0px 0px 0cm; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">1、全面：<span style="margin: 0px; padding: 0px;">TMT</span>红外热成像检查， 可以为受检者从头到脚全身的扫描和评估； 通过红外热成像仪对人体进行全面扫描，将人体体表温度情况用伪色彩图显示出来，专业医生可以结合临床对患者全身情况进行全面系统的分析，克服了其他诊断技术局限于某个局部的片面性。现在应用红外热成像技术已经能够检测炎症、肿瘤、结石、血管性疾病、神经系统疾病等<span style="margin: 0px; padding: 0px;">&nbsp;100&nbsp;</span>余种常见病和多发病，涉及人体各个系统；能检查全身各系统的亚健康、亚临床以至于疾病状态的很多不同程度的问题，相当于一次全身&ldquo;健康精算&rdquo;。</p>
<p style="margin: 0px 0px 0px 0cm; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: -22.3pt;">2、安全：<span style="margin: 0px; padding: 0px;">TMT</span>红外热成像是安全、绿色的检测<span style="margin: 0px; padding: 0px;">,</span>&emsp;对人没有任何伤害；许多影像学仪器或多或少对人体都有不同程度的伤害，而红外热成像诊断不会产生任何射线，无需标记药物，是通过红外探测器接收人体发出的红外辐射并转换成伪色彩图像来判断疾病，因此，对人体不会造成任何伤害，对环境不会造成任何污染，</p>
<p style="margin: 0px 0px 0px 0cm; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">而且简便经济。红外热像技术实现了人类追求绿色健康的梦想，人们形象地将该技术称为&ldquo;绿色体检&rdquo;。</p>
<p style="margin: 0px 0px 0px 0cm; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: -22.3pt;">3、灵敏：<span style="margin: 0px; padding: 0px;">TMT</span>红外热成像检查是在细胞代谢水平上的功能检测，可以补充临床检测的盲区，与<span style="margin: 0px; padding: 0px;">&nbsp;X&nbsp;</span>光、<span style="margin: 0px; padding: 0px;">B&nbsp;</span>超、<span style="margin: 0px; padding: 0px;">CT&nbsp;</span>等影像技术相比，红外热成像检测重要的一个优势就是早期预警。<span style="margin: 0px; padding: 0px;">X&nbsp;</span>光、<span style="margin: 0px; padding: 0px;">B&nbsp;</span>超、<span style="margin: 0px; padding: 0px;">CT&nbsp;</span>等技术虽各具特点，但它们都属于结构影像技术，只有在疾病形成病灶之后才能发现疾病，而疾病在出现组织结构和形态变化之前，细胞代谢会发生异常，人体会发生温度的改变，温度的高低、温场的形状、温差的大小可反映疾病的部位、性质和程度。红外热成像技术主要是功能状态的影像技术，是根据人体温度的异常来发现疾病，因此能够在机体只有功能障碍，尚没有明显组织结构异常的情况下解读出潜在的隐患，早地发现问题。有资料显示，远红外热图比结构影像可提前半年乃至更早发现病变，为疾病的早期发现与防治赢得宝贵的时间，帮助你早发现、早治疗、使你防病于未然。</p>'),
('15','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">产品名称：智能艾灸-任脉灸</span>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">品牌名称：一真堂</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">产品介绍：</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">适应病症:</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">1.内科病症:感冒、头痛、失眠、腹泻、慢性支气管炎、哮喘、呃逆、慢性胃炎、胃下垂、关节炎、冠心病、中风、面瘫、抑郁症、阳痿、早泄、不孕不育症等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">2.外科病症:颈椎病、腰椎病、骨关节病、前列腺炎、血栓性浅静脉炎、腹股沟斜疝、乳腺增生病等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">3.皮肤病症:带状疱疹、斑秃、冻疮、神经性皮炎、寻常疣、黄褐斑等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">4.妇产科病症:子宫脱垂、习惯性流产、外阴白色病变、胎位不正、功能性子宫出血、痛经、慢性盆腔炎等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">5.儿科病症:脑积水、流行性腮腺炎、婴幼儿腹泻、小儿厌食症、小儿遗尿症等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">6.五官科病症:近视眼、麦粒肿、单纯性慢性青光眼、老年性白内障、过敏性鼻炎、萎缩性鼻炎、急性扁桃体炎、内耳眩晕症、复发性口疮等。</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">7.保健、抗衰老、抗疲劳等。</p>
<div style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">&nbsp;</div>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;">&nbsp;</p>
<p style="margin: 0px; padding: 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; color: rgb(51, 51, 51); text-indent: 0px;"><img src="https://static.3618med.com/resources/k4/3n/ldbvwgnstbqaraqtanrwtvmj.jpg" width="800" height="1141" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /><img src="https://static.3618med.com/resources/xp/s5/bahshtasdngccwwvkxveecps.jpg" width="800" height="879" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /><img src="https://static.3618med.com/resources/e7/xx/gesrmpxaxgxnlejeqmxsskjd.jpg" width="800" height="1068" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /><img src="https://static.3618med.com/resources/mt/nf/hkfbkkffdwfpfescuprlnlkt.jpg" width="800" height="1342" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /><img src="https://static.3618med.com/resources/me/9r/xgxmkxywxwaffcdsgwgfvjnp.jpg" width="800" height="908" alt="" style="margin: 0px; padding: 0px; border: 0px; max-width: 858px;" /></p>
<div>&nbsp;</div>
<div class="clear" style="margin: 0px; padding: 0px; clear: both; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">&nbsp;</div>'),
('16','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">点穴原理：点穴疗法集针灸、按摩、开穴的优势作用于相关经穴使阻塞的经穴瞬间打通，有效的疏通了人体的经穴，同时并引起肌肉的收缩和挤压，有效的调节生物电和新陈代谢过程。人体能量激活后，自发调理人体自身功能，调和气血，存储能量以达到调理身体，留住青春。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">2、疏通经络：利用激活人体的能量来激发经气，疏通经络，达到&ldquo;通则不痛&rdquo;，同时产生更多的能量。</span><br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<br style="margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;" />
<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial;">3、兴奋神经：可引起中枢神经，感觉神经，运动神经和植物神经的兴奋和抑制，提高神经，恢复知觉，提高神经自律性，头痛，三叉神经，周围性神经麻痹见效快。能量的激活可引起神经组织兴奋使脑啡呔增多，产生镇痛作用，适应于治疗各种疼痛症，能使经络畅通，使局部的血液循环改善，炎症物质的吸收和运走加速，吞噬作用活跃，免疫功能提高。</span>');
DROP TABLE IF EXISTS  `destoon_job_9`;
CREATE TABLE `destoon_job_9` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `department` varchar(100) NOT NULL DEFAULT '',
  `total` smallint(4) unsigned NOT NULL DEFAULT '0',
  `minsalary` int(10) unsigned NOT NULL DEFAULT '0',
  `maxsalary` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `marriage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `education` smallint(2) unsigned NOT NULL DEFAULT '0',
  `experience` smallint(2) unsigned NOT NULL DEFAULT '0',
  `minage` smallint(2) unsigned NOT NULL DEFAULT '0',
  `maxage` smallint(2) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL,
  `apply` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `editdate` (`editdate`,`vip`,`edittime`),
  KEY `edittime` (`edittime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='招聘';

DROP TABLE IF EXISTS  `destoon_job_apply_9`;
CREATE TABLE `destoon_job_apply_9` (
  `applyid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `jobid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `resumeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `job_username` varchar(30) NOT NULL DEFAULT '',
  `apply_username` varchar(30) NOT NULL DEFAULT '',
  `applytime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`applyid`),
  KEY `job_username` (`job_username`),
  KEY `apply_username` (`apply_username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应聘工作';

DROP TABLE IF EXISTS  `destoon_job_data_9`;
CREATE TABLE `destoon_job_data_9` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='招聘内容';

DROP TABLE IF EXISTS  `destoon_job_resume_9`;
CREATE TABLE `destoon_job_resume_9` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `age` smallint(2) unsigned NOT NULL DEFAULT '0',
  `marriage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `height` smallint(2) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(2) unsigned NOT NULL DEFAULT '0',
  `education` smallint(2) unsigned NOT NULL DEFAULT '0',
  `school` varchar(100) NOT NULL DEFAULT '',
  `major` varchar(100) NOT NULL DEFAULT '',
  `skill` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(255) NOT NULL DEFAULT '',
  `minsalary` int(10) unsigned NOT NULL DEFAULT '0',
  `maxsalary` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `experience` smallint(2) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `situation` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `open` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `edittime` (`edittime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='简历';

DROP TABLE IF EXISTS  `destoon_job_resume_data_9`;
CREATE TABLE `destoon_job_resume_data_9` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='简历内容';

DROP TABLE IF EXISTS  `destoon_job_talent_9`;
CREATE TABLE `destoon_job_talent_9` (
  `talentid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `resumeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `jointime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`talentid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='人才库';

DROP TABLE IF EXISTS  `destoon_keylink`;
CREATE TABLE `destoon_keylink` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `item` varchar(20) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='关联链接';

DROP TABLE IF EXISTS  `destoon_keyword`;
CREATE TABLE `destoon_keyword` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` smallint(6) NOT NULL DEFAULT '0',
  `word` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `letter` varchar(255) NOT NULL DEFAULT '',
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `total_search` int(10) unsigned NOT NULL DEFAULT '0',
  `month_search` int(10) unsigned NOT NULL DEFAULT '0',
  `week_search` int(10) unsigned NOT NULL DEFAULT '0',
  `today_search` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '3',
  PRIMARY KEY (`itemid`),
  KEY `moduleid` (`moduleid`),
  KEY `word` (`word`),
  KEY `letter` (`letter`),
  KEY `keyword` (`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='关键词';

DROP TABLE IF EXISTS  `destoon_know_10`;
CREATE TABLE `destoon_know_10` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `credit` int(10) unsigned NOT NULL DEFAULT '0',
  `aid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `process` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addition` mediumtext NOT NULL,
  `comment` mediumtext NOT NULL,
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `raise` int(10) unsigned NOT NULL DEFAULT '0',
  `agree` int(10) unsigned NOT NULL DEFAULT '0',
  `against` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `ask` varchar(30) NOT NULL,
  `expert` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='知道';

DROP TABLE IF EXISTS  `destoon_know_answer_10`;
CREATE TABLE `destoon_know_answer_10` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `qid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `vote` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `expert` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `qid` (`qid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='知道回答';

DROP TABLE IF EXISTS  `destoon_know_data_10`;
CREATE TABLE `destoon_know_data_10` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='知道内容';

DROP TABLE IF EXISTS  `destoon_know_expert_10`;
CREATE TABLE `destoon_know_expert_10` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `style` varchar(50) NOT NULL DEFAULT '',
  `major` varchar(255) NOT NULL,
  `ask` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `best` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='知道专家';

DROP TABLE IF EXISTS  `destoon_know_vote_10`;
CREATE TABLE `destoon_know_vote_10` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `qid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `aid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='知道投票';

DROP TABLE IF EXISTS  `destoon_link`;
CREATE TABLE `destoon_link` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='友情链接';

insert into `destoon_link`(`itemid`,`typeid`,`areaid`,`title`,`style`,`thumb`,`introduce`,`username`,`addtime`,`editor`,`edittime`,`listorder`,`level`,`status`,`linkurl`) values
('1','0','0','DESTOON B2B','','http://static.destoon.com/logo.gif','DESTOON B2B网站管理系统','','1569851008','admin','1569851008','0','1','3','http://www.destoon.com/');
DROP TABLE IF EXISTS  `destoon_login`;
CREATE TABLE `destoon_login` (
  `logid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `passsalt` varchar(8) NOT NULL,
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(50) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `message` varchar(255) NOT NULL DEFAULT '',
  `agent` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`logid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='登录日志';

DROP TABLE IF EXISTS  `destoon_mail`;
CREATE TABLE `destoon_mail` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `sendtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邮件订阅';

DROP TABLE IF EXISTS  `destoon_mail_list`;
CREATE TABLE `destoon_mail_list` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `typeids` varchar(255) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订阅列表';

DROP TABLE IF EXISTS  `destoon_mail_log`;
CREATE TABLE `destoon_mail_log` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邮件记录';

DROP TABLE IF EXISTS  `destoon_mall_16`;
CREATE TABLE `destoon_mall_16` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `mycatid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `elite` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `brand` varchar(100) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `step` mediumtext NOT NULL,
  `amount` int(10) unsigned NOT NULL DEFAULT '0',
  `unit` varchar(20) NOT NULL,
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `orders` int(10) unsigned NOT NULL DEFAULT '0',
  `sales` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `thumb1` varchar(255) NOT NULL DEFAULT '',
  `thumb2` varchar(255) NOT NULL DEFAULT '',
  `thumbs` text NOT NULL,
  `relate_name` varchar(100) NOT NULL,
  `relate_id` varchar(255) NOT NULL,
  `relate_title` varchar(100) NOT NULL,
  `n1` varchar(100) NOT NULL,
  `n2` varchar(100) NOT NULL,
  `n3` varchar(100) NOT NULL,
  `v1` varchar(255) NOT NULL,
  `v2` varchar(255) NOT NULL,
  `v3` varchar(255) NOT NULL,
  `express_1` int(10) unsigned NOT NULL DEFAULT '0',
  `express_name_1` varchar(100) NOT NULL,
  `fee_start_1` decimal(10,2) unsigned NOT NULL,
  `fee_step_1` decimal(10,2) unsigned NOT NULL,
  `express_2` int(10) unsigned NOT NULL DEFAULT '0',
  `express_name_2` varchar(100) NOT NULL,
  `fee_start_2` decimal(10,2) unsigned NOT NULL,
  `fee_step_2` decimal(10,2) unsigned NOT NULL,
  `express_3` int(10) unsigned NOT NULL DEFAULT '0',
  `express_name_3` varchar(100) NOT NULL,
  `fee_start_3` decimal(10,2) unsigned NOT NULL,
  `fee_step_3` decimal(10,2) unsigned NOT NULL,
  `cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `editdate` (`editdate`,`vip`,`edittime`),
  KEY `catid` (`catid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商城';

DROP TABLE IF EXISTS  `destoon_mall_comment_16`;
CREATE TABLE `destoon_mall_comment_16` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mallid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `buyer` varchar(30) NOT NULL DEFAULT '',
  `seller` varchar(30) NOT NULL DEFAULT '',
  `buyer_star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `buyer_comment` text NOT NULL,
  `buyer_ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `buyer_reply` text NOT NULL,
  `buyer_rtime` int(10) unsigned NOT NULL DEFAULT '0',
  `seller_star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `seller_comment` text NOT NULL,
  `seller_ctime` int(10) unsigned NOT NULL DEFAULT '0',
  `seller_reply` text NOT NULL,
  `seller_rtime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `itemid` (`itemid`),
  KEY `buyer` (`buyer`),
  KEY `seller` (`seller`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单评论';

DROP TABLE IF EXISTS  `destoon_mall_data_16`;
CREATE TABLE `destoon_mall_data_16` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='商城内容';

DROP TABLE IF EXISTS  `destoon_mall_express_16`;
CREATE TABLE `destoon_mall_express_16` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `express` varchar(30) NOT NULL,
  `fee_start` decimal(10,2) unsigned NOT NULL,
  `fee_step` decimal(10,2) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='运费模板';

DROP TABLE IF EXISTS  `destoon_mall_stat_16`;
CREATE TABLE `destoon_mall_stat_16` (
  `mallid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `seller` varchar(30) NOT NULL DEFAULT '',
  `scomment` int(10) unsigned NOT NULL DEFAULT '0',
  `s1` int(10) unsigned NOT NULL DEFAULT '0',
  `s2` int(10) unsigned NOT NULL DEFAULT '0',
  `s3` int(10) unsigned NOT NULL DEFAULT '0',
  `buyer` varchar(30) NOT NULL DEFAULT '',
  `bcomment` int(10) unsigned NOT NULL DEFAULT '0',
  `b1` int(10) unsigned NOT NULL DEFAULT '0',
  `b2` int(10) unsigned NOT NULL DEFAULT '0',
  `b3` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `mallid` (`mallid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评分统计';

DROP TABLE IF EXISTS  `destoon_mall_view_16`;
CREATE TABLE `destoon_mall_view_16` (
  `uid` varchar(50) NOT NULL,
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `seller` varchar(30) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `uid` (`uid`),
  KEY `username` (`username`),
  KEY `lasttime` (`lasttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='浏览历史';

DROP TABLE IF EXISTS  `destoon_member`;
CREATE TABLE `destoon_member` (
  `userid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `passport` varchar(30) NOT NULL DEFAULT '',
  `company` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `passsalt` varchar(8) NOT NULL,
  `payword` varchar(32) NOT NULL DEFAULT '',
  `paysalt` varchar(8) NOT NULL,
  `email` varchar(50) NOT NULL DEFAULT '',
  `message` smallint(6) unsigned NOT NULL DEFAULT '0',
  `chat` smallint(6) unsigned NOT NULL DEFAULT '0',
  `sound` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `avatar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `truename` varchar(20) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `wxqr` varchar(255) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `department` varchar(30) NOT NULL DEFAULT '',
  `career` varchar(30) NOT NULL DEFAULT '',
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role` varchar(255) NOT NULL DEFAULT '',
  `aid` int(10) unsigned NOT NULL DEFAULT '0',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '4',
  `regid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `sms` int(10) NOT NULL DEFAULT '0',
  `credit` int(10) NOT NULL DEFAULT '0',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deposit` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` varchar(50) NOT NULL DEFAULT '',
  `regtime` int(10) unsigned NOT NULL DEFAULT '0',
  `loginip` varchar(50) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `logintimes` int(10) unsigned NOT NULL DEFAULT '1',
  `send` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `vemail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vmobile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vtruename` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vbank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vcompany` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vtrade` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `trade` varchar(50) NOT NULL DEFAULT '',
  `support` varchar(50) NOT NULL DEFAULT '',
  `inviter` varchar(30) NOT NULL DEFAULT '',
  `note` text NOT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `passport` (`passport`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='会员';

insert into `destoon_member`(`userid`,`username`,`passport`,`company`,`password`,`passsalt`,`payword`,`paysalt`,`email`,`message`,`chat`,`sound`,`online`,`avatar`,`gender`,`truename`,`mobile`,`qq`,`wx`,`wxqr`,`ali`,`skype`,`department`,`career`,`admin`,`role`,`aid`,`groupid`,`regid`,`areaid`,`sms`,`credit`,`money`,`deposit`,`edittime`,`regip`,`regtime`,`loginip`,`logintime`,`logintimes`,`send`,`vemail`,`vmobile`,`vtruename`,`vbank`,`vcompany`,`vtrade`,`trade`,`support`,`inviter`,`note`) values
('1','admin','admin','DESTOON B2B网站管理系统','bb1aad6621657f367db7662ef7484b32','abcd1234','cfd007a8d389dd248caa1280a1ade6a9','bCykaNbU','mail@yourdomain.com','0','0','0','0','1','1','姓名','','','','','','','','','1','','0','1','6','1','0','33',0.00,0.00,'1445261241','182.148.91.176','1569851008','122.234.13.59','1592551361','15','1','1','1','1','0','0','0','','','',''),
('2','a238128821','a238128821','湖北肽尔生物医疗科技有限公司','9e2049f9b6d2020af107c9747f0e4ea9','aLXz0YhY','bcf2005c0d4584cefc0ef6e6cde1010c','BR2N9NlQ','31212321@qq.com','1','0','1','1','0','1','张','','','','','','','','','0','','0','7','6','2','0','8',0.00,0.00,'1569942085','182.148.91.176','1569942085','182.148.91.176','1569942085','1','1','0','0','0','0','0','0','','','a238128821',''),
('3','a238128824','a238128824','南京瑞普森生物科技有限公司','fbd2fa8b5cee9307617196ea26836d31','OEGSipga','72f7b54561d7fce03e8976eecbe1c50a','LY0jpEAB','a238128822@qq.com','1','0','1','1','0','1','李小姐','','','','','','','','','0','','0','7','6','3','0','14',0.00,0.00,'1569942240','182.148.91.176','1569942240','182.148.91.176','1569942240','1','1','0','0','0','0','0','0','','','a238128824',''),
('4','a238128822','a238128822','南昌华康医疗科技有限公司','96f04e642d366f95f702f0087c50a65d','3AdiKiT0','43f9e8b930570a1882e7cbf838fc538f','X7UTtTa7','a238128824@qq.com','1','0','1','1','0','1','张先生','','','','','','','','','0','','0','7','6','4','0','12',0.00,0.00,'1569942490','182.148.91.176','1569942490','182.148.91.176','1569942490','1','1','0','0','0','0','0','0','','','a238128822',''),
('5','9282733','9282733','北京格润来福医药科技有限公司','19fee436ae8a3a83b7469ba37ffad575','S8qIN4Kh','0457e5cb1b0845ce7d77a4845b994731','JoEFLyo8','22123@qq.com','1','0','1','1','0','1','张先生','','','','','','','','','0','','0','7','6','6','0','6',0.00,0.00,'1569942651','182.148.91.176','1569942651','182.148.91.176','1569942651','1','1','0','0','0','0','0','0','','','9282733',''),
('6','37237712','37237712','太原市怀诚医疗器械有限公司','ed5b88c3774402e0e6399d2a99b5f8c2','3GDsTlBx','ec3aa4ede8fd12cb80c89398d439e532','6iFFHEKL','37237712@qq.com','1','0','1','1','0','2','李小姐','','','','','','','','','0','','0','7','6','5','0','6',0.00,0.00,'1569942742','182.148.91.176','1569942742','182.148.91.176','1569942742','1','1','0','0','0','0','0','0','','','37237712',''),
('7','82378238','82378238','武汉安士泰医疗科技有限公司','84cf7a6398c68a8447838792caaf983f','6q7HW9yb','5ab8ae562f4009eb273eabd80116311d','JK3VE1fL','82378238@qq.com','1','0','1','1','0','1','王先生','','','','','','','','','0','','0','7','6','6','0','2',0.00,0.00,'1569942851','182.148.91.176','1569942851','182.148.91.176','1569942851','1','1','0','0','0','0','0','0','','','82378238',''),
('8','91872822412','91872822412','江苏海智生物医药有限公司','82458a506315f496744dc0b6d485ec3a','clG63DJz','4b992192d45587132b5317926797f4ba','KzaQOhJb','91872822412@qq.com','1','0','1','1','0','1','何','','','','','','','','','0','','0','7','6','8','0','4',0.00,0.00,'1569942937','182.148.91.176','1569942937','182.148.91.176','1569942937','1','1','0','0','0','0','0','0','','','91872822412',''),
('9','92732832','92732832','广州市安辅健医疗器械有限公司','e293f34310b9dd14716b028a973220d3','9OKxKFGH','45e82a3e8c7b1967be71e49bcfc23e39','7MFb0pLN','92732832@qq.com','1','0','1','1','0','1','周','','','','','','','','','0','','0','7','6','10','0','5',0.00,0.00,'1569943026','182.148.91.176','1569943026','182.148.91.176','1569943026','1','1','0','0','0','0','0','0','','','92732832',''),
('10','93323988932','93323988932','济南涵康医疗器械有限公司','81b43213bb50e0fefc02fb604ef96d31','WefHxlW8','395a92a5fa1fdd6688830885b3392595','RHb65InQ','221231221@qq.com','1','0','1','1','0','1','张先生','','','','','','','','','0','','0','6','6','9','0','8',0.00,0.00,'1569944310','182.148.91.176','1569944310','182.148.91.176','1569944310','1','1','0','0','0','0','0','0','','','93323988932','');
DROP TABLE IF EXISTS  `destoon_member_check`;
CREATE TABLE `destoon_member_check` (
  `userid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员资料审核';

DROP TABLE IF EXISTS  `destoon_member_group`;
CREATE TABLE `destoon_member_group` (
  `groupid` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='会员组';

insert into `destoon_member_group`(`groupid`,`groupname`,`vip`,`listorder`) values
('1','管理员','0','1'),
('2','禁止访问','0','2'),
('3','游客','0','3'),
('4','待审核会员','0','4'),
('5','个人会员','0','5'),
('6','企业会员','0','6'),
('7','VIP会员','1','7');
DROP TABLE IF EXISTS  `destoon_member_misc`;
CREATE TABLE `destoon_member_misc` (
  `userid` bigint(20) unsigned NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `bank` varchar(30) NOT NULL DEFAULT '',
  `banktype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `branch` varchar(100) NOT NULL,
  `account` varchar(30) NOT NULL DEFAULT '',
  `reply` text NOT NULL,
  `black` text NOT NULL,
  `send` tinyint(1) unsigned NOT NULL DEFAULT '1',
  UNIQUE KEY `userid` (`userid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员杂项';

insert into `destoon_member_misc`(`userid`,`username`,`bank`,`banktype`,`branch`,`account`,`reply`,`black`,`send`) values
('1','admin','','0','','','','','1'),
('2','a238128821','','0','','','','','1'),
('3','a238128824','','0','','','','','1'),
('4','a238128822','','0','','','','','1'),
('5','9282733','','0','','','','','1'),
('6','37237712','','0','','','','','1'),
('7','82378238','','0','','','','','1'),
('8','91872822412','','0','','','','','1'),
('9','92732832','','0','','','','','1'),
('10','93323988932','','0','','','','','1');
DROP TABLE IF EXISTS  `destoon_message`;
CREATE TABLE `destoon_message` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `typeid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `fromuser` varchar(30) NOT NULL DEFAULT '',
  `touser` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `isread` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `feedback` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `groupids` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `touser` (`touser`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='站内信件';

insert into `destoon_message`(`itemid`,`title`,`style`,`typeid`,`content`,`fromuser`,`touser`,`addtime`,`ip`,`isread`,`issend`,`feedback`,`status`,`groupids`) values
('1','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>a238128821<br/>
<strong>密码：</strong>a238128821<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','a238128821','1569942085','182.148.91.176','0','0','0','3',''),
('2','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>a238128824<br/>
<strong>密码：</strong>a238128824<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','a238128824','1569942240','182.148.91.176','0','0','0','3',''),
('3','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>a238128822<br/>
<strong>密码：</strong>a238128822<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','a238128822','1569942490','182.148.91.176','0','0','0','3',''),
('4','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>9282733<br/>
<strong>密码：</strong>a9282733<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','9282733','1569942651','182.148.91.176','0','0','0','3',''),
('5','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>37237712<br/>
<strong>密码：</strong>a37237712<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','37237712','1569942742','182.148.91.176','0','0','0','3',''),
('6','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>82378238<br/>
<strong>密码：</strong>a82378238<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','82378238','1569942851','182.148.91.176','0','0','0','3',''),
('7','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>91872822412<br/>
<strong>密码：</strong>a91872822412<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','91872822412','1569942937','182.148.91.176','0','0','0','3',''),
('8','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>92732832<br/>
<strong>密码：</strong>a92732832<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','92732832','1569943026','182.148.91.176','0','0','0','3',''),
('9','欢迎加入纯购医疗器械网','','4','<table cellpadding="0" cellspacing="0" width="700" align="center">
<tr>
<td><a href="http://qingchuangjie.gotoip2.com/" target="_blank"><img src="http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg" style="margin:10px 0;border:none;" alt="纯购医疗器械网 LOGO" title="纯购医疗器械网"/></a></td>
</tr>
<tr>
<td style="border-top:solid 1px #DDDDDD;border-bottom:solid 1px #DDDDDD;padding:10px 0;line-height:200%;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:14px;color:#333333;">
尊敬的会员：<br/>
恭喜您成功注册成为纯购医疗器械网会员！<br/>
以下为您的会员帐号信息：<br/>
<strong>户名：</strong>93323988932<br/>
<strong>密码：</strong>a93323988932<br/>
请您妥善保存，切勿告诉他人。<br/>
如果您在使用过程中遇到任何问题，欢迎随时与我们取得联系。<br/>
</td>
</tr>
<tr>
<td style="line-height:22px;padding:10px 0;font-family:\'Microsoft YaHei\',Verdana,Arial;font-size:12px;color:#666666;">
请注意：此邮件系 <a href="http://qingchuangjie.gotoip2.com/" target="_blank" style="color:#005590;">纯购医疗器械网</a> 自动发送，请勿直接回复。如果此邮件不是您请求的，请忽略并删除
</td>
</tr>
</table>','','93323988932','1569944310','182.148.91.176','0','0','0','3','');
DROP TABLE IF EXISTS  `destoon_module`;
CREATE TABLE `destoon_module` (
  `moduleid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(20) NOT NULL DEFAULT '',
  `moduledir` varchar(20) NOT NULL DEFAULT '',
  `domain` varchar(255) NOT NULL DEFAULT '',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isblank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `logo` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `installtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='模型';

insert into `destoon_module`(`moduleid`,`module`,`name`,`moduledir`,`domain`,`mobile`,`linkurl`,`style`,`listorder`,`islink`,`ismenu`,`isblank`,`logo`,`disabled`,`installtime`) values
('1','destoon','核心','','','','http://www.mengdigua.com/','','1','0','0','0','0','0','1569851008'),
('2','member','会员','member','','','http://www.mengdigua.com/member/','','2','0','0','0','0','0','1569851008'),
('3','extend','扩展','extend','','','http://www.mengdigua.com/extend/','','0','0','0','0','0','0','1569851008'),
('4','company','热门企业','company','','','http://www.mengdigua.com/company/','','7','0','1','0','0','0','1569851008'),
('6','buy','药品信息','buy','','','http://www.mengdigua.com/buy/','','6','0','1','0','0','0','1569851008'),
('7','quote','市场行情','quote','','','http://www.mengdigua.com/quote/','','9','0','1','0','0','0','1569851008'),
('8','exhibit','展会信息','exhibit','','','http://www.mengdigua.com/exhibit/','','10','0','0','0','0','0','1569851008'),
('10','know','知道','know','','','http://www.mengdigua.com/know/','','15','0','0','0','0','0','1569851008'),
('11','special','专题','special','','','http://www.mengdigua.com/special/','','16','0','0','0','0','0','1569851008'),
('12','photo','图库','photo','','','http://www.mengdigua.com/photo/','','17','0','0','0','0','0','1569851008'),
('13','brand','推荐品牌','brand','','','http://www.mengdigua.com/brand/','','13','0','1','0','0','0','1569851008'),
('14','video','视频','video','','','http://www.mengdigua.com/video/','','18','0','0','0','0','0','1569851008'),
('15','down','下载','down','','','http://www.mengdigua.com/down/','','19','0','0','0','0','0','1569851008'),
('17','group','团购','group','','','http://www.mengdigua.com/group/','','8','0','0','0','0','0','1569851008'),
('18','club','商圈','club','','','http://www.mengdigua.com/club/','','20','0','0','0','0','0','1569851008'),
('21','article','资讯','news','','','http://www.mengdigua.com/news/','','11','0','0','0','0','0','1569851008'),
('22','info','医疗器械','invest','','','http://www.mengdigua.com/invest/','','12','0','1','0','0','0','1569851008');
DROP TABLE IF EXISTS  `destoon_news`;
CREATE TABLE `destoon_news` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司新闻';

DROP TABLE IF EXISTS  `destoon_news_data`;
CREATE TABLE `destoon_news_data` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司新闻内容';

DROP TABLE IF EXISTS  `destoon_oauth`;
CREATE TABLE `destoon_oauth` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `site` varchar(30) NOT NULL DEFAULT '',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `avatar` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logintimes` int(10) unsigned NOT NULL DEFAULT '0',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `site` (`site`,`openid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='一键登录';

DROP TABLE IF EXISTS  `destoon_online`;
CREATE TABLE `destoon_online` (
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `moduleid` int(10) unsigned NOT NULL DEFAULT '0',
  `online` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `lasttime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='在线会员';

DROP TABLE IF EXISTS  `destoon_order`;
CREATE TABLE `destoon_order` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` smallint(6) unsigned NOT NULL DEFAULT '16',
  `mallid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `cid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `buyer` varchar(30) NOT NULL DEFAULT '',
  `seller` varchar(30) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `number` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fee_name` varchar(30) NOT NULL DEFAULT '',
  `buyer_name` varchar(30) NOT NULL DEFAULT '',
  `buyer_address` varchar(255) NOT NULL DEFAULT '',
  `buyer_postcode` varchar(10) NOT NULL DEFAULT '',
  `buyer_mobile` varchar(30) NOT NULL DEFAULT '',
  `buyer_star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `seller_star` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `send_type` varchar(50) NOT NULL DEFAULT '',
  `send_no` varchar(50) NOT NULL DEFAULT '',
  `send_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `send_time` varchar(20) NOT NULL DEFAULT '',
  `send_days` int(10) unsigned NOT NULL DEFAULT '0',
  `cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `trade_no` varchar(50) NOT NULL DEFAULT '',
  `add_time` smallint(6) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `buyer_reason` mediumtext NOT NULL,
  `refund_reason` mediumtext NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `buyer` (`buyer`),
  KEY `seller` (`seller`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单';

DROP TABLE IF EXISTS  `destoon_page`;
CREATE TABLE `destoon_page` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司单页';

DROP TABLE IF EXISTS  `destoon_page_data`;
CREATE TABLE `destoon_page_data` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='公司单页内容';

DROP TABLE IF EXISTS  `destoon_photo_12`;
CREATE TABLE `destoon_photo_12` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `open` tinyint(1) unsigned NOT NULL DEFAULT '3',
  `password` varchar(30) NOT NULL DEFAULT '',
  `question` varchar(30) NOT NULL DEFAULT '',
  `answer` varchar(30) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图库';

DROP TABLE IF EXISTS  `destoon_photo_data_12`;
CREATE TABLE `destoon_photo_data_12` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图库内容';

DROP TABLE IF EXISTS  `destoon_photo_item_12`;
CREATE TABLE `destoon_photo_item_12` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item` bigint(20) unsigned NOT NULL DEFAULT '0',
  `introduce` text NOT NULL,
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `listorder` (`listorder`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图库图片';

DROP TABLE IF EXISTS  `destoon_poll`;
CREATE TABLE `destoon_poll` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `groupid` varchar(255) NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) unsigned NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) unsigned NOT NULL DEFAULT '0',
  `poll_max` smallint(6) unsigned NOT NULL DEFAULT '0',
  `poll_page` smallint(6) unsigned NOT NULL DEFAULT '0',
  `poll_cols` smallint(6) unsigned NOT NULL DEFAULT '0',
  `poll_order` smallint(6) unsigned NOT NULL DEFAULT '0',
  `polls` int(10) unsigned NOT NULL DEFAULT '0',
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `template_poll` varchar(30) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='票选';

DROP TABLE IF EXISTS  `destoon_poll_item`;
CREATE TABLE `destoon_poll_item` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pollid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `polls` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `pollid` (`pollid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='票选选项';

DROP TABLE IF EXISTS  `destoon_poll_record`;
CREATE TABLE `destoon_poll_record` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `pollid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `polltime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='票选记录';

DROP TABLE IF EXISTS  `destoon_question`;
CREATE TABLE `destoon_question` (
  `qid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`qid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='验证问题';

insert into `destoon_question`(`qid`,`question`,`answer`) values
('1','5+6=?','11'),
('2','7+8=?','15'),
('3','11*11=?','121'),
('4','12-5=?','7'),
('5','21-9=?','12');
DROP TABLE IF EXISTS  `destoon_quote_7`;
CREATE TABLE `destoon_quote_7` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='行情';

insert into `destoon_quote_7`(`itemid`,`catid`,`areaid`,`level`,`title`,`style`,`fee`,`introduce`,`tag`,`keyword`,`pptword`,`hits`,`comments`,`thumb`,`username`,`addtime`,`adddate`,`editor`,`edittime`,`ip`,`template`,`status`,`linkurl`,`filepath`,`note`) values
('1','14','0','1','2019年中国民营医疗行业市场现状及发展趋势分析','','0','民营医院，指经济类型为国有和集体以外的医院，包括联营、股份合作、私营、港澳台投资和外国投资等医院，是医疗体系的重要组成部','','2019年中国民营医疗行业市场现状及发展趋势分析,行情','','37','0','','admin','1569947947','2019-10-02','admin','1569947964','182.148.91.176','','3','show.php?itemid=1','',''),
('2','14','0','1','为什么手持超声设备市场将迎来大幅增长？','','0','本文译自HIT Consultant，作者西蒙哈里斯(Simon Harris)，曾任IMS Research的执行副总裁。今年是世界上首台手持超声波扫描仪GE V','','为什么手持超声设备市场将迎来大幅增长？,行情','','37','0','','admin','1569947964','2019-10-02','admin','1569947981','182.148.91.176','','3','show.php?itemid=2','',''),
('3','14','0','1','增幅超2倍！2020年我国血糖仪市场规模将破200亿','','0','血糖监测是糖尿病管理中的重要组成部分，其结果有助于评估糖尿病患者糖代谢紊乱的程度，制定合理的降糖方案，反映降糖治疗的效果','','增幅超2倍！2020年我国血糖仪市场规模将破200亿,行情','','38','0','','admin','1569947981','2019-10-02','admin','1569948001','182.148.91.176','','3','show.php?itemid=3','',''),
('4','14','0','1','脑机接口技术真的火起来了','','0','选手们头戴脑电帽，双眼紧盯电脑屏幕，搜索快速闪烁的目标字符。尽管身体纹丝不动，脑机接口技术已捕捉到他们脑电波的变化。8月2','','脑机接口技术真的火起来了,行情','','38','0','','admin','1569948001','2019-10-02','admin','1569948033','182.148.91.176','','3','show.php?itemid=4','','');
DROP TABLE IF EXISTS  `destoon_quote_data_7`;
CREATE TABLE `destoon_quote_data_7` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='行情内容';

insert into `destoon_quote_data_7`(`itemid`,`content`) values
('1','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">民营医院，指经济类型为国有和集体以外的医院，包括联营、股份合作、私营、港澳台投资和外国投资等医院，是医疗体系的重要组成部分。</span>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">近几年来，公立医院疯狂扩张，导致负债累累，民营医疗逐渐成为市场趋势。为鼓励社会办医，国家从顶层开始不断发力，逐步放开政策限制。由此，民营医疗逐渐兴盛，民营医院、诊所得到了大力发展，同时也出现了许多新兴的医疗业态，包括医生出来单干形成的&ldquo;医生集团&rdquo;，还有从医院独立出来的&ldquo;第三方独立医疗机构&rdquo;，还有依托互联网等新技术形成的&ldquo;互联网医院&rdquo;等等。这些新业态的出现，为我国医疗卫生事业注入了活力，让整个医疗生态日臻完善。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2018</span>年，国家继续沿用以往方针，放开增量市场，鼓励社会办医。<span lang="EN-US">2018</span>年<span lang="EN-US">6</span>月，国家卫生健康委员发布了《关于进一步改革完善医疗机构、医师审批工作的通知》。该通知指出，除三级医院、三级妇幼保健院、急救中心、急救站、临床检验中心、中外合资合作医疗机构、港澳台独资医疗机构外，举办其他医疗机构的，卫生健康行政部门不再核发《设置医疗机构批准书》，仅在执业登记时发放《医疗机构执业许可证》。换句话来讲，二级及以下医疗机构设置审批与执业登记将&ldquo;两证合一&rdquo;，大力推动了民办医疗结构的审批效率。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">民营医疗规模迅速发展，<span lang="EN-US">2018</span>年数量已达公立医院的<span lang="EN-US">1.65</span>倍<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">在国家的大力推动下，民营医疗快速发展，其近年来的普遍增速在<span lang="EN-US">10%</span>以上。据前瞻产业研究院发布的《中国民营医疗行业市场前瞻与投资战略规划分析报告》统计数据显示，<span lang="EN-US">2015</span>年我国民营医院数量正式超过公立医院，数量达到<span lang="EN-US">14518</span>个，此后更是拉开距离。截止至<span lang="EN-US">2017</span>年我国民营医院的数量增长至<span lang="EN-US">18759</span>个，<span lang="EN-US">2013-2017</span>年，我国民营医院年均复合增长率达到<span lang="EN-US">13.48%</span>。进入<span lang="EN-US">2018</span>年我国民营医院数量达到了<span lang="EN-US">20977</span>个，而公立医院数量仅有<span lang="EN-US">12032</span>个。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">据相关数据预测<span lang="EN-US">2019</span>年我国民营医院的数量将达<span lang="EN-US">2.32</span>万个，并预测在<span lang="EN-US">2023</span>年我国民营医院的数量将增长至<span lang="EN-US">3.59</span>万个左右，<span lang="EN-US">2019-2023</span>年均复合增长率约为<span lang="EN-US">11.53%</span>。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;<img src="https://static.3618med.com/resources/vw/8a/nellbveujtmqctpyvwddtlwh.png" width="571" height="449" alt="" style="border: 0px;" /></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2013-2018</span>年我国民营医院、公立医院数量统计情况<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">数据来源：前瞻产业研究院整理<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US"><img src="https://static.3618med.com/resources/gq/kf/wdrvvpsphxydsfcwmjesyajf.png" width="578" height="463" alt="" style="border: 0px;" />&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2019-2023</span>年我国民营医院数量统计情况及预测<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">数据来源：前瞻产业研究院整理<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">我国民营医疗行业发展痛点分析&mdash;&mdash;公众对民营医院认知度较低<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">我国公立医疗机构起步早、积累深厚，拥有良好的人才资源和政策支持，加上国有资本的背景，在市场竞争中比较容易获得患者的信赖。民营医疗机构是在公立医疗机构处于垄断地位的背景下发展起来的，起步晚、积累少、技术水平和管理水平参差不齐，加上小部分民营医疗机构缺乏诚信和自律，损害了民营医疗机构在社会上的整体形象，使得民营医疗机构较公立医疗机构难以获得患者的信任。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">近年来，医疗体制改制有序推进，民营医疗机构的开始涌现，社会公众对民营医疗机构的认知开始改观，但大多停留在服务态度好、就医环境好等方面，社会对民营医院的能力、水平等的认知度没有质的提高，这种认知的改变仍需要较长的时间和过程。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2</span>、人才资源匮乏<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">目前制约民营医院进一步发展的瓶颈是人才问题。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">一方面，民营医院的企业身份与公立医院的事业身份在众多方面存在着较大差别，基础设施、诊疗设备、技术水平等比较薄弱，导致民营医院一线医务人员绝大多数由退休人员和刚从学校毕业的人员构成，呈现&ldquo;两头大、中间小&rdquo;的&ldquo;哑铃&rdquo;型人才结构，中间骨干力量断层明显。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">另一方面，民营医院不能像公立医院那样，有事业编制、待遇、职称、晋升等优厚条件，难以招到高校毕业生，甚至一些基层医院的医生都难以引进，形不成人才梯队<span lang="EN-US">;</span>同时在医护人员的职称晋升、人员培训、发展机会方面差异明显，民营医院引进和培养自身人才方面成本高昂、人才高流动率等多种原因也让很多医院疲于招人，多数民办医院不重视人才培养，不利于医院的长远发展。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">3</span>、区域发展不平衡<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">在区域分布方面，我国民营医院集中在东部地区，<span lang="EN-US">2017</span>年共有医院数量<span lang="EN-US">7</span>，<span lang="EN-US">513</span>家，占比<span lang="EN-US">40%;</span>其次为西部地区，因公共资源不发达，给了民营医疗生长的空间，<span lang="EN-US">2017</span>年民营医院数达到<span lang="EN-US">6</span>，<span lang="EN-US">154</span>家，占比<span lang="EN-US">33%;</span>中部地区民营医院数目最少，<span lang="EN-US">2017</span>年为<span lang="EN-US">5</span>，<span lang="EN-US">092</span>家，仅占比<span lang="EN-US">27%</span>。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">在城乡分布方面，城市民营医院聚集度更高，乡镇民营医院除乡村私人诊所外，则仍以公立医院为主<span lang="EN-US">;</span>乡镇在对民营医院的扶持政策上不如城市力度大，在一定程度上也不利于乡镇民营医院的发展。在城市分布方面，民营医院的院址选择，既要和城市规划建设相联系，又要考虑到城市社区人口集聚相对集中的地段，不同城市的经济发展现状、城市建设进程或规模等一定程度上影响着民营医疗行业的发展。例如江苏、浙江、山东等城市的民营医院聚集度更高，广西、青海、宁夏等地城市的民营医院聚集度较低。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">4</span>、重收益轻管理现象<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">少数投资者将开设医疗机构作为一种短期的投资行为，一味追求利益得失，甚至不惜采取虚假宣传、夸大效果、广告轰炸等手段，使民营医院形象受损严重，降低了民营医疗机构在社会上的信誉度。一些规模较小的民办医院，质量管理人员身兼数职，有的甚至没有质量管理人员，很多质量问题得不到及时控制，各类规章制度得不到认真执行，三级医师查房、三查七对制度、疑难危重病例讨论等流于形式。民营医疗机构中存在的重收益、轻管理等现象，也在一定程度加重了市场诚信缺失的不良影响，阻碍民营医疗行业的进一步发展。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">我国民营医疗行业发展趋势分析&mdash;&mdash;利好政策形成多层次多样化医疗服务新格局<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2016</span>年<span lang="EN-US">10</span>月，《&ldquo;健康中国<span lang="EN-US">2030</span>&rdquo;规划纲要》发布，提出优先支持社会力量举办非营利性医疗机构，推进和实现非营利性民营医院与公立医院同等待遇<span lang="EN-US">;</span>鼓励医生利用业余时间、退休医生到基层医疗卫生机构执业或开设工作室<span lang="EN-US">;</span>破除社会力量进入医疗领域的不合理限制和隐性壁垒。<span lang="EN-US">2016</span>年<span lang="EN-US">12</span>月，国务院印发《&ldquo;十三五&rdquo;卫生与健康规划》，提出到<span lang="EN-US">2020</span>年，社会办医院床位占医院床位总数的比重将由<span lang="EN-US">2015</span>年的<span lang="EN-US">19.4%</span>提升至<span lang="EN-US">30%</span>以上。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2017</span>年<span lang="EN-US">5</span>月，国务院办公厅发布《国务院办公厅关于支持社会力量提供多层次多样化医疗服务的意见》，《意见》提出到<span lang="EN-US">2020</span>年，社会力量办医能力明显增强，医疗技术、服务品质、品牌美誉度显著提高，专业人才、健康保险、医药技术等支撑进一步夯实，行业发展环境全面优化。打造一大批有较强服务竞争力的社会办医疗机构，形成若干具有影响力的特色健康服务产业集聚区，服务供给基本满足国内需求，逐步形成多层次多样化医疗服务新格局。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2018</span>年<span lang="EN-US">6</span>月，国家卫健委、国家中医药管理局下发《关于进一步改革完善医疗机构、医师审批工作的通知》，《通知》指出，二级及以下医疗机构设置审批与执业登记将&ldquo;两证合一&rdquo;，卫生健康行政部门不再核发《设置医疗机构批准书》，仅在执业登记时发放《医疗机构执业许可证》，大力推动了民办医疗结构的审批效率。<span lang="EN-US">2018</span>年<span lang="EN-US">10</span>月，国家卫健委发布《<span lang="EN-US">2018-2020</span>年全国大型<a href="http://www.3618med.com/product/keywords/2933.html" title="医用设备" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">医用设备</a>配置规划》，支持非公立机构发展，将不以医疗机构等级、床位规模等业务量因素作为非公立医疗机构的主要配置标准，重点考核机构人员资质与技术服务能力等保障应用质量安全的要求。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">2</span>、分级诊疗下民营医院的发展空间<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">分级诊疗制度作为我国医疗卫生五大基本制度之一，旨在改善和优化医疗资源配置，促进基本医疗卫生服务均等化，随着分级诊疗制度的推进，大医院门诊量将会逐步缩减，患者将逐渐向基层医疗机构和民营医院流动。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据国家卫计委发布的我国各年卫生和计划生育事业发展统计公报，民营医院诊疗人次在全国医院诊疗人次中的比重逐年上升，更加表明了患者向民营医院流动的趋势，越来越多的患者会到民营医院就诊，这对于民营医疗机构而言是更大的发展机遇。且随着医疗服务行业的改革深入，医疗服务体系将进一步完善，分级诊疗模式加速形成并逐步完善，基层医疗需求快速放大<span lang="EN-US">;</span>行业生态将逐步优化，医疗服务价格改革带来的市场格局变动、资源配置转移会加快民营医院的发展，服务质量和运营能力将成为民营医院未来的竞争重点。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">3</span>、民营医院崛起<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">受限于医院数量、服务质量等多种因素，&ldquo;医院&rdquo;一直是大众谈之色变的话题，尽管公立三甲医院集合了国内优质的医学人才和医疗服务器械，但几十人的医疗团队相较于日均上万人流量的看病人群而言，显然是一种低水平的广覆盖，就医患者无法享受到高水平的一对一医疗服务，由此产生的医疗纠纷、医闹等事件也见诸各大媒体。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">不良的医疗服务对于患者和医院来说都是不利的，首先对于患者来说，病情的痛苦无法得到充分缓解，加重负面消极情绪，其次医院层面，因为患者对服务体验的不满造成了患者的流失，加重了负面的恶性循环。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">用户的就诊需求催生了民营医院的崛起，伴随着新医改等政策的颁布，一系列民营医院如雨后春笋般涌现，民营医院的出现推动了医疗服务的本质回归，通过专业细致的医疗服务，为用户提供了全面、优质的医疗体验，在一定程度上缓和了医患关系，解决了普通用户的就诊需求。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">4</span>、民营医院向高端服务市场方向发展<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">随着国家医疗体制改革的逐步推进，国家及地方政府相继发布了一系列关于鼓励多种形式、多种渠道投资发展医药卫生事业的政策措施，明确为民营医疗机构的发展提供政策扶持，支持民营资本投资开办专科医院等各种特色医疗机构，鼓励民营医疗机构提供基本医疗服务，同时引导和促进民间资本投入高端、特需服务市场，满足群众不同层次的医疗卫生服务需求。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">民营医院具有经营灵活、资本自由等优势，未来民营医院在提供基本医疗服务的同时，将逐渐进入高端、特需服务市场，以满足不同层次的医疗卫生服务需求。以美国为例，公立医院占医院总数的比例不足三分之一，公立医院主要为低收入人群提供保障性医疗服务<span lang="EN-US">;</span>私立医院主要定位于有医疗保险的普通人群，满足大部分美国人民的医疗需求，并提供主要的高端、特需医疗服务。</p>'),
('2','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">本文译自</span><span lang="EN-US" style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">HIT Consultant</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">，作者西蒙&middot;哈里斯</span><span lang="EN-US" style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">(Simon Harris)</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">，曾任</span><span lang="EN-US" style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">IMS Research</span><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">的执行副总裁。</span>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">今年是世界上首台手持超声波扫描仪<span lang="EN-US">GE Vscan</span>问世的第<span lang="EN-US">10</span>年。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">十年过去了，手持超声波扫描仪似乎并没有达到市场预期。以<span lang="EN-US">2018</span>年为例，全球<span lang="EN-US">69</span>亿美元的超声设备市场中，手持超声设备的销售额才不到<span lang="EN-US">2%</span>。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">早期发展速度缓慢，究其原因，其制约因素则是手持设备成本较高，性能有限。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">随着这些年来产品陆续的改进，以及整个市场的不断微创新，致使手持超声设备，正开始释放自身的价值。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">其中，心脏病医学家是<a href="http://www.3618med.com/product/keywords/1310.html" title="手持式" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">手持式</a>超声的早期使用群体，手持设备在诊所、查房时的床旁和介入病房中都可以作为最初的筛查工具。其他使用者则更多为急诊医生，尤其是急诊医务人员、重症监护室的重症监护人员和军人。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">随后，手持式超声在过程性超声<span lang="EN-US">(</span>包括血管通路和麻醉<span lang="EN-US">)</span>中获得了一定程度的认可，最近<span lang="EN-US">MSK</span>的专家开始在办公室检查、术中成像和现场医学中使用手持式超声。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">第一批用户：心脏病专家和传统床旁超声使用者<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">急诊医学是<span lang="EN-US">2018</span>年最大的手持超声市场，价值约<span lang="EN-US">1500</span>万美元。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">然而，这仅占当年用于急诊医疗<a href="http://www.3618med.com/product/keywords/2744.html" title="超声系统" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">超声系统</a>总销量的<span lang="EN-US">10%</span>，其中以紧凑型和车载系统占据了最大的市场份额。同样也有床旁超声<span lang="EN-US">(POCUS)</span>。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">当前趋势：以科室场景为基础<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">除了传统<span lang="EN-US">POCUS</span>市场上手持超声的使用范围不断扩大外，各种医学专业<span lang="EN-US">(</span>如泌尿科、胃肠科和血管科<span lang="EN-US">)</span>的科室医生也开始产生更多的需求。科室内的专家正在使用手持超声波进行快速检查和初步筛查，作为医院科室中更强大的车载系统辅助手段。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">不断扩大的客户群，再加上实惠的价格，使得全球手持超声的销量，在<span lang="EN-US">2019</span>年将增加<span lang="EN-US">50%</span>以上。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">然而，医院之外也有越来越多的场景使用超声波，这也随之带来了新的挑战。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">首先便是报销问题，在大多数国家，可报销的费用有限，即使在可报销的国家，科室医生通常也没有相应的上报流程，以确保体检符合账单要求。此外，认证、数据安全和质量保证问题<span lang="EN-US">(</span>用于图像获取和可解释性<span lang="EN-US">)</span>也存在一定的挑战性。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">虽然手持超声设备可能陆续被主流采用，但许多机构缺乏在办公室和医院之间提供无缝患者护理所需的<span lang="EN-US">IT</span>基础设施。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">因此，整个行业必须妥善处理和克服这些挑战，以确保护理质量，并使得手持超声充分发挥其潜力。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">下一波浪潮：初级保健医生<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">初级保健场景，很大程度上仍是手持超声尚未开发的市场，也可能是最大的机遇。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">数据统计，仅在美国就有<span lang="EN-US">25</span>万多名初级保健医生。迄今为止，初级保健医生群体使用的手持超声主要在发达国家，而近些年在低收入和中等收入国家也逐渐开始应用。在后者中，手持超声在医学成像辅助诊断方面，发挥着重要作用，其主要应用于心脏筛查、妊娠筛查和诊断呼吸和腹部疾病。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">我们也相信手持式超声将在城市初级保健中得到越来越多地应用。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">在过去的几年里，手持扫描仪的价格已经大幅下降，对许多初级保健医生来说，这是一个性价比颇高的选择。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">例如，<span lang="EN-US">Butterfly Network</span>公司在<span lang="EN-US">2018</span>年底开始推出蝴蝶智商扫描仪，售价<span lang="EN-US">1999</span>美元<span lang="EN-US">(</span>外加<span lang="EN-US">420</span>美元的年费<span lang="EN-US">)</span>。而在这之后，<span lang="EN-US">GE</span>医疗将<span lang="EN-US">Vscan</span>基本版的价格下调至<span lang="EN-US">2995</span>美元<span lang="EN-US">(</span>目前仅限美国<span lang="EN-US">)</span>。虽然价格不再是大问题，但许多初级保健医生缺乏正规的超声培训，且无法广泛获得超声报销补贴。在许多欧洲国家，全科医生必须通过认证才能获得超声波扫描的报销。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">为了解决全科医生缺乏相关使用技能的问题，手持扫描仪企业正在努力简化其操作流程，同时通过双向音频和视频通话，将新手用户与位于不同位置的专家连接起来，提供综合远程超声服务。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">最新一代的手持式扫描仪具有许多针对常见检查类型的预置，随着<span lang="EN-US">AI</span>的嵌入，使得即便没有扫描经验的医生也能够捕捉高质量的图像。由人工智能引导的超声扫描，将帮助用户识别身体部位，并正确定位换能器，最大限度地提高图像质量。人工智能还将在图像解释方面发挥越来越重要的作用，为医生提供自动化测量、异常检测和诊断决策支持。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">人工智能在超声波领域的应用虽尚处于早期阶段，但第一批解决方案正在推向市场。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">这些是支持特定检查类型解释的单点解决方案，例如用于心脏评估的自动射血分数计算。在不久的将来，我们希望看到<span lang="EN-US">AI</span>解决方案具有更广泛的功能，能够支持对身体区域的多种情况进行检测和诊断。与此同时，第一款支持人工智能的手持扫描仪在图像采集过程中有望在未来一两年上市。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px; line-height: 24px;">带有人工智能的图像采集和可解释的智能设备的出现，将推动手持式超声在初级和其他多种护理场景中得到更广泛的应用。预计到<span lang="EN-US">2023</span>年，全球手持超声市场预计将超过<span lang="EN-US">4</span>亿美元。</p>'),
('3','&nbsp;<a href="http://www.3618med.com/product/keywords/2192.html" title="血糖监测" target="_blank" class="hl-keyword" style="font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt; outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">血糖监测</a><span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">是糖尿病管理中的重要组成部分，其结果有助于评估糖尿病患者糖代谢紊乱的程度，制定合理的降糖方案，反映降糖治疗的效果并指导治疗方案的调整。</span>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">一、血糖监测系统：迭代升级，动态连续<a href="http://www.3618med.com/product/keywords/99.html" title="血糖仪" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">血糖仪</a>（<span lang="EN-US">CGM</span>）应运而生<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据《中国<span lang="EN-US">2</span>型糖尿病防治指南<span lang="EN-US">(2017</span>版<span lang="EN-US">)</span>》特别提到&ldquo;血糖监测&rdquo;，突出在糖尿病管理中的血糖监测重要作用，因此需要高效快捷确认日内血糖波动，以保障糖尿病病人有效控制率。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">自<span lang="EN-US">1968</span>年第一台血糖仪诞生以来，指血血糖仪已历经五个发展阶段，成为最为悠久、技术储备最为完善的血糖检测产品。目前，大多数血糖仪都采用电化学法技术，精准度、采血量、疼痛程度、操作和携带的便捷性上都有了极大提升。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">同一品牌、同一型号的血糖仪只能匹配相应的试条，即血糖仪和试条形成的一一对应的&ldquo;封闭系统&rdquo;。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US"><img src="https://static.3618med.com/resources/ss/vp/tuqrknseaspdumwnkksewclp.png" width="532" height="279" alt="" style="border: 0px;" />&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">图表<span lang="EN-US">1</span>：血糖仪迭代史<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">对糖尿病患者而言，目前最普遍的血糖测试设备是指血血糖仪，但指血血糖仪有一定的局限性，它只能测到患者某个时间点的瞬间血糖值，不能监测患者在运动、吃饭、睡觉时的血糖水平。为了能全面了解患者<span lang="EN-US">24</span>小时动态血糖波动，连续血糖监测系统（<span lang="EN-US">Co<em></em>ntinuous Glucose Monitoring</span>，<span lang="EN-US">CGM</span>）应运而生，即通过葡萄糖感应器监测皮下组织间液的葡萄糖浓度而间接反映血糖水平。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">连续血糖监测系统通过刺入皮下的传感器，在患者的组织液与体内葡萄糖发生氧化反应时形成电信号，电信号随之转换为血糖读数，再通过发射器到无线接收器上。因此，临床医生能够全面了解患者<span lang="EN-US">24</span>小时的血糖波动情况，必要时可配合<a href="http://www.3618med.com/product/keywords/256.html" title="胰岛素泵" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">胰岛素泵</a>给患者注射胰岛素。血糖连续监测最初应用于医院的危重病或急救监护中心，但现在已经有可用于家庭的连续血糖监测仪。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US"><img src="https://static.3618med.com/resources/hk/bc/gskcvxnhmcmssxfuynskxpve.png" width="500" height="478" alt="" style="border: 0px;" />&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">图表<span lang="EN-US">2</span>：动态连续血糖仪监测原理<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据血糖仪的检测对象及创伤程度，血糖仪分为传统指血血糖仪（<span lang="EN-US">BGM</span>）、动态连续血糖仪（<span lang="EN-US">CGM</span>）以及无创血糖仪三大类。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;<img src="https://static.3618med.com/resources/qc/uu/typfqvnecneqhrmjxhjgabsm.png" width="539" height="172" alt="" style="border: 0px;" /></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">图表<span lang="EN-US">3</span>：传统指血血糖仪、动态连续血糖仪以及无创血糖仪对比<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">二、血糖监测系统市场规模：渗透率和使用率亟待提升<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据数据显示，全球血糖监测系统市场容量达<span lang="EN-US">200</span>多亿美元，我国血糖监测系统市场规模约<span lang="EN-US">60</span>亿元。按血糖仪与<a href="http://www.3618med.com/product/keywords/1353.html" title="血糖试纸" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">血糖试纸</a>销售收入比为<span lang="EN-US">1</span>：<span lang="EN-US">4</span>来计算，目前血糖试纸销售规模约<span lang="EN-US">48</span>亿元，按照平均每条试纸均价在<span lang="EN-US">2.7</span>元<span lang="EN-US">/</span>条，则我国每年血糖试纸使用量在<span lang="EN-US">17.8</span>亿条，我国共有<span lang="EN-US">1.139</span>亿糖尿病患者，按照知晓率（诊断率）<span lang="EN-US">1/3</span>来计算，人均血糖试纸的年消耗量仅为<span lang="EN-US">47</span>条，也就是说已诊断为糖尿病的患者平均每月检<a href="http://www.3618med.com/product/keywords/2191.html" title="测血糖" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">测血糖</a>的频率尚不到<span lang="EN-US">4</span>次。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">而根据<span lang="EN-US">ADA</span>的最新指南，血糖未达标患者或治疗开始时的患者每天血糖监测次数至少为<span lang="EN-US">5</span>次，血糖已达标患者的检测次数则在<span lang="EN-US">2-4</span>次<span lang="EN-US">/</span>天，而应用胰岛素治疗的患者更是需要在正餐前、后，加餐前、后，睡前、运动前<a href="http://www.3618med.com/product/keywords/2195.html" title="检测血糖" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">检测血糖</a>水平。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据中国产业协会数据显示，目前，国内血糖仪市场份额外资占据<span lang="EN-US">60%</span>以上市场份额，其中强生约<span lang="EN-US">35%</span>，罗氏约<span lang="EN-US">20%</span>，雅培约<span lang="EN-US">8%</span>。国产品牌三诺约<span lang="EN-US">15%</span>，北京怡成约<span lang="EN-US">6%</span>，近年鱼跃医疗也逐步开始进入血糖市场。随着品牌技术差距逐步缩小、国产血糖仪价格优势明显，替代效应逐步显现。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;<img src="https://static.3618med.com/resources/ty/37/bdrggypxnfyccfadssjmhbpq.png" width="521" height="348" alt="" style="border: 0px;" /></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">图表<span lang="EN-US">4</span>：<span lang="EN-US">2020</span>年我国糖尿病监测市场规模测算<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">根据<span lang="EN-US">Coherent Market Insights</span>数据，<span lang="EN-US">2015</span>年全球连续血糖监测市场价值为<span lang="EN-US">4.44</span>亿美元，预计<span lang="EN-US">2016</span>年至<span lang="EN-US">2024</span>年将以<span lang="EN-US">9.8</span>％的年复合增长率扩大，到<span lang="EN-US">2024</span>年，全球<span lang="EN-US">CGM</span>市场价值或达<span lang="EN-US">10.25</span>亿。而根据<span lang="EN-US">Grandview Research</span>数据，我国<span lang="EN-US">CGM</span>市场将爆发式增长，预计到<span lang="EN-US">2024</span>年，我国连续血糖监测传感器市场将达<span lang="EN-US">5500</span>万美元。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">资料来源：中国<span lang="EN-US">2</span>型糖尿病防治指南（<span lang="EN-US">2017</span>年版）、公开信息、东兴证券、上市公司公告</p>'),
('4','&nbsp;<span style="color: rgb(51, 51, 51); font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; font-size: 16px; text-indent: 21pt;">选手们头戴脑电帽，双眼紧盯电脑屏幕，搜索快速闪烁的目标字符。尽管身体纹丝不动，脑机接口技术已捕捉到他们脑电波的变化。</span>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">8</span>月<span lang="EN-US">20</span>日至<span lang="EN-US">25</span>日，<span lang="EN-US">2019</span>世界<a href="http://www.3618med.com/product/keywords/2880.html" title="机器人" target="_blank" class="hl-keyword" style="outline: 0px; cursor: pointer; color: green; text-decoration-line: none;">机器人</a>大会在北京举行。酷炫的&ldquo;<span lang="EN-US">BCI</span>脑控机器人大赛暨第三届中国脑机接口比赛&rdquo;在大会期间正式&ldquo;开锣&rdquo;，赛事由国家自然科学基金委信息科学部、中国电子学会、清华大学医学院共同主办。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">要说参观今年脑机接口比赛的感受，一句话：脑机接口技术真的火起来了。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">比赛规模远远胜于往届<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">&ldquo;这次比赛有<span lang="EN-US">2000</span>多人次参加技能赛的初赛，一共产生<span lang="EN-US">40</span>名选手来大会参加决赛。同时还有<span lang="EN-US">400</span>多个赛队参加了技术赛初赛，赛出<span lang="EN-US">16</span>强来大会参加技术赛的决赛。&rdquo;此次脑机接口赛事专家委员会副主任、清华大学医学院生物医学工程系教授高小榕接受科技日报记者采访时说，从比赛规模来看，今年远胜往届。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">话说回来，今年技能赛和技术赛分别怎么比呢？<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">&ldquo;如果把脑机接口技术比作赛车的话，那么技能赛比的是人，技术赛比的是车。&rdquo;作为赛事筹备工作人员，清华大学医学院科研助理吴昊霖告诉科技日报记者。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">吴昊霖介绍，技能赛设置了运动想象、<span lang="EN-US">SSVEP</span>、<span lang="EN-US">P300</span>三种比赛范式，分别以不同方式测试选手使用脑机接口设备的能力。以运动想象比赛为例，选手头戴脑电帽，仅在大脑中想象左手或右手的运动，借助脑机接口技术识别选手意图，电脑屏幕上虚拟的左手或右手会做出相应运动。它比的是选手用意识来操控虚拟左右手运动的能力。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">技术赛比的是团队设计的脑机接口相关算法的性能。进入技术赛的决赛团队，大多来自高校和科研院所，他们有的关注脑机接口研究，也有的从事深度学习技术研究。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">决赛选手在激烈紧张地进行比赛的同时，比赛区外也吸引了满满一大批饶有兴趣的参观者，不少人好奇地向工作人员问这问那。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">脑机接口进入&ldquo;技术爆发期&rdquo;<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">这种&ldquo;热度&rdquo;，或许得益于前不久脑机接口领域的一些重要进展。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">北京时间<span lang="EN-US">7</span>月<span lang="EN-US">17</span>日，&ldquo;科学狂人&rdquo;埃隆&middot;马斯克创立的<span lang="EN-US">Neurali[x]nk</span>公司发布脑机接口系统；<span lang="EN-US">7</span>月底，国际期刊发表了美国科学家&ldquo;语音解码器&rdquo;相关研究，该研究利用脑机接口分析大脑信号来判断人们在说什么，脸书是研究的资助方之一。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">&ldquo;由于产业界巨头的关注和相关研发成果的公布，今年脑机接口技术得到很好的科普，大家对脑机接口技术的兴趣高涨。&rdquo;在高小榕看来，这是好事。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">高小榕认为，目前脑机接口技术已经进入第三阶段。第一阶段是科学幻想阶段，第二阶段是科学论证阶段，当下的第三阶段主要聚焦用什么技术路径来实现脑机接口技术，将出现各种各样的技术方法，也就是所谓的&ldquo;技术爆发期&rdquo;。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">&ldquo;脑机接口技术将在人与机器之间架起桥梁，并最终促进人与人之间的沟通，因此将创造巨大价值。这是科技巨头关注和投资脑机接口技术的重要原因。&rdquo;赛事协办方博睿康科技有限公司（<span lang="EN-US">Neuracle</span>）负责为此次大赛提供脑机接口信号采集设备和数据分析平台，该公司总经理黄肖山接受科技日报记者采访时说。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">黄肖山介绍，目前在医疗领域，脑机接口技术已开始临床应用阶段，并往商业化角度发力，教育和娱乐领域也有一些相关应用。<span lang="EN-US"><o:p></o:p></span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;"><span lang="EN-US">&nbsp;</span></p>
<p class="MsoNormal" align="left" style="margin: 0px; padding: 8px 0px; font-family: &quot;Microsoft YaHei&quot;, 宋体, Arial; text-indent: 21pt; color: rgb(51, 51, 51); font-size: 16px;">&ldquo;这次脑机接口比赛的举办，会进一步促进社会对脑机接口技术的关注，增进公众对脑机接口技术的了解，同时推动国内脑机接口科研团队之间的交流。&rdquo;吴昊霖说。</p>');
DROP TABLE IF EXISTS  `destoon_quote_price_7`;
CREATE TABLE `destoon_quote_price_7` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `price` decimal(10,2) NOT NULL,
  `market` smallint(6) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL,
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `wx` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='行情报价';

DROP TABLE IF EXISTS  `destoon_quote_product_7`;
CREATE TABLE `destoon_quote_product_7` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `unit` varchar(10) NOT NULL,
  `price` decimal(10,2) unsigned NOT NULL,
  `minprice` decimal(10,2) unsigned NOT NULL,
  `maxprice` decimal(10,2) unsigned NOT NULL,
  `n1` varchar(100) NOT NULL,
  `n2` varchar(100) NOT NULL,
  `n3` varchar(100) NOT NULL,
  `v1` varchar(100) NOT NULL,
  `v2` varchar(100) NOT NULL,
  `v3` varchar(100) NOT NULL,
  `market` varchar(255) NOT NULL,
  `item` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `seo_title` varchar(255) NOT NULL,
  `seo_keywords` varchar(255) NOT NULL,
  `seo_description` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='行情产品';

DROP TABLE IF EXISTS  `destoon_sell_5`;
CREATE TABLE `destoon_sell_5` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `mycatid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(2) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `elite` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `n1` varchar(100) NOT NULL,
  `n2` varchar(100) NOT NULL,
  `n3` varchar(100) NOT NULL,
  `v1` varchar(100) NOT NULL,
  `v2` varchar(100) NOT NULL,
  `v3` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL DEFAULT '',
  `unit` varchar(10) NOT NULL DEFAULT '',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `minamount` float unsigned NOT NULL DEFAULT '0',
  `amount` float unsigned NOT NULL DEFAULT '0',
  `days` smallint(3) unsigned NOT NULL DEFAULT '0',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `thumb1` varchar(255) NOT NULL DEFAULT '',
  `thumb2` varchar(255) NOT NULL DEFAULT '',
  `thumbs` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `vip` smallint(2) unsigned NOT NULL DEFAULT '0',
  `validated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(30) NOT NULL DEFAULT '',
  `telephone` varchar(50) NOT NULL DEFAULT '',
  `mobile` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `qq` varchar(20) NOT NULL DEFAULT '',
  `wx` varchar(50) NOT NULL DEFAULT '',
  `ali` varchar(30) NOT NULL DEFAULT '',
  `skype` varchar(30) NOT NULL DEFAULT '',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `editdate` date NOT NULL DEFAULT '0000-00-00',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `adddate` date NOT NULL DEFAULT '0000-00-00',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `editdate` (`editdate`,`vip`,`edittime`),
  KEY `edittime` (`edittime`),
  KEY `catid` (`catid`),
  KEY `mycatid` (`mycatid`),
  KEY `areaid` (`areaid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='供应';

DROP TABLE IF EXISTS  `destoon_sell_data_5`;
CREATE TABLE `destoon_sell_data_5` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='供应内容';

DROP TABLE IF EXISTS  `destoon_sell_search_5`;
CREATE TABLE `destoon_sell_search_5` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `sorttime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='供应搜索';

DROP TABLE IF EXISTS  `destoon_session`;
CREATE TABLE `destoon_session` (
  `sessionid` varchar(32) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `sessionid` (`sessionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SESSION';

DROP TABLE IF EXISTS  `destoon_setting`;
CREATE TABLE `destoon_setting` (
  `item` varchar(30) NOT NULL DEFAULT '',
  `item_key` varchar(100) NOT NULL DEFAULT '',
  `item_value` text NOT NULL,
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='网站设置';

insert into `destoon_setting`(`item`,`item_key`,`item_value`) values
('1','message_type','1,2,3'),
('1','message_time','60'),
('1','message_group','6,7'),
('1','message_email','0'),
('1','mail_log','1'),
('1','mail_name',''),
('1','mail_sender',''),
('1','mail_sign',''),
('1','smtp_pass',''),
('1','smtp_user',''),
('1','smtp_auth','1'),
('1','smtp_port','25'),
('1','smtp_host',''),
('1','mail_delimiter','1'),
('1','mail_type','close'),
('1','water_fontcolor','#000000'),
('1','water_fontsize','20'),
('1','water_font','simhei.ttf'),
('1','water_text','www.destoon.com'),
('1','water_jpeg_quality','90'),
('1','water_transition','60'),
('1','water_mark','watermark.png'),
('1','max_image','800'),
('1','thumb_title','0'),
('1','thumb_album','0'),
('1','middle_h','300'),
('1','water_com','1'),
('1','water_middle','0'),
('1','middle_w','400'),
('1','gif_ani','1'),
('2','oauth','1'),
('2','uc_bbspre',''),
('2','uc_bbs','1'),
('2','uc_key',''),
('2','uc_charset','utf8'),
('2','uc_appid',''),
('2','uc_dbpre',''),
('2','uc_dbname',''),
('2','uc_dbpwd',''),
('2','uc_dbuser',''),
('2','uc_dbhost',''),
('2','uc_mysql','1'),
('2','uc_api',''),
('2','uc_ip',''),
('2','passport_key',''),
('2','passport_url',''),
('2','passport_charset','gbk'),
('2','passport','0'),
('2','ex_name',''),
('2','ex_rate',''),
('2','ex_fdnm',''),
('2','ex_prex',''),
('2','ex_data',''),
('2','ex_pass',''),
('2','ex_user','root'),
('2','ex_host','localhost'),
('2','ex_type','PW'),
('2','credit_exchange','0'),
('2','credit_price','5|10|45|85'),
('2','credit_buy','30|100|500|1000'),
('2','credit_del_page','5'),
('2','credit_add_page','2'),
('2','credit_del_news','5'),
('2','credit_add_news','2'),
('2','credit_del_credit','5'),
('2','credit_add_credit','2'),
('2','credit_charge','1'),
('2','credit_maxip','50'),
('2','credit_ip','2'),
('2','credit_user','20'),
('2','credit_login','1'),
('2','credit_edit','10'),
('2','credit_less','1'),
('2','send_types','平邮|EMS|顺丰快递|申通快递|圆通快递|中通快递|国通快递|宅急送|韵达快递|天天快递|如风达|百世汇通|全峰快递|快捷快递|其它'),
('2','deposit','1000'),
('2','trade_day','10'),
('2','pay_banks','站内|支付宝|微信支付|财付通|现金|招商银行|工商银行|农业银行|建设银行|交通银行|中国银行|邮政储蓄|邮政汇款'),
('2','cash_fee_max','50'),
('2','cash_fee_min','1'),
('2','cash_fee','1'),
('2','cash_max','10000'),
('2','cash_min','50'),
('2','cash_banks','支付宝|微信|财付通|招商银行|工商银行|农业银行|建设银行|交通银行|中国银行|邮政储蓄|邮政汇款'),
('2','cash_times','3'),
('2','cash_enable','1'),
('2','pay_url',''),
('2','awards','1|2|5|10|20|50|100'),
('2','mincharge','0'),
('2','pay_card','1'),
('2','pay_online','1'),
('2','link_check','2'),
('2','credit_clear','0'),
('2','credit_save','0'),
('2','credit_check','2'),
('2','page_clear','0'),
('2','page_save','0'),
('2','page_check','2'),
('2','news_clear','0'),
('2','news_save','0'),
('2','news_thumb_height','180'),
('2','news_thumb_width','240'),
('2','news_check','2'),
('2','introduce_clear','0'),
('2','introduce_save','0'),
('2','introduce_length','0'),
('2','thumb_height','180'),
('2','thumb_width','180'),
('2','cate_max','6'),
('2','mode_max','2'),
('2','money_unit','人民币|港元|台币|美元|欧元|英镑'),
('2','editor','Basic'),
('2','com_type','企业单位|事业单位或社会团体|个体经营|其他'),
('2','com_size','1-49人|50-99人|100-499人|500-999人|1000-3000人|3000-5000人|5000-10000人|10000人以上'),
('2','com_mode','制造商|贸易商|服务商|其他机构'),
('2','vfax',''),
('2','vcompany','1'),
('2','vbank','1'),
('2','vtruename','1'),
('2','vmobile','1'),
('2','vemail','1'),
('2','vmember','1'),
('2','chat_img','1'),
('2','chat_url','1'),
('2','chat_file','1'),
('2','chat_mintime','3'),
('2','chat_poll','1'),
('2','chat_timeout','600'),
('2','chat_maxlen','300'),
('2','alert_check','2'),
('2','alertid','5|6|22'),
('2','auth_days','3'),
('2','captcha_home','2'),
('2','captcha_edit','2'),
('2','captcha_sendmessage','2'),
('2','maxtouser','5'),
('2','login_scan','1'),
('2','login_sms','1'),
('2','login_time','864000'),
('2','captcha_login','0'),
('2','lock_hour','1'),
('2','login_times','5'),
('2','usernote',''),
('2','edit_check','thumb,areaid,type,business,regyear,capital,address,telephone,gzh,gzhqr,content'),
('2','iptimeout','24'),
('2','banagent',''),
('2','defend_proxy','0'),
('2','sms_register','0'),
('2','credit_register','0'),
('2','money_register','0'),
('2','question_register','1'),
('2','captcha_register','1'),
('2','welcome_sms','1'),
('2','welcome_email','1'),
('2','welcome_message','1'),
('2','checkuser','0'),
('2','banemail',''),
('2','banmodec','0'),
('2','bancompany',''),
('2','mixpassword','1,2'),
('2','maxpassword','20'),
('2','maxusername','20'),
('2','banusername','admin|system|master|web|sell|buy|company|quote|job|article|info|page|bbs'),
('2','banmodeu','0'),
('2','minpassword','6'),
('2','minusername','4'),
('2','enable_register','1'),
('2','module','member'),
('2','mobile','http://demo.destoon.com/v7.0/mobile/member/'),
('3','baidunews_items','90'),
('3','baidunews_update','60'),
('3','baidunews_email','web@destoon.com'),
('3','baidunews','1'),
('3','sitemaps_update','60'),
('3','sitemaps_items','10000'),
('3','sitemaps_module','16,5,6,4,17,7,8,21,22,9,10,11,12,14,15'),
('3','sitemaps_priority','0.8'),
('3','sitemaps_changefreq','monthly'),
('3','sitemaps','1'),
('3','feed_pagesize','50'),
('3','feed_domain',''),
('3','feed_enable','2'),
('3','archiver_domain',''),
('3','archiver_enable','1'),
('3','form_domain',''),
('3','form_enable','1'),
('3','poll_domain',''),
('3','poll_enable','1'),
('3','vote_domain',''),
('3','vote_enable','1'),
('3','gift_domain',''),
('3','gift_time','86400'),
('3','gift_enable','1'),
('3','guestbook_enable','1'),
('3','guestbook_domain',''),
('3','guestbook_type','业务合作|意见建议|使用问题|页面错误|不良信息|其他'),
('3','guestbook_captcha','1'),
('3','comment_am','网友'),
('3','credit_del_comment','5'),
('3','credit_add_comment','2'),
('3','comment_limit','30'),
('3','comment_pagesize','10'),
('3','comment_time','30'),
('3','comment_max','500'),
('3','comment_min','5'),
('3','comment_vote','1'),
('3','comment_admin_del','1'),
('3','comment_user_del','4'),
('3','comment_captcha_add','1'),
('3','comment_check','2'),
('3','comment_vote_group','5,6,7'),
('3','comment_group','5,6,7'),
('3','comment_show','1'),
('3','comment_api_key',''),
('3','comment_module','5,6,4,17,7,8,21,22,13,9,11,12,14,15'),
('3','comment_api',''),
('3','comment_api_id',''),
('3','comment_domain',''),
('3','link_request',''),
('3','link_reg','1'),
('3','link_domain',''),
('3','link_enable','1'),
('3','announce_domain',''),
('3','announce_enable','1'),
('3','ad_currency','money'),
('3','ad_buy','1'),
('3','ad_view','1'),
('3','ad_domain',''),
('3','ad_enable','1'),
('3','spread_currency','money'),
('3','spread_list','1'),
('3','spread_check','1'),
('3','spread_step','100'),
('3','spread_month','6'),
('3','spread_max','10'),
('3','spread_price','200'),
('3','spread_domain',''),
('3','mobile_adr','77@aprcc7byyvzxyi4i'),
('3','mobile_ios','77@d9xuz1ukp1goudwh'),
('3','mobile_ajax','1'),
('3','mobile_goto','1'),
('3','mobile_pid','14'),
('3','mobile_sitename','DESTOON'),
('3','mobile_domain',''),
('3','mobile_enable','1'),
('3','show_url','1'),
('3','list_url','1'),
('3','weixin','0'),
('3','oauth','1,sina'),
('3','module','extend'),
('3','mobile','http://qingchuangjie.gotoip2.com/mobile/extend/'),
('3','feed_url','http://qingchuangjie.gotoip2.com/feed/'),
('3','feed_mob','http://qingchuangjie.gotoip2.com/mobile/feed/'),
('3','archiver_url','http://qingchuangjie.gotoip2.com/archiver/'),
('3','archiver_mob','http://qingchuangjie.gotoip2.com/mobile/archiver/'),
('3','form_url','http://qingchuangjie.gotoip2.com/form/'),
('3','form_mob','http://qingchuangjie.gotoip2.com/mobile/form/'),
('3','poll_url','http://qingchuangjie.gotoip2.com/poll/'),
('3','poll_mob','http://qingchuangjie.gotoip2.com/mobile/poll/'),
('3','vote_url','http://qingchuangjie.gotoip2.com/vote/'),
('3','vote_mob','http://qingchuangjie.gotoip2.com/mobile/vote/'),
('3','gift_url','http://qingchuangjie.gotoip2.com/gift/'),
('3','gift_mob','http://qingchuangjie.gotoip2.com/mobile/gift/'),
('3','guestbook_url','http://qingchuangjie.gotoip2.com/guestbook/'),
('3','guestbook_mob','http://qingchuangjie.gotoip2.com/mobile/guestbook/'),
('3','comment_url','http://qingchuangjie.gotoip2.com/comment/'),
('3','comment_mob','http://qingchuangjie.gotoip2.com/mobile/comment/'),
('3','link_url','http://qingchuangjie.gotoip2.com/link/'),
('3','link_mob','http://qingchuangjie.gotoip2.com/mobile/link/'),
('3','announce_url','http://qingchuangjie.gotoip2.com/announce/'),
('3','announce_mob','http://qingchuangjie.gotoip2.com/mobile/announce/'),
('3','ad_url','http://qingchuangjie.gotoip2.com/ad/'),
('3','ad_mob','http://qingchuangjie.gotoip2.com/mobile/ad/'),
('3','spread_url','http://qingchuangjie.gotoip2.com/spread/'),
('3','spread_mob','http://qingchuangjie.gotoip2.com/mobile/spread/'),
('3','mobile_url','http://qingchuangjie.gotoip2.com/mobile/'),
('3','mobile_mob','http://qingchuangjie.gotoip2.com/mobile/mobile/'),
('4','group_message','3,5,6,7'),
('4','group_buy','3,5,6,7'),
('4','group_index','3,5,6,7'),
('4','seo_description_search',''),
('4','seo_keywords_search',''),
('4','seo_title_search',''),
('4','group_list','3,5,6,7'),
('4','group_search','3,5,6,7'),
('4','group_price','3,5,6,7'),
('4','seo_description_show','{内容标题}{内容简介}{分类名称}{分类SEO描述}{模块名称}{网站名称}{网站SEO描述}'),
('4','group_inquiry','3,5,6,7'),
('4','seo_keywords_show','{内容标题}{分类名称}{分类SEO关键词}{模块名称}{网站SEO关键词}'),
('4','seo_title_show','{内容标题}{分类名称}{分类SEO标题}{模块名称}{网站名称}{网站SEO标题}{分隔符}'),
('4','seo_description_list','{网站SEO描述}{网站名称}{模块名称}{分类SEO描述}{分类名称}'),
('4','seo_keywords_list','{分类名称}{分类SEO关键词}{模块名称}{网站名称}{网站SEO关键词}'),
('4','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('4','seo_keywords_index','{模块名称}{网站名称}{网站SEO标题}'),
('4','seo_description_index','{模块名称}{网站名称}{网站SEO标题}'),
('4','php_list_urlid','5'),
('4','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('4','htm_list_urlid','0'),
('4','htm_list_prefix','company_list_'),
('4','list_html','0'),
('4','index_html','0'),
('4','page_comment','0'),
('4','hits','1'),
('4','pagesize','20'),
('4','page_inew','10'),
('4','group_contact','5,6,7'),
('4','page_inews','10'),
('4','page_ivip','10'),
('4','page_irec','10'),
('4','page_subcat','6'),
('4','level','推荐公司'),
('4','kf','qq,53kf,tq,qiao'),
('4','stats','baidu,qq,cnzz,51la'),
('4','map','baidu'),
('4','vip_honor','1'),
('4','vip_maxyear','5'),
('4','vip_year','1'),
('4','vip_cominfo','1'),
('4','vip_maxgroupvip','3'),
('4','delvip','1'),
('4','openall','0'),
('4','split','0'),
('4','comment','1'),
('4','homeurl','0'),
('4','fields','userid,username,company,linkurl,thumb,catid,areaid,vip,groupid,validated,business,mode'),
('4','order','vip desc,userid desc'),
('4','template_search',''),
('4','template_list',''),
('4','template_index',''),
('4','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('4','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('4','title_show','{$seo_showtitle}{$seo_catname}{$seo_cattitle}{$seo_modulename}{$seo_sitename}{$seo_sitetitle}{$seo_delimiter}'),
('4','title_search',''),
('4','keywords_index','{$seo_modulename}{$seo_sitename}{$seo_sitetitle}'),
('4','keywords_list','{$seo_catname}{$seo_catkeywords}{$seo_modulename}{$seo_sitename}{$seo_sitekeywords}'),
('4','keywords_show','{$seo_showtitle}{$seo_catname}{$seo_catkeywords}{$seo_modulename}{$seo_sitekeywords}'),
('4','keywords_search',''),
('4','description_index','{$seo_modulename}{$seo_sitename}{$seo_sitetitle}'),
('4','description_list','{$seo_sitedescription}{$seo_sitename}{$seo_modulename}{$seo_catdescription}{$seo_catname}'),
('4','description_show','{$seo_showtitle}{$seo_showintroduce}{$seo_catname}{$seo_catdescription}{$seo_modulename}{$seo_sitename}{$seo_sitedescription}'),
('4','description_search',''),
('4','module','company'),
('4','mobile','http://demo.destoon.com/v7.0/mobile/company/'),
('6','free_limit_7','-1'),
('6','limit_7','100'),
('6','free_limit_6','0'),
('6','limit_6','30'),
('6','free_limit_5','0'),
('6','limit_5','3'),
('6','free_limit_4','0'),
('6','limit_4','-1'),
('6','free_limit_3','0'),
('6','limit_3','-1'),
('6','free_limit_2','0'),
('6','limit_2','-1'),
('6','free_limit_1','-1'),
('6','limit_1','0'),
('6','credit_refresh','1'),
('6','credit_color','100'),
('6','credit_del','5'),
('6','credit_add','2'),
('6','fee_award','0'),
('6','fee_back','0'),
('6','fee_period','0'),
('6','fee_view','0'),
('6','fee_add','0'),
('6','fee_currency','money'),
('6','fee_mode','1'),
('6','question_add','2'),
('6','captcha_add','2'),
('6','check_add','2'),
('6','question_price','2'),
('6','captcha_price','2'),
('6','group_refresh','7'),
('6','group_color','7'),
('6','group_search','3,5,6,7'),
('6','group_contact','3,5,6,7'),
('6','group_show','3,5,6,7'),
('6','group_list','3,5,6,7'),
('6','group_index','3,5,6,7'),
('6','seo_description_search',''),
('6','seo_keywords_search',''),
('6','seo_title_search',''),
('6','seo_keywords_show',''),
('6','seo_description_show',''),
('6','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('6','seo_description_list',''),
('6','seo_keywords_list',''),
('6','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('6','seo_description_index',''),
('6','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('6','seo_keywords_index',''),
('6','php_item_urlid','0'),
('6','htm_item_urlid','0'),
('6','htm_item_prefix','buy_info_'),
('6','show_html','0'),
('6','php_list_urlid','0'),
('6','htm_list_urlid','0'),
('6','htm_list_prefix','buy_list_'),
('6','list_html','0'),
('6','index_html','0'),
('6','page_comment','0'),
('6','hits','1'),
('6','max_width','1000'),
('6','pagesize','20'),
('6','page_ihits','9'),
('6','page_iedit','10'),
('6','page_inew','10'),
('6','page_irec','12'),
('6','page_subcat','6'),
('6','level','推荐信息'),
('6','fulltext','0'),
('6','split','0'),
('6','keylink','0'),
('6','clear_link','0'),
('6','type','求购|紧急求购|求购二手|寻求加工|寻求合作|招标'),
('6','price_ask','请您发一份比较详细的产品规格说明，谢谢！|请问您对此产品是长期有需求吗？|请问您对此产品有多大的需求量？'),
('6','cat_property','0'),
('6','save_remotepic','0'),
('6','order','editdate desc,vip desc,edittime desc'),
('6','fields','itemid,title,thumb,linkurl,style,catid,areaid,introduce,addtime,edittime,username,company,groupid,vip,qq,wx,ali,skype,validated,price,hits'),
('6','introduce_length','120'),
('6','editor','Destoon'),
('6','thumb_height','200'),
('6','thumb_width','200'),
('6','template_price',''),
('6','template_my',''),
('6','template_search',''),
('6','template_show',''),
('6','template_list',''),
('6','template_index',''),
('6','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('6','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('6','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('6','title_search',''),
('6','keywords_index',''),
('6','keywords_list',''),
('6','keywords_show',''),
('6','keywords_search',''),
('6','description_index',''),
('6','description_list',''),
('6','description_show',''),
('6','description_search',''),
('6','module','buy'),
('6','mobile','http://demo.destoon.com/v7.0/mobile/buy/'),
('7','free_limit_5','0'),
('7','limit_6','30'),
('7','limit_5','3'),
('7','free_limit_4','0'),
('7','limit_4','-1'),
('7','free_limit_3','0'),
('7','limit_3','-1'),
('7','free_limit_2','0'),
('7','limit_2','-1'),
('7','free_limit_1','-1'),
('7','limit_1','0'),
('7','credit_color','100'),
('7','credit_del','5'),
('7','free_limit_7','-1'),
('7','credit_add','2'),
('7','limit_7','100'),
('7','free_limit_6','0'),
('7','pre_view','200'),
('7','fee_award','0'),
('7','fee_back','0'),
('7','fee_period','0'),
('7','fee_view','0'),
('7','fee_add','0'),
('7','fee_currency','money'),
('7','fee_mode','1'),
('7','question_add','2'),
('7','captcha_add','2'),
('7','check_add','2'),
('7','group_add_price','3,5,6,7'),
('7','group_show_price','3,5,6,7'),
('7','group_color','7'),
('7','group_search','3,5,6,7'),
('7','group_show','3,5,6,7'),
('7','group_list','3,5,6,7'),
('7','seo_description_search',''),
('7','group_index','3,5,6,7'),
('7','seo_keywords_search',''),
('7','seo_title_search',''),
('7','seo_keywords_show',''),
('7','seo_description_show',''),
('7','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('7','seo_description_list',''),
('7','seo_keywords_list',''),
('7','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('7','seo_description_index',''),
('7','seo_keywords_index',''),
('7','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('7','php_item_urlid','0'),
('7','htm_item_urlid','0'),
('7','htm_item_prefix',''),
('7','htm_list_urlid','0'),
('7','show_html','0'),
('7','php_list_urlid','0'),
('7','htm_list_prefix',''),
('7','list_html','0'),
('7','index_html','0'),
('7','page_comment','0'),
('7','hits','1'),
('7','max_width','800'),
('7','page_child','5'),
('7','page_icat','5'),
('7','pagesize','20'),
('7','level','推荐行情|暂未指定|推荐图文|头条相关|头条推荐'),
('7','fulltext','0'),
('7','split','0'),
('7','keylink','1'),
('7','clear_link','0'),
('7','cat_property','0'),
('7','save_remotepic','0'),
('7','fields','itemid,title,thumb,linkurl,style,catid,introduce,hits,addtime,edittime,username'),
('7','order','addtime desc'),
('7','introduce_length','120'),
('7','editor','Destoon'),
('7','thumb_height','180'),
('7','thumb_width','240'),
('7','template_price',''),
('7','template_product',''),
('7','template_my',''),
('7','template_search',''),
('7','template_show',''),
('7','template_list',''),
('7','template_index',''),
('7','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('7','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('7','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('7','title_search',''),
('7','keywords_index',''),
('7','keywords_list',''),
('7','keywords_show',''),
('7','keywords_search',''),
('7','description_index',''),
('7','description_list',''),
('7','description_show',''),
('7','description_search',''),
('7','module','quote'),
('7','mobile','http://demo.destoon.com/v7.0/mobile/quote/'),
('8','free_limit_5','0'),
('8','limit_6','30'),
('8','free_limit_7','-1'),
('8','limit_5','3'),
('8','free_limit_4','0'),
('8','limit_7','100'),
('8','limit_4','-1'),
('8','limit_3','-1'),
('8','free_limit_3','0'),
('8','free_limit_2','0'),
('8','limit_2','-1'),
('8','free_limit_6','0'),
('8','free_limit_1','-1'),
('8','limit_1','0'),
('8','credit_color','100'),
('8','credit_del','5'),
('8','credit_add','2'),
('8','pre_view','200'),
('8','fee_award','100'),
('8','fee_back','0'),
('8','fee_period','0'),
('8','fee_view','0'),
('8','fee_add','0'),
('8','fee_currency','money'),
('8','fee_mode','1'),
('8','question_add','2'),
('8','captcha_add','2'),
('8','check_add','2'),
('8','captcha_sign','2'),
('8','group_color','7'),
('8','group_search','3,5,6,7'),
('8','group_contact','5,6,7'),
('8','group_show','3,5,6,7'),
('8','group_list','3,5,6,7'),
('8','group_index','3,5,6,7'),
('8','seo_description_search',''),
('8','seo_keywords_search',''),
('8','seo_title_search',''),
('8','seo_description_list',''),
('8','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('8','seo_keywords_show',''),
('8','seo_description_show',''),
('8','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('8','seo_keywords_list',''),
('8','seo_description_index',''),
('8','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('8','seo_keywords_index',''),
('8','php_item_urlid','0'),
('8','htm_item_urlid','0'),
('8','htm_item_prefix',''),
('8','show_html','0'),
('8','php_list_urlid','0'),
('8','htm_list_urlid','0'),
('8','htm_list_prefix',''),
('8','list_html','0'),
('8','index_html','0'),
('8','page_comment','0'),
('8','hits','1'),
('8','max_width','800'),
('8','pagesize','10'),
('8','cat_hall_num','2'),
('8','cat_hall','0'),
('8','cat_service_num','8'),
('8','cat_service','0'),
('8','cat_news_num','10'),
('8','cat_news','0'),
('8','news_id','21'),
('8','page_islide','3'),
('8','page_icat','10'),
('8','level','推荐展会|展会幻灯'),
('8','fulltext','0'),
('8','split','0'),
('8','keylink','1'),
('8','clear_link','0'),
('8','save_remotepic','0'),
('8','cat_property','0'),
('8','fields','itemid,title,thumb,linkurl,style,catid,addtime,edittime,username,fromtime,totime,city,address,sponsor'),
('8','order','addtime desc'),
('8','editor','Destoon'),
('8','introduce_length','0'),
('8','thumb_height','180'),
('8','thumb_width','240'),
('8','template_sign',''),
('8','template_my',''),
('8','template_search',''),
('8','template_show',''),
('8','template_list',''),
('8','template_index',''),
('8','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('8','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('8','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('8','title_search',''),
('8','keywords_index',''),
('8','keywords_list',''),
('8','keywords_show',''),
('8','keywords_search',''),
('8','description_index',''),
('8','description_list',''),
('8','description_show',''),
('8','description_search',''),
('8','module','exhibit'),
('8','mobile','http://demo.destoon.com/v7.0/mobile/exhibit/'),
('10','limit_6','30'),
('10','answer_limit_6','30'),
('10','answer_limit_7','100'),
('10','free_limit_7','-1'),
('10','limit_7','100'),
('10','free_limit_6','0'),
('10','answer_limit_5','-1'),
('10','free_limit_5','0'),
('10','limit_5','3'),
('10','answer_limit_4','-1'),
('10','free_limit_4','0'),
('10','limit_4','-1'),
('10','answer_limit_3','-1'),
('10','free_limit_3','0'),
('10','limit_3','-1'),
('10','answer_limit_2','-1'),
('10','free_limit_2','0'),
('10','limit_2','-1'),
('10','answer_limit_1','0'),
('10','free_limit_1','-1'),
('10','limit_1','0'),
('10','credit_deal','20'),
('10','credit_maxvote','30'),
('10','credit_del_answer','5'),
('10','credit_maxanswer','50'),
('10','credit_vote','1'),
('10','credit_answer','2'),
('10','credit_best','20'),
('10','credit_hidden','10'),
('10','credit_color','100'),
('10','credit_del','20'),
('10','credit_add','0'),
('10','pre_view','200'),
('10','fee_award','0'),
('10','fee_back','0'),
('10','fee_period','0'),
('10','fee_view','0'),
('10','fee_add','0'),
('10','fee_currency','money'),
('10','fee_mode','1'),
('10','captcha_answer','2'),
('10','question_answer','0'),
('10','check_answer','2'),
('10','group_vote','3,5,6,7'),
('10','group_answer','3,5,6,7'),
('10','question_add','2'),
('10','captcha_add','2'),
('10','check_add','2'),
('10','group_color','7'),
('10','group_search','3,5,6,7'),
('10','group_show','3,5,6,7'),
('10','group_list','3,5,6,7'),
('10','group_index','3,5,6,7'),
('10','seo_description_search',''),
('10','seo_keywords_search',''),
('10','seo_title_search',''),
('10','seo_description_show',''),
('10','seo_keywords_show',''),
('10','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('10','seo_description_list',''),
('10','seo_keywords_list',''),
('10','seo_description_index',''),
('10','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('10','seo_keywords_index',''),
('10','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('10','php_item_urlid','0'),
('10','htm_item_urlid','1'),
('10','htm_item_prefix',''),
('10','show_html','0'),
('10','php_list_urlid','0'),
('10','htm_list_urlid','0'),
('10','htm_list_prefix',''),
('10','list_html','0'),
('10','index_html','0'),
('10','page_comment','0'),
('10','hits','1'),
('10','max_width','750'),
('10','answer_pagesize','10'),
('10','pagesize','20'),
('10','page_iexpert','8'),
('10','page_iresolve','8'),
('10','page_ivote','8'),
('10','page_isolve','8'),
('10','page_irec','8'),
('10','messagedays','14'),
('10','highcredit','20'),
('10','raisecredit','20'),
('10','raisedays','3'),
('10','maxraise','2'),
('10','minvote','3'),
('10','votedays','5'),
('10','overdays','15'),
('10','answer_message','1'),
('10','answer_repeat','1'),
('10','credits','0|5|10|15|20|30|50|80|100'),
('10','level','精彩推荐'),
('10','fulltext','0'),
('10','split','0'),
('10','keylink','1'),
('10','cat_property','0'),
('10','save_remotepic','0'),
('10','clear_link','0'),
('10','clear_alink','1'),
('10','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,username,passport,answer,process,credit'),
('10','order','addtime desc'),
('10','editor','Simple'),
('10','introduce_length','0'),
('10','thumb_height','180'),
('10','thumb_width','240'),
('10','template_my_answer',''),
('10','template_my',''),
('10','template_faq',''),
('10','template_expert',''),
('10','template_answer',''),
('10','template_search',''),
('10','template_show',''),
('10','template_list',''),
('10','template_index',''),
('10','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('10','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('10','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('10','title_search',''),
('10','keywords_index',''),
('10','keywords_list',''),
('10','keywords_show',''),
('10','keywords_search',''),
('10','description_index',''),
('10','description_list',''),
('10','description_show',''),
('10','description_search',''),
('10','module','know'),
('10','mobile','http://demo.destoon.com/v7.0/mobile/know/'),
('11','group_show','3,5,6,7'),
('11','group_search','3,5,6,7'),
('11','fee_award','0'),
('11','group_list','3,5,6,7'),
('11','group_index','3,5,6,7'),
('11','seo_description_search',''),
('11','seo_keywords_search',''),
('11','seo_title_search',''),
('11','seo_description_show',''),
('11','seo_keywords_show',''),
('11','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('11','seo_keywords_list',''),
('11','seo_description_list',''),
('11','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('11','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('11','seo_keywords_index',''),
('11','seo_description_index',''),
('11','php_item_urlid','0'),
('11','htm_item_urlid','1'),
('11','htm_item_prefix',''),
('11','show_html','0'),
('11','php_list_urlid','0'),
('11','htm_list_urlid','0'),
('11','htm_list_prefix',''),
('11','list_html','0'),
('11','index_html','0'),
('11','page_comment','0'),
('11','hits','1'),
('11','max_width','1000'),
('11','pagesize','20'),
('11','level_item','推荐信息|幻灯图片|推荐图文|头条相关|头条推荐|视频报道'),
('11','page_irec','6'),
('11','page_icat','6'),
('11','level','推荐专题|暂未指定|推荐图文|头条相关|头条推荐'),
('11','fulltext','0'),
('11','split','0'),
('11','clear_link','0'),
('11','cat_property','0'),
('11','save_remotepic','0'),
('11','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,islink,hits'),
('11','order','addtime desc'),
('11','editor','Destoon'),
('11','introduce_length','120'),
('11','banner_height','200'),
('11','banner_width','1200'),
('11','thumb_height','180'),
('11','thumb_width','240'),
('11','template_show',''),
('11','template_type',''),
('11','template_search',''),
('11','template_list',''),
('11','template_index',''),
('11','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('11','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('11','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('11','title_search',''),
('11','keywords_index',''),
('11','keywords_list',''),
('11','keywords_show',''),
('11','keywords_search',''),
('11','description_index',''),
('11','description_list',''),
('11','description_show',''),
('11','description_search',''),
('11','module','special'),
('11','mobile','http://demo.destoon.com/v7.0/mobile/special/'),
('12','free_limit_7','-1'),
('12','limit_7','100'),
('12','free_limit_6','0'),
('12','limit_6','30'),
('12','free_limit_5','0'),
('12','limit_5','3'),
('12','free_limit_4','0'),
('12','limit_4','-1'),
('12','free_limit_3','0'),
('12','limit_3','-1'),
('12','free_limit_2','0'),
('12','limit_2','-1'),
('12','free_limit_1','-1'),
('12','limit_1','0'),
('12','credit_color','100'),
('12','credit_del','5'),
('12','credit_add','2'),
('12','pre_view','200'),
('12','fee_award','100'),
('12','fee_back','0'),
('12','fee_period','0'),
('12','fee_view','0'),
('12','fee_add','0'),
('12','fee_currency','money'),
('12','fee_mode','0'),
('12','question_add','1'),
('12','captcha_add','2'),
('12','check_add','1'),
('12','group_color','7'),
('12','group_search','3,5,6,7'),
('12','group_show','3,5,6,7'),
('12','group_list','3,5,6,7'),
('12','seo_description_show',''),
('12','seo_title_search',''),
('12','seo_keywords_search',''),
('12','group_index','3,5,6,7'),
('12','seo_description_search',''),
('12','seo_keywords_show',''),
('12','seo_description_list',''),
('12','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('12','seo_keywords_list',''),
('12','seo_keywords_index',''),
('12','seo_description_index',''),
('12','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('12','php_item_urlid','0'),
('12','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('12','htm_item_urlid','1'),
('12','htm_item_prefix',''),
('12','show_html','0'),
('12','php_list_urlid','0'),
('12','htm_list_urlid','0'),
('12','htm_list_prefix',''),
('12','list_html','0'),
('12','index_html','0'),
('12','page_comment','0'),
('12','hits','1'),
('12','max_width','1000'),
('12','pagesize','18'),
('12','page_islide','3'),
('12','page_irec','6'),
('12','page_icat','6'),
('12','swfu_max','20'),
('12','level','推荐图库|幻灯图片|推荐图文|头条相关|头条推荐'),
('12','fulltext','0'),
('12','split','0'),
('12','keylink','0'),
('12','clear_link','0'),
('12','save_remotepic','0'),
('12','cat_property','0'),
('12','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,username,items,open'),
('12','order','addtime desc'),
('12','editor','Simple'),
('12','introduce_length','120'),
('12','maxitem','30'),
('12','thumb_height','180'),
('12','thumb_width','240'),
('12','template_view',''),
('12','template_private',''),
('12','template_my',''),
('12','template_search',''),
('12','template_show',''),
('12','template_list',''),
('12','template_index',''),
('12','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('12','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('12','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('12','title_search',''),
('12','keywords_index',''),
('12','keywords_list',''),
('12','keywords_show',''),
('12','keywords_search',''),
('12','description_index',''),
('12','description_list',''),
('12','description_show',''),
('12','description_search',''),
('12','module','photo'),
('12','mobile','http://demo.destoon.com/v7.0/mobile/photo/'),
('13','free_limit_7','-1'),
('13','limit_7','100'),
('13','free_limit_6','0'),
('13','free_limit_5','0'),
('13','limit_6','30'),
('13','limit_5','3'),
('13','free_limit_4','0'),
('13','limit_4','-1'),
('13','free_limit_3','0'),
('13','limit_3','-1'),
('13','free_limit_2','0'),
('13','limit_2','-1'),
('13','free_limit_1','-1'),
('13','limit_1','0'),
('13','credit_refresh','1'),
('13','credit_color','100'),
('13','credit_del','5'),
('13','credit_add','2'),
('13','fee_view','0'),
('13','fee_award','0'),
('13','fee_back','0'),
('13','fee_period','0'),
('13','fee_add','0'),
('13','fee_currency','money'),
('13','fee_mode','0'),
('13','question_add','2'),
('13','captcha_add','2'),
('13','group_refresh','3,5,6,7'),
('13','captcha_message','2'),
('13','question_message','2'),
('13','check_add','2'),
('13','group_color','3,5,6,7'),
('13','group_search','3,5,6,7'),
('13','group_contact','6,7'),
('13','group_show','3,5,6,7'),
('13','group_list','3,5,6,7'),
('13','group_index','3,5,6,7'),
('13','seo_description_search',''),
('13','seo_keywords_search',''),
('13','seo_title_search',''),
('13','seo_description_show',''),
('13','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('13','seo_keywords_list',''),
('13','seo_description_list',''),
('13','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('13','seo_description_index','{模块名称}{网站名称}{网站SEO标题}'),
('13','seo_keywords_index','{模块名称}{网站名称}{网站SEO标题}'),
('13','seo_keywords_show',''),
('13','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('13','php_item_urlid','0'),
('13','htm_item_urlid','0'),
('13','htm_item_prefix',''),
('13','show_html','0'),
('13','php_list_urlid','0'),
('13','htm_list_urlid','0'),
('13','htm_list_prefix',''),
('13','list_html','0'),
('13','index_html','0'),
('13','page_comment','0'),
('13','hits','1'),
('13','max_width','1000'),
('13','pagesize','20'),
('13','page_icat','15'),
('13','page_irec','18'),
('13','page_subcat','6'),
('13','level','推荐品牌'),
('13','fulltext','0'),
('13','split','0'),
('13','keylink','0'),
('13','clear_link','0'),
('13','introduce_length','120'),
('13','editor','Destoon'),
('13','order','editdate desc,vip desc,edittime desc'),
('13','fields','itemid,title,thumb,linkurl,style,catid,areaid,introduce,addtime,edittime,username,company,groupid,vip,qq,wx,ali,skype,validated,hits'),
('13','message_ask','请问我这个地方有加盟商了吗？|我想加盟，请来电话告诉我具体细节。|初步打算加盟贵公司，请寄资料。|请问贵公司哪里有样板店或直营店？|想了解加盟细节，请尽快寄一份资料。 '),
('13','cat_property','0'),
('13','save_remotepic','0'),
('13','thumb_height','60'),
('13','thumb_width','180'),
('13','template_message',''),
('13','template_my',''),
('13','template_search',''),
('13','template_show',''),
('13','template_list',''),
('13','template_index',''),
('13','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('13','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('13','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('13','title_search',''),
('13','keywords_index','{$seo_modulename}{$seo_sitename}{$seo_sitetitle}'),
('13','keywords_list',''),
('13','keywords_show',''),
('13','keywords_search',''),
('13','description_index','{$seo_modulename}{$seo_sitename}{$seo_sitetitle}'),
('13','description_list',''),
('13','description_show',''),
('13','description_search',''),
('13','module','brand'),
('13','mobile','http://demo.destoon.com/v7.0/mobile/brand/'),
('14','limit_7','100'),
('14','free_limit_7','-1'),
('14','free_limit_6','0'),
('14','limit_6','30'),
('14','free_limit_5','0'),
('14','limit_5','3'),
('14','free_limit_4','0'),
('14','limit_4','-1'),
('14','free_limit_3','0'),
('14','limit_3','-1'),
('14','free_limit_2','0'),
('14','limit_2','-1'),
('14','free_limit_1','-1'),
('14','limit_1','0'),
('14','credit_color','100'),
('14','credit_del','5'),
('14','credit_add','2'),
('14','fee_award','100'),
('14','fee_back','0'),
('14','fee_period','0'),
('14','fee_view','0'),
('14','fee_add','0'),
('14','fee_currency','money'),
('14','fee_mode','0'),
('14','question_add','2'),
('14','captcha_add','2'),
('14','check_add','2'),
('14','question_message','2'),
('14','captcha_message','2'),
('14','group_upload','6,7'),
('14','group_color','7'),
('14','group_search','3,5,6,7'),
('14','group_show','3,5,6,7'),
('14','group_list','3,5,6,7'),
('14','group_index','3,5,6,7'),
('14','seo_description_search',''),
('14','seo_keywords_search',''),
('14','seo_title_search',''),
('14','seo_description_show',''),
('14','seo_keywords_show',''),
('14','seo_description_list',''),
('14','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('14','seo_keywords_list',''),
('14','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('14','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('14','seo_description_index',''),
('14','seo_keywords_index',''),
('14','php_item_urlid','0'),
('14','htm_item_urlid','1'),
('14','htm_item_prefix',''),
('14','show_html','0'),
('14','php_list_urlid','0'),
('14','htm_list_urlid','0'),
('14','htm_list_prefix',''),
('14','list_html','0'),
('14','index_html','0'),
('14','page_comment','0'),
('14','hits','1'),
('14','max_width','1000'),
('14','pagesize','20'),
('14','page_icat','6'),
('14','page_irec','6'),
('14','swfu','0'),
('14','upload','mp4|flv'),
('14','flvend',''),
('14','flvstart',''),
('14','flvlink',''),
('14','flvmargin','10 auto auto 10'),
('14','flvlogo','video.png'),
('14','autostart','1'),
('14','level','推荐视频'),
('14','fulltext','0'),
('14','split','0'),
('14','keylink','0'),
('14','video_width','600'),
('14','video_height','500'),
('14','introduce_length','120'),
('14','editor','Destoon'),
('14','order','addtime desc'),
('14','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,username,hits'),
('14','cat_property','0'),
('14','save_remotepic','0'),
('14','clear_link','0'),
('14','thumb_height','180'),
('14','thumb_width','240'),
('14','template_my',''),
('14','template_search',''),
('14','template_show',''),
('14','template_list',''),
('14','template_index',''),
('14','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('14','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('14','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('14','title_search',''),
('14','keywords_index',''),
('14','keywords_list',''),
('14','keywords_show',''),
('14','keywords_search',''),
('14','description_index',''),
('14','description_list',''),
('14','description_show',''),
('14','description_search',''),
('14','module','video'),
('14','mobile','http://demo.destoon.com/v7.0/mobile/video/'),
('15','limit_6','30'),
('15','free_limit_5','0'),
('15','limit_5','3'),
('15','free_limit_4','0'),
('15','free_limit_7','-1'),
('15','limit_4','-1'),
('15','free_limit_3','0'),
('15','limit_3','-1'),
('15','free_limit_2','0'),
('15','limit_2','-1'),
('15','free_limit_1','-1'),
('15','limit_1','0'),
('15','credit_color','100'),
('15','credit_del','5'),
('15','credit_add','2'),
('15','fee_award','100'),
('15','fee_back','0'),
('15','fee_period','0'),
('15','fee_view','0'),
('15','fee_add','0'),
('15','fee_currency','money'),
('15','fee_mode','0'),
('15','question_add','2'),
('15','captcha_add','2'),
('15','check_add','2'),
('15','question_message','2'),
('15','captcha_message','2'),
('15','limit_7','100'),
('15','free_limit_6','0'),
('15','group_upload','6,7'),
('15','group_color','7'),
('15','group_search','3,5,6,7'),
('15','group_contact','5,6,7'),
('15','group_show','3,5,6,7'),
('15','group_list','3,5,6,7'),
('15','group_index','3,5,6,7'),
('15','seo_description_search',''),
('15','seo_keywords_search',''),
('15','seo_title_search',''),
('15','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('15','seo_description_show',''),
('15','seo_keywords_show',''),
('15','seo_keywords_list',''),
('15','seo_description_list',''),
('15','seo_keywords_index',''),
('15','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('15','seo_description_index',''),
('15','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('15','php_item_urlid','0'),
('15','htm_item_urlid','1'),
('15','htm_item_prefix',''),
('15','show_html','0'),
('15','php_list_urlid','0'),
('15','htm_list_urlid','0'),
('15','htm_list_prefix',''),
('15','list_html','0'),
('15','index_html','0'),
('15','page_comment','0'),
('15','hits','1'),
('15','max_width','550'),
('15','pagesize','20'),
('15','page_icat','10'),
('15','swfu','1'),
('15','page_irec','6'),
('15','upload','rar|zip|pdf|doc|jpg|gif|png|docx'),
('15','readsize','10'),
('15','level','推荐下载'),
('15','fulltext','0'),
('15','split','0'),
('15','keylink','0'),
('15','clear_link','0'),
('15','cat_property','0'),
('15','save_remotepic','0'),
('15','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,username,fileext,filesize,unit,download'),
('15','order','addtime desc'),
('15','editor','Destoon'),
('15','introduce_length','120'),
('15','thumb_height','180'),
('15','thumb_width','240'),
('15','template_my',''),
('15','template_search',''),
('15','template_show',''),
('15','template_list',''),
('15','template_index',''),
('15','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('15','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('15','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('15','title_search',''),
('15','keywords_index',''),
('15','keywords_list',''),
('15','keywords_show',''),
('15','keywords_search',''),
('15','description_index',''),
('15','description_list',''),
('15','description_show',''),
('15','description_search',''),
('15','module','down'),
('15','mobile','http://demo.destoon.com/v7.0/mobile/down/'),
('17','limit_7','100'),
('17','free_limit_7','-1'),
('17','free_limit_6','0'),
('17','free_limit_5','0'),
('17','limit_5','3'),
('17','free_limit_4','0'),
('17','limit_4','-1'),
('17','free_limit_3','0'),
('17','limit_3','-1'),
('17','free_limit_2','0'),
('17','limit_2','-1'),
('17','free_limit_1','-1'),
('17','limit_1','0'),
('17','credit_refresh','1'),
('17','credit_color','100'),
('17','credit_del','5'),
('17','credit_add','2'),
('17','fee_award','0'),
('17','fee_back','0'),
('17','fee_period','0'),
('17','fee_view','0'),
('17','fee_add','0'),
('17','fee_currency','money'),
('17','fee_mode','1'),
('17','question_add','2'),
('17','captcha_add','2'),
('17','check_add','2'),
('17','question_inquiry','2'),
('17','captcha_inquiry','2'),
('17','group_refresh','3,5,6,7'),
('17','group_color','7'),
('17','group_search','3,5,6,7'),
('17','group_contact','3,5,6,7'),
('17','group_show','3,5,6,7'),
('17','group_list','3,5,6,7'),
('17','group_index','3,5,6,7'),
('17','seo_description_search',''),
('17','seo_keywords_search',''),
('17','seo_title_search',''),
('17','seo_description_show',''),
('17','limit_6','30'),
('17','seo_keywords_show',''),
('17','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('17','seo_description_list',''),
('17','seo_keywords_list',''),
('17','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('17','seo_keywords_index',''),
('17','seo_description_index',''),
('17','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('17','php_item_urlid','0'),
('17','split','0'),
('17','fulltext','0'),
('17','level','推荐团购'),
('17','swfu','1'),
('17','page_subcat','9'),
('17','page_irec','4'),
('17','page_icat','4'),
('17','pagesize','9'),
('17','max_width','1000'),
('17','hits','1'),
('17','page_comment','0'),
('17','index_html','0'),
('17','list_html','0'),
('17','htm_list_prefix','group_list_'),
('17','htm_list_urlid','0'),
('17','php_list_urlid','0'),
('17','show_html','0'),
('17','htm_item_prefix','group_info_'),
('17','htm_item_urlid','1'),
('17','keylink','0'),
('17','clear_link','0'),
('17','save_remotepic','0'),
('17','cat_property','0'),
('17','fields','itemid,title,thumb,linkurl,style,catid,areaid,introduce,addtime,edittime,username,company,groupid,vip,qq,wx,ali,skype,validated,price,marketprice,savemoney,discount,sales,orders,minamount,amount'),
('17','order','addtime desc'),
('17','editor','Destoon'),
('17','introduce_length','120'),
('17','thumb_height','300'),
('17','thumb_width','400'),
('17','template_buy',''),
('17','template_my',''),
('17','template_search',''),
('17','template_list',''),
('17','template_show',''),
('17','template_index',''),
('17','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('17','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('17','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('17','title_search',''),
('17','keywords_index',''),
('17','keywords_list',''),
('17','keywords_show',''),
('17','keywords_search',''),
('17','description_index',''),
('17','description_list',''),
('17','description_show',''),
('17','description_search',''),
('17','module','group'),
('17','mobile','http://demo.destoon.com/v7.0/mobile/group/'),
('18','reply_limit_7','100'),
('18','join_limit_7','0'),
('18','group_limit_7','10'),
('18','free_limit_7','-1'),
('18','limit_7','100'),
('18','reply_limit_6','30'),
('18','join_limit_6','0'),
('18','group_limit_6','3'),
('18','limit_6','30'),
('18','free_limit_6','0'),
('18','reply_limit_5','10'),
('18','join_limit_5','0'),
('18','group_limit_5','1'),
('18','free_limit_5','0'),
('18','limit_5','3'),
('18','reply_limit_4','-1'),
('18','join_limit_4','-1'),
('18','group_limit_4','-1'),
('18','free_limit_4','0'),
('18','limit_4','-1'),
('18','reply_limit_3','-1'),
('18','join_limit_3','-1'),
('18','group_limit_3','-1'),
('18','free_limit_3','0'),
('18','limit_3','-1'),
('18','reply_limit_2','-1'),
('18','join_limit_2','-1'),
('18','group_limit_2','-1'),
('18','free_limit_2','0'),
('18','limit_2','-1'),
('18','reply_limit_1','0'),
('18','join_limit_1','0'),
('18','group_limit_1','0'),
('18','free_limit_1','-1'),
('18','limit_1','0'),
('18','credit_del_reply','2'),
('18','credit_reply','1'),
('18','credit_del','5'),
('18','credit_level','10'),
('18','credit_add','3'),
('18','pre_view','200'),
('18','fee_award','100'),
('18','fee_back','0'),
('18','fee_period','0'),
('18','fee_view','0'),
('18','fee_add','0'),
('18','fee_currency','money'),
('18','fee_mode','1'),
('18','question_reply','2'),
('18','captcha_reply','2'),
('18','check_reply','2'),
('18','question_add','2'),
('18','captcha_add','2'),
('18','check_add','2'),
('18','question_group','2'),
('18','captcha_group','2'),
('18','check_group','2'),
('18','group_reply','3,5,6,7'),
('18','group_search','3,5,6,7'),
('18','group_show','3,5,6,7'),
('18','group_list','3,5,6,7'),
('18','group_index','3,5,6,7'),
('18','seo_description_search',''),
('18','seo_keywords_search',''),
('18','seo_title_search',''),
('18','seo_description_show',''),
('18','seo_description_list',''),
('18','seo_title_show','{内容标题}{分隔符}{页码}{$GRP[\'title\']}{$MOD[\'seo_name\']}{分隔符}{模块名称}{分隔符}{网站名称}'),
('18','seo_keywords_show',''),
('18','seo_keywords_list',''),
('18','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('18','seo_keywords_index',''),
('18','seo_description_index',''),
('18','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('18','seo_name','圈'),
('18','php_item_urlid','0'),
('18','htm_item_urlid','4'),
('18','htm_item_prefix',''),
('18','show_html','0'),
('18','php_list_urlid','0'),
('18','htm_list_urlid','0'),
('18','htm_list_prefix',''),
('18','list_html','0'),
('18','index_html','0'),
('18','hits','1'),
('18','max_width','750'),
('18','reply_pagesize','10'),
('18','pagesize','20'),
('18','maxontop','5'),
('18','page_islide','3'),
('18','page_icat','6'),
('18','floor','沙发|藤椅|板凳|马扎|地板'),
('18','manage_reason','1'),
('18','manage_message','1'),
('18','manage_reasons','广告/SPAM|恶意灌水|违规内容|文不对题|重复发帖|我很赞同|精品文章|原创内容|感谢分享'),
('18','swfu','1'),
('18','level','精华1|精华2'),
('18','fulltext','0'),
('18','split','0'),
('18','keylink','1'),
('18','clear_alink','1'),
('18','clear_link','0'),
('18','cat_property','0'),
('18','save_remotepic','0'),
('18','fields','itemid,title,ontop,video,level,thumb,linkurl,style,catid,introduce,hits,addtime,edittime,username,passport,reply,replyer,replytime '),
('18','order','addtime desc'),
('18','editor','Destoon'),
('18','introduce_length','0'),
('18','thumb_height','180'),
('18','template_my_fans',''),
('18','template_my_manage',''),
('18','thumb_width','240'),
('18','template_my_join',''),
('18','template_my_reply',''),
('18','template_my_group',''),
('18','template_my',''),
('18','template_fans',''),
('18','template_group',''),
('18','template_search',''),
('18','template_show',''),
('18','template_list',''),
('18','template_index',''),
('18','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('18','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('18','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_page}{$GRP[\'title\']}{$MOD[\'seo_name\']}{$seo_delimiter}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('18','title_search',''),
('18','keywords_index',''),
('18','keywords_list',''),
('18','keywords_show',''),
('18','keywords_search',''),
('18','description_index',''),
('18','description_list',''),
('18','description_show',''),
('18','description_search',''),
('18','module','club'),
('18','mobile','http://demo.destoon.com/v7.0/mobile/club/'),
('21','free_limit_7','-1'),
('21','limit_7','100'),
('21','free_limit_6','0'),
('21','limit_6','30'),
('21','free_limit_5','0'),
('21','limit_5','3'),
('21','free_limit_4','0'),
('21','limit_4','-1'),
('21','free_limit_3','0'),
('21','limit_3','-1'),
('21','free_limit_2','0'),
('21','limit_2','-1'),
('21','free_limit_1','-1'),
('21','limit_1','0'),
('21','credit_color','100'),
('21','credit_del','5'),
('21','credit_add','2'),
('21','pre_view','200'),
('21','fee_award','100'),
('21','fee_back','0'),
('21','fee_period','0'),
('21','fee_view','0'),
('21','fee_add','0'),
('21','fee_currency','money'),
('21','fee_mode','0'),
('21','question_add','2'),
('21','captcha_add','2'),
('21','check_add','2'),
('21','group_color','7'),
('21','group_search','3,5,6,7'),
('21','group_show','3,5,6,7'),
('21','group_list','3,5,6,7'),
('21','group_index','3,5,6,7'),
('21','seo_description_search',''),
('21','seo_keywords_search',''),
('21','seo_title_search',''),
('21','seo_description_show',''),
('21','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('21','seo_keywords_show',''),
('21','seo_description_list',''),
('21','seo_keywords_list',''),
('21','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('21','seo_description_index',''),
('21','seo_keywords_index',''),
('21','php_item_urlid','0'),
('21','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('21','htm_item_urlid','1'),
('21','htm_item_prefix',''),
('21','show_html','0'),
('21','php_list_urlid','0'),
('21','htm_list_urlid','0'),
('21','htm_list_prefix',''),
('21','list_html','0'),
('21','index_html','0'),
('21','show_np','1'),
('21','page_comment','0'),
('21','hits','1'),
('21','max_width','800'),
('21','page_shits','10'),
('21','page_srec','10'),
('21','page_srecimg','4'),
('21','page_srelate','10'),
('21','page_lhits','10'),
('21','page_lrec','10'),
('21','page_lrecimg','4'),
('21','show_lcat','1'),
('21','page_child','6'),
('21','pagesize','20'),
('21','page_ihits','10'),
('21','page_irecimg','6'),
('21','show_icat','1'),
('21','page_icat','6'),
('21','page_islide','3'),
('21','swfu','2'),
('21','fulltext','1'),
('21','level','推荐文章|幻灯图片|推荐图文|头条相关|头条推荐'),
('21','split','0'),
('21','keylink','1'),
('21','clear_link','0'),
('21','save_remotepic','0'),
('21','cat_property','0'),
('21','order','addtime desc'),
('21','fields','itemid,title,thumb,linkurl,style,catid,introduce,addtime,edittime,username,islink,hits'),
('21','editor','Destoon'),
('21','introduce_length','120'),
('21','thumb_height','180'),
('21','thumb_width','240'),
('21','template_my',''),
('21','template_search',''),
('21','template_list',''),
('21','template_show',''),
('21','template_index',''),
('21','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('21','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('21','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('21','title_search',''),
('21','keywords_index',''),
('21','keywords_list',''),
('21','keywords_show',''),
('21','keywords_search',''),
('21','description_index',''),
('21','description_list',''),
('21','description_show',''),
('21','description_search',''),
('21','module','article'),
('21','mobile','http://demo.destoon.com/v7.0/mobile/news/'),
('22','free_limit_7','-1'),
('22','limit_7','100'),
('22','free_limit_6','0'),
('22','limit_6','30'),
('22','free_limit_5','0'),
('22','limit_5','3'),
('22','free_limit_4','0'),
('22','limit_4','-1'),
('22','free_limit_3','0'),
('22','limit_3','-1'),
('22','free_limit_2','0'),
('22','limit_2','-1'),
('22','free_limit_1','-1'),
('22','limit_1','0'),
('22','credit_refresh','1'),
('22','credit_color','100'),
('22','credit_del','5'),
('22','credit_add','2'),
('22','fee_award','0'),
('22','fee_back','0'),
('22','fee_period','0'),
('22','fee_view','0'),
('22','fee_add','0'),
('22','fee_currency','money'),
('22','check_add','2'),
('22','captcha_add','2'),
('22','question_add','2'),
('22','fee_mode','1'),
('22','question_message','2'),
('22','group_search','3,5,6,7'),
('22','group_color','7'),
('22','group_refresh','5,6,7'),
('22','captcha_message','2'),
('22','group_contact','6,7'),
('22','seo_title_search',''),
('22','seo_keywords_search',''),
('22','group_show','3,5,6,7'),
('22','group_list','3,5,6,7'),
('22','seo_description_search',''),
('22','group_index','3,5,6,7'),
('22','seo_keywords_list',''),
('22','seo_description_list',''),
('22','seo_title_show','{内容标题}{分隔符}{分类名称}{模块名称}{分隔符}{网站名称}'),
('22','seo_keywords_show',''),
('22','seo_description_show',''),
('22','seo_title_list','{分类SEO标题}{页码}{模块名称}{分隔符}{网站名称}'),
('22','seo_description_index',''),
('22','seo_keywords_index',''),
('22','seo_title_index','{模块名称}{分隔符}{页码}{网站名称}'),
('22','php_item_urlid','0'),
('22','htm_item_urlid','1'),
('22','htm_item_prefix',''),
('22','php_list_urlid','0'),
('22','show_html','0'),
('22','htm_list_urlid','0'),
('22','htm_list_prefix',''),
('22','list_html','0'),
('22','index_html','0'),
('22','page_comment','0'),
('22','hits','1'),
('22','max_width','1000'),
('22','page_srelate','10'),
('22','show_message','1'),
('22','page_lkw','10'),
('22','show_larea','1'),
('22','show_lcat','1'),
('22','pagesize','20'),
('22','page_ihits','9'),
('22','show_iarea','1'),
('22','show_icat','1'),
('22','page_icat','8'),
('22','page_irec','12'),
('22','page_subcat','5'),
('22','swfu','2'),
('22','level','推荐信息'),
('22','fulltext','0'),
('22','split','0'),
('22','message_ask','请问我这个地方有加盟商了吗？|我想加盟，请来电话告诉我具体细节。|初步打算加盟贵公司，请寄资料。|请问贵公司哪里有样板店或直营店？|想了解加盟细节，请尽快寄一份资料。 '),
('22','cat_property','0'),
('22','save_remotepic','0'),
('22','clear_link','0'),
('22','keylink','0'),
('22','fields','itemid,title,thumb,linkurl,style,catid,areaid,introduce,addtime,edittime,username,company,groupid,vip,qq,wx,ali,skype,validated,islink,hits'),
('22','order','edittime desc'),
('22','editor','Destoon'),
('22','introduce_length','120'),
('22','thumb_height','200'),
('22','template_message',''),
('22','thumb_width','200'),
('22','template_search',''),
('22','template_my',''),
('22','template_show',''),
('22','template_list',''),
('22','template_index',''),
('22','title_index','{$seo_modulename}{$seo_delimiter}{$seo_page}{$seo_sitename}'),
('22','title_list','{$seo_cattitle}{$seo_page}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('22','title_show','{$seo_showtitle}{$seo_delimiter}{$seo_catname}{$seo_modulename}{$seo_delimiter}{$seo_sitename}'),
('22','title_search',''),
('22','keywords_index',''),
('22','keywords_list',''),
('22','keywords_show',''),
('22','keywords_search',''),
('22','description_index',''),
('22','description_list',''),
('22','description_show',''),
('22','description_search',''),
('22','module','info'),
('22','mobile','http://demo.destoon.com/v7.0/mobile/invest/'),
('pay-alipay','percent','0'),
('pay-alipay','notify',''),
('pay-alipay','keycode',''),
('pay-alipay','partnerid',''),
('pay-alipay','email',''),
('pay-alipay','order','1'),
('pay-alipay','name','支付宝'),
('pay-alipay','enable','0'),
('pay-aliwap','percent','0'),
('pay-aliwap','notify',''),
('pay-aliwap','keycode',''),
('pay-aliwap','partnerid',''),
('pay-aliwap','order','2'),
('pay-aliwap','name','支付宝'),
('pay-aliwap','enable','0'),
('pay-weixin','percent','2'),
('pay-weixin','notify',''),
('pay-weixin','keycode',''),
('pay-weixin','appid',''),
('pay-weixin','partnerid',''),
('pay-weixin','order','3'),
('pay-weixin','name','微信支付'),
('pay-weixin','enable','0'),
('pay-tenpay','percent','0'),
('pay-tenpay','notify',''),
('pay-tenpay','keycode',''),
('pay-tenpay','partnerid',''),
('pay-tenpay','order','4'),
('pay-tenpay','name','财付通'),
('pay-tenpay','enable','0'),
('pay-upay','percent','0'),
('pay-upay','notify',''),
('pay-upay','keycode',''),
('pay-upay','cert',''),
('pay-upay','partnerid',''),
('pay-upay','order','5'),
('pay-upay','name','中国银联'),
('pay-upay','enable','0'),
('pay-chinabank','order','6'),
('pay-chinabank','partnerid',''),
('pay-chinabank','keycode',''),
('pay-chinabank','percent','0'),
('pay-chinabank','name','网银在线'),
('pay-chinabank','notify',''),
('pay-chinabank','enable','0'),
('pay-yeepay','percent','0'),
('pay-yeepay','keycode',''),
('pay-yeepay','partnerid',''),
('pay-yeepay','order','7'),
('pay-yeepay','name','易宝支付'),
('pay-yeepay','enable','0'),
('pay-kq99bill','percent','0'),
('pay-kq99bill','notify',''),
('pay-kq99bill','cert',''),
('pay-kq99bill','partnerid',''),
('pay-kq99bill','order','8'),
('pay-kq99bill','name','快钱支付'),
('pay-kq99bill','enable','0'),
('pay-chinapay','percent','1'),
('pay-chinapay','partnerid',''),
('pay-chinapay','order','9'),
('pay-chinapay','name','银联在线'),
('pay-chinapay','enable','0'),
('pay-paypal','percent','0'),
('pay-paypal','currency','USD'),
('pay-paypal','keycode',''),
('pay-paypal','notify',''),
('pay-paypal','partnerid',''),
('pay-paypal','order','10'),
('pay-paypal','name','贝宝'),
('pay-paypal','enable','0'),
('oauth-qq','sync','0'),
('oauth-qq','key',''),
('oauth-qq','id',''),
('oauth-qq','order','1'),
('oauth-qq','name','QQ登录'),
('oauth-qq','enable','0'),
('oauth-sina','sync','0'),
('oauth-sina','key',''),
('oauth-sina','id',''),
('oauth-sina','order','2'),
('oauth-sina','name','新浪微博'),
('oauth-sina','enable','0'),
('oauth-baidu','key',''),
('oauth-baidu','id',''),
('oauth-baidu','order','3'),
('oauth-baidu','name','百度'),
('oauth-baidu','enable','0'),
('oauth-netease','key',''),
('oauth-netease','id',''),
('oauth-netease','enable','0'),
('oauth-netease','order','4'),
('oauth-netease','name','网易通行证'),
('oauth-wechat','key',''),
('oauth-wechat','id',''),
('oauth-wechat','order','5'),
('oauth-wechat','name','微信'),
('oauth-wechat','enable','0'),
('oauth-taobao','id',''),
('oauth-taobao','order','6'),
('oauth-taobao','name','淘宝'),
('oauth-taobao','enable','0'),
('oauth-taobao','key',''),
('weixin','bind','点击可绑定会员帐号、查看会员信息、收发站内信件、管理我的订单等服务内容'),
('weixin','welcome','感谢您的关注，请点击菜单查看相应的服务'),
('weixin','auto',''),
('weixin','weixin',''),
('weixin','aeskey',''),
('weixin','apptoken',''),
('weixin','appsecret',''),
('weixin','appid',''),
('weixin','credit','10'),
('weixin-menu','menu','a:3:{i:0;a:6:{i:0;a:2:{s:4:"name";s:6:"最新";s:3:"key";s:0:"";}i:1;a:2:{s:4:"name";s:6:"资讯";s:3:"key";s:7:"V_mid21";}i:2;a:2:{s:4:"name";s:6:"供应";s:3:"key";s:6:"V_mid5";}i:3;a:2:{s:4:"name";s:6:"求购";s:3:"key";s:6:"V_mid6";}i:4;a:2:{s:4:"name";s:6:"商城";s:3:"key";s:7:"V_mid16";}i:5;a:2:{s:4:"name";s:6:"招商";s:3:"key";s:7:"V_mid22";}}i:1;a:6:{i:0;a:2:{s:4:"name";s:6:"会员";s:3:"key";s:8:"V_member";}i:1;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:2;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:3;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:4;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:5;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}}i:2;a:6:{i:0;a:2:{s:4:"name";s:6:"更多";s:3:"key";s:40:"http://qingchuangjie.gotoip2.com/mobile/";}i:1;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:2;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:3;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:4;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}i:5;a:2:{s:4:"name";s:0:"";s:3:"key";s:0:"";}}}'),
('group-1','listorder','1'),
('group-1','reg','0'),
('group-1','type','0'),
('group-1','edit_limit','0'),
('group-1','refresh_limit','0'),
('group-1','day_limit','0'),
('group-1','hour_limit','0'),
('group-1','add_limit','0'),
('group-1','copy','1'),
('group-1','delete','1'),
('group-1','vweixin','0'),
('group-1','vdeposit','0'),
('group-1','vcompany','0'),
('group-1','vtruename','0'),
('group-1','vmobile','0'),
('group-1','resume','1'),
('group-1','vemail','0'),
('group-1','moduleids','16,5,6,17,7,8,21,22,13,9,10,12,14,15,18'),
('group-1','link_limit','0'),
('group-1','honor_limit','0'),
('group-1','page_limit','0'),
('group-1','news_limit','0'),
('group-1','kf','1'),
('group-1','stats','1'),
('group-1','map','1'),
('group-1','style','0'),
('group-1','main_d','1,5'),
('group-1','main_c','1,5'),
('group-1','home_main','0'),
('group-1','side_d','0,3,6'),
('group-1','side_c','0,3,6'),
('group-1','home_side','0'),
('group-1','menu_d','0,6,7,11'),
('group-1','menu_c','0,6,7,11'),
('group-1','home_menu','0'),
('group-1','home','0'),
('group-1','styleid','0'),
('group-1','homepage','0'),
('group-1','type_limit','0'),
('group-1','price_limit','0'),
('group-1','inquiry_limit','0'),
('group-1','message_limit','0'),
('group-1','promo_limit','0'),
('group-1','express_limit','0'),
('group-1','address_limit','0'),
('group-1','alert_limit','0'),
('group-1','favorite_limit','0'),
('group-1','friend_limit','0'),
('group-1','inbox_limit','0'),
('group-1','chat','1'),
('group-1','ad','1'),
('group-1','spread','1'),
('group-1','sms','1'),
('group-1','sendmail','1'),
('group-1','trade_order','1'),
('group-1','group_order','1'),
('group-1','mail','1'),
('group-1','ask','1'),
('group-1','cash','1'),
('group-1','question','0'),
('group-1','captcha','0'),
('group-1','check','0'),
('group-1','uploadpt','0'),
('group-1','uploadcredit','0'),
('group-1','uploadday','0'),
('group-1','uploadlimit','0'),
('group-1','uploadsize','0'),
('group-1','uploadtype',''),
('group-1','upload','1'),
('group-1','editor','Destoon'),
('group-1','grade','0'),
('group-1','biz','1'),
('group-1','commission','0'),
('group-1','discount','100'),
('group-1','fee','0'),
('group-1','fee_mode','0'),
('group-2','listorder','2'),
('group-2','reg','0'),
('group-2','type','0'),
('group-2','vmobile','0'),
('group-2','edit_limit','-1'),
('group-2','refresh_limit','-1'),
('group-2','day_limit','-1'),
('group-2','hour_limit','-1'),
('group-2','add_limit','-1'),
('group-2','copy','0'),
('group-2','delete','0'),
('group-2','vweixin','0'),
('group-2','vdeposit','0'),
('group-2','vcompany','0'),
('group-2','vtruename','0'),
('group-2','vemail','0'),
('group-2','resume','0'),
('group-2','moduleids','6'),
('group-2','link_limit','-1'),
('group-2','honor_limit','-1'),
('group-2','page_limit','-1'),
('group-2','news_limit','-1'),
('group-2','kf','0'),
('group-2','stats','0'),
('group-2','map','0'),
('group-2','style','0'),
('group-2','main_d','5'),
('group-2','main_c','5'),
('group-2','home_main','0'),
('group-2','side_d','0'),
('group-2','side_c','0'),
('group-2','home_side','0'),
('group-2','menu_d','0'),
('group-2','menu_c','0'),
('group-2','home_menu','0'),
('group-2','home','0'),
('group-2','styleid','0'),
('group-2','homepage','0'),
('group-2','type_limit','-1'),
('group-2','price_limit','-1'),
('group-2','inquiry_limit','-1'),
('group-2','message_limit','-1'),
('group-2','promo_limit','-1'),
('group-2','express_limit','-1'),
('group-2','address_limit','-1'),
('group-2','alert_limit','-1'),
('group-2','favorite_limit','-1'),
('group-2','friend_limit','-1'),
('group-2','inbox_limit','-1'),
('group-2','chat','0'),
('group-2','ad','0'),
('group-2','group_order','0'),
('group-2','spread','0'),
('group-2','trade_order','0'),
('group-2','sendmail','0'),
('group-2','sms','0'),
('group-2','mail','0'),
('group-2','ask','0'),
('group-2','cash','0'),
('group-2','question','1'),
('group-2','captcha','1'),
('group-2','check','1'),
('group-2','uploadpt','1'),
('group-2','uploadcredit','10'),
('group-2','uploadday','10'),
('group-2','uploadlimit','2'),
('group-2','uploadsize','200'),
('group-2','uploadtype',''),
('group-2','upload','0'),
('group-2','editor','Basic'),
('group-2','grade','0'),
('group-2','biz','0'),
('group-2','commission','0'),
('group-2','discount','100'),
('group-2','fee','0'),
('group-2','fee_mode','0'),
('group-3','listorder','3'),
('group-3','reg','0'),
('group-3','type','0'),
('group-3','refresh_limit','-1'),
('group-3','day_limit','3'),
('group-3','edit_limit','-1'),
('group-3','hour_limit','1'),
('group-3','add_limit','30'),
('group-3','copy','0'),
('group-3','vweixin','0'),
('group-3','delete','0'),
('group-3','vdeposit','0'),
('group-3','vcompany','0'),
('group-3','vtruename','0'),
('group-3','vmobile','0'),
('group-3','vemail','0'),
('group-3','resume','0'),
('group-3','moduleids','5,6,8,22,9'),
('group-3','link_limit','-1'),
('group-3','honor_limit','-1'),
('group-3','page_limit','-1'),
('group-3','news_limit','-1'),
('group-3','kf','0'),
('group-3','stats','0'),
('group-3','map','0'),
('group-3','style','0'),
('group-3','main_d','5'),
('group-3','main_c','5'),
('group-3','home_main','0'),
('group-3','side_d','0'),
('group-3','side_c','0'),
('group-3','home_side','0'),
('group-3','menu_d','0'),
('group-3','menu_c','0'),
('group-3','home_menu','0'),
('group-3','home','0'),
('group-3','styleid','0'),
('group-3','homepage','0'),
('group-3','type_limit','-1'),
('group-3','price_limit','10'),
('group-3','inquiry_limit','30'),
('group-3','message_limit','30'),
('group-3','promo_limit','-1'),
('group-3','express_limit','-1'),
('group-3','address_limit','-1'),
('group-3','alert_limit','-1'),
('group-3','favorite_limit','-1'),
('group-3','friend_limit','-1'),
('group-3','inbox_limit','-1'),
('group-3','chat','1'),
('group-3','ad','0'),
('group-3','spread','0'),
('group-3','group_order','0'),
('group-3','trade_order','0'),
('group-3','sendmail','0'),
('group-3','sms','0'),
('group-3','mail','0'),
('group-3','ask','0'),
('group-3','cash','0'),
('group-3','question','1'),
('group-3','captcha','1'),
('group-3','check','1'),
('group-3','uploadpt','1'),
('group-3','uploadcredit','0'),
('group-3','uploadday','10'),
('group-3','uploadlimit','5'),
('group-3','uploadsize','500'),
('group-3','uploadtype',''),
('group-3','upload','0'),
('group-3','editor','Basic'),
('group-3','grade','0'),
('group-3','biz','0'),
('group-3','commission','0'),
('group-3','discount','100'),
('group-3','fee','0'),
('group-3','fee_mode','0'),
('group-4','listorder','4'),
('group-4','reg','0'),
('group-4','type','0'),
('group-4','edit_limit','-1'),
('group-4','refresh_limit','-1'),
('group-4','day_limit','-1'),
('group-4','hour_limit','-1'),
('group-4','add_limit','-1'),
('group-4','copy','0'),
('group-4','delete','0'),
('group-4','vweixin','0'),
('group-4','vdeposit','0'),
('group-4','vcompany','0'),
('group-4','vtruename','0'),
('group-4','vmobile','0'),
('group-4','vemail','0'),
('group-4','resume','0'),
('group-4','moduleids','6'),
('group-4','link_limit','-1'),
('group-4','honor_limit','-1'),
('group-4','page_limit','-1'),
('group-4','news_limit','-1'),
('group-4','kf','0'),
('group-4','stats','0'),
('group-4','map','0'),
('group-4','style','0'),
('group-4','main_c','5'),
('group-4','main_d','5'),
('group-4','home_main','0'),
('group-4','side_d','0'),
('group-4','menu_c','0'),
('group-4','menu_d','0'),
('group-4','side_c','0'),
('group-4','home_side','0'),
('group-4','home_menu','0'),
('group-4','home','0'),
('group-4','styleid','0'),
('group-4','homepage','0'),
('group-4','type_limit','-1'),
('group-4','price_limit','-1'),
('group-4','inquiry_limit','-1'),
('group-4','message_limit','-1'),
('group-4','promo_limit','-1'),
('group-4','express_limit','-1'),
('group-4','address_limit','-1'),
('group-4','alert_limit','-1'),
('group-4','favorite_limit','-1'),
('group-4','friend_limit','-1'),
('group-4','inbox_limit','-1'),
('group-4','trade_order','0'),
('group-4','group_order','0'),
('group-4','spread','0'),
('group-4','ad','0'),
('group-4','chat','1'),
('group-4','sendmail','0'),
('group-4','sms','0'),
('group-4','mail','0'),
('group-4','ask','0'),
('group-4','cash','0'),
('group-4','question','1'),
('group-4','captcha','1'),
('group-4','check','1'),
('group-4','uploadpt','1'),
('group-4','uploadcredit','5'),
('group-4','uploadday','10'),
('group-4','uploadlimit','5'),
('group-4','uploadsize','500'),
('group-4','uploadtype',''),
('group-4','upload','0'),
('group-4','editor','Basic'),
('group-4','grade','0'),
('group-4','biz','0'),
('group-4','commission','0'),
('group-4','discount','100'),
('group-4','fee','0'),
('group-4','fee_mode','0'),
('group-5','listorder','5'),
('group-5','reg','1'),
('group-5','type','0'),
('group-5','edit_limit','3'),
('group-5','day_limit','3'),
('group-5','refresh_limit','43200'),
('group-5','hour_limit','1'),
('group-5','add_limit','60'),
('group-5','copy','1'),
('group-5','delete','1'),
('group-5','vweixin','0'),
('group-5','vdeposit','0'),
('group-5','vcompany','0'),
('group-5','vtruename','0'),
('group-5','vmobile','0'),
('group-5','vemail','0'),
('group-5','resume','1'),
('group-5','moduleids','5,6,10,12,18'),
('group-5','link_limit','-1'),
('group-5','honor_limit','-1'),
('group-5','page_limit','-1'),
('group-5','news_limit','-1'),
('group-5','kf','0'),
('group-5','stats','0'),
('group-5','map','0'),
('group-5','style','0'),
('group-5','main_d','5'),
('group-5','main_c','5'),
('group-5','home_main','0'),
('group-5','side_d','0'),
('group-5','side_c','0'),
('group-5','home_side','0'),
('group-5','menu_d','0'),
('group-5','menu_c','0'),
('group-5','home_menu','0'),
('group-5','home','0'),
('group-5','styleid','0'),
('group-5','homepage','0'),
('group-5','type_limit','10'),
('group-5','price_limit','-1'),
('group-5','inquiry_limit','3'),
('group-5','message_limit','10'),
('group-5','promo_limit','-1'),
('group-5','express_limit','-1'),
('group-5','address_limit','10'),
('group-5','alert_limit','3'),
('group-5','favorite_limit','20'),
('group-5','friend_limit','10'),
('group-5','inbox_limit','20'),
('group-5','chat','1'),
('group-5','ad','1'),
('group-5','spread','0'),
('group-5','group_order','0'),
('group-5','trade_order','0'),
('group-5','sendmail','1'),
('group-5','sms','1'),
('group-5','mail','1'),
('group-5','ask','0'),
('group-5','cash','0'),
('group-5','question','1'),
('group-5','captcha','1'),
('group-5','check','1'),
('group-5','uploadpt','1'),
('group-5','uploadcredit','1'),
('group-5','uploadday','20'),
('group-5','uploadlimit','5'),
('group-5','uploadsize',''),
('group-5','uploadtype',''),
('group-5','upload','1'),
('group-5','editor','Simple'),
('group-5','grade','1'),
('group-5','biz','0'),
('group-5','commission','0'),
('group-5','discount','100'),
('group-5','fee','0'),
('group-5','fee_mode','0'),
('group-6','listorder','6'),
('group-6','reg','1'),
('group-6','type','1'),
('group-6','day_limit','5'),
('group-6','refresh_limit','21600'),
('group-6','edit_limit','0'),
('group-6','hour_limit','2'),
('group-6','add_limit','60'),
('group-6','copy','1'),
('group-6','delete','1'),
('group-6','vweixin','0'),
('group-6','vtruename','0'),
('group-6','vcompany','0'),
('group-6','vdeposit','0'),
('group-6','vmobile','0'),
('group-6','vemail','0'),
('group-6','resume','0'),
('group-6','moduleids','16,5,6,17,7,8,22,13,9,10,12'),
('group-6','link_limit','20'),
('group-6','honor_limit','10'),
('group-6','page_limit','5'),
('group-6','news_limit','20'),
('group-6','kf','0'),
('group-6','map','1'),
('group-6','stats','0'),
('group-6','style','0'),
('group-6','main_d','0,1,2'),
('group-6','main_c','0,1,2,3,4,5,6'),
('group-6','home_main','0'),
('group-6','side_c','0,1,2,3,4,5,6'),
('group-6','side_d','0,2,4,6'),
('group-6','home_menu','0'),
('group-6','menu_c','0,1,2,3,4,5,6,7,8,9,10,11'),
('group-6','menu_d','0,1,2,3,4,6,7'),
('group-6','home_side','0'),
('group-6','home','0'),
('group-6','styleid','0'),
('group-6','type_limit','10'),
('group-6','homepage','1'),
('group-6','price_limit','3'),
('group-6','inquiry_limit','10'),
('group-6','message_limit','20'),
('group-6','promo_limit','3'),
('group-6','express_limit','5'),
('group-6','address_limit','10'),
('group-6','alert_limit','5'),
('group-6','favorite_limit','50'),
('group-6','friend_limit','50'),
('group-6','inbox_limit','50'),
('group-6','group_order','1'),
('group-6','spread','0'),
('group-6','ad','1'),
('group-6','chat','1'),
('group-6','trade_order','1'),
('group-6','sendmail','1'),
('group-6','sms','1'),
('group-6','mail','1'),
('group-6','ask','1'),
('group-6','cash','0'),
('group-6','question','1'),
('group-6','captcha','1'),
('group-6','check','1'),
('group-6','uploadday','50'),
('group-6','uploadcredit','2'),
('group-6','uploadpt','0'),
('group-6','uploadlimit','5'),
('group-6','uploadsize',''),
('group-6','uploadtype',''),
('group-6','editor','Destoon'),
('group-6','upload','1'),
('group-6','grade','1'),
('group-6','biz','1'),
('group-6','commission','0'),
('group-6','discount','100'),
('group-6','fee','0'),
('group-6','fee_mode','0'),
('group-7','listorder','7'),
('group-7','reg','0'),
('group-7','type','1'),
('group-7','edit_limit','0'),
('group-7','refresh_limit','3600'),
('group-7','day_limit','10'),
('group-7','hour_limit','5'),
('group-7','add_limit','0'),
('group-7','copy','1'),
('group-7','delete','1'),
('group-7','vweixin','0'),
('group-7','vdeposit','0'),
('group-7','vcompany','0'),
('group-7','vtruename','0'),
('group-7','vmobile','0'),
('group-7','resume','0'),
('group-7','vemail','1'),
('group-7','moduleids','16,5,6,17,7,8,21,22,13,9,10,12,14,15,18'),
('group-7','link_limit','0'),
('group-7','kf','1'),
('group-7','news_limit','0'),
('group-7','page_limit','10'),
('group-7','honor_limit','0'),
('group-7','stats','1'),
('group-7','map','1'),
('group-7','style','1'),
('group-7','main_d','0,1,2,7'),
('group-7','main_c','0,1,2,4,5,6,7'),
('group-7','home_main','1'),
('group-7','side_c','0,1,2,3,4,5,6'),
('group-7','side_d','0,1,2,4,6'),
('group-7','home_side','1'),
('group-7','menu_d','0,1,2,3,4,5,6,7,8,9,10,11,12,13'),
('group-7','home','1'),
('group-7','home_menu','1'),
('group-7','menu_c','0,1,2,3,4,5,6,7,8,9,10,11,12,13'),
('group-7','styleid','2'),
('group-7','homepage','1'),
('group-7','type_limit','20'),
('group-7','price_limit','20'),
('group-7','inquiry_limit','50'),
('group-7','message_limit','100'),
('group-7','promo_limit','5'),
('group-7','express_limit','10'),
('group-7','address_limit','10'),
('group-7','alert_limit','10'),
('group-7','favorite_limit','100'),
('group-7','friend_limit','200'),
('group-7','inbox_limit','500'),
('group-7','chat','1'),
('group-7','ad','1'),
('group-7','spread','1'),
('group-7','group_order','1'),
('group-7','trade_order','1'),
('group-7','sendmail','1'),
('group-7','sms','1'),
('group-7','mail','1'),
('group-7','ask','1'),
('group-7','cash','1'),
('group-7','question','0'),
('group-7','captcha','0'),
('group-7','check','0'),
('group-7','uploadpt','0'),
('group-7','uploadcredit','0'),
('group-7','uploadday','100'),
('group-7','uploadlimit','10'),
('group-7','uploadsize',''),
('group-7','uploadtype',''),
('group-7','upload','1'),
('group-7','editor','Destoon'),
('group-7','grade','1'),
('group-7','biz','1'),
('group-7','commission','0'),
('group-7','discount',''),
('group-7','fee','2000'),
('group-7','fee_mode','1'),
('destoon','backtime','1569851008'),
('1','bmp_jpg','1'),
('1','water_pos','9'),
('1','water_min_wh','180'),
('1','water_margin','10'),
('1','water_type','2'),
('1','file_my','my.php'),
('1','file_login','login.php'),
('1','file_register','register.php'),
('1','defend_proxy','0'),
('1','defend_reload','0'),
('1','defend_cc','0'),
('1','safe_domain',''),
('1','check_referer','1'),
('1','uploaddir','Ym/d'),
('1','uploadsize','20480'),
('1','uploadtype','jpg|jpeg|png|gif|bmp|mp4|flv|rar|zip|pdf|doc|docx|xls|xlsx|ppt|ppts'),
('1','uploadlog','1'),
('1','anticopy','0'),
('1','ip_login','0'),
('1','login_log','0'),
('1','admin_log','1'),
('1','admin_online','1'),
('1','md5_pass','1'),
('1','captcha_admin','0'),
('1','captcha_cn','0'),
('1','captcha_chars',''),
('1','check_hour',''),
('1','admin_hour',''),
('1','admin_ip',''),
('1','admin_area',''),
('1','remote_url',''),
('1','ftp_path',''),
('1','ftp_save','0'),
('1','ftp_pasv','1'),
('1','ftp_ssl','0'),
('1','ftp_pass',''),
('1','ftp_user',''),
('1','ftp_port','21'),
('1','ftp_host',''),
('1','ftp_remote','0'),
('1','max_len','50000'),
('1','schcate_limit','10'),
('1','pushtime','10'),
('1','pagesize','20'),
('1','online','1200'),
('1','search_limit','1'),
('1','max_kw','32'),
('1','min_kw','3'),
('1','search_check_kw','0'),
('1','search_kw','1'),
('1','save_draft','0'),
('1','search_tips','1'),
('1','anti_spam','1'),
('1','log_credit','1'),
('1','pages_mode','0'),
('1','gzip_enable','0'),
('1','lazy','0'),
('1','cache_hits','0'),
('1','cache_search','0'),
('1','task_item','86400'),
('1','task_list','1800'),
('1','pcharset','0'),
('1','log_404','0'),
('1','task_index','600'),
('1','search_rewrite','0'),
('1','com_https','0'),
('1','com_www','0'),
('1','index','index'),
('1','file_ext','html'),
('1','index_html','0'),
('1','rewrite','0'),
('1','seo_description','萌瓜医疗信息网'),
('1','seo_keywords','萌瓜医疗信息网'),
('1','seo_title','萌瓜医疗信息网'),
('1','seo_delimiter','_'),
('1','im_skype','0'),
('1','im_ali','1'),
('1','im_wx','1'),
('1','im_qq','1'),
('1','im_web','1'),
('1','admin_left','218'),
('1','max_cart','50'),
('1','quick_pay','200'),
('1','credit_unit','点'),
('1','credit_name','积分'),
('1','money_sign','￥'),
('1','money_unit','元'),
('1','money_name','资金'),
('1','city_ip','1'),
('1','city','1'),
('1','close_reason','网站维护中，请稍候访问...'),
('1','close','0'),
('1','icpno',''),
('1','telephone',''),
('1','copyright','(c)2008-2019 萌瓜医疗信息网 All Rights Reserved'),
('1','logo','/file/upload/201910/01/215051881.jpg'),
('1','sitename','萌瓜医疗信息网'),
('1','message_weixin','1'),
('1','page_mall','10'),
('1','page_sell','10'),
('1','page_info','10'),
('1','page_group','10'),
('1','page_newst','1'),
('1','page_newsh','1'),
('1','page_news','6'),
('1','page_special','1'),
('1','page_video','3'),
('1','page_photo','3'),
('1','page_brand','16'),
('1','page_exhibit','6'),
('1','page_job','5'),
('1','page_know','6'),
('1','page_down','3'),
('1','page_club','8'),
('1','page_logo','18'),
('1','page_text','18'),
('1','sms','0'),
('1','sms_fee','0.1'),
('1','sms_max','5'),
('1','sms_len','70'),
('1','sms_ok','成功'),
('1','sms_sign',''),
('1','cloud_express','0'),
('1','trade_pw',''),
('1','admin_week',''),
('1','check_week','');
DROP TABLE IF EXISTS  `destoon_sms`;
CREATE TABLE `destoon_sms` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `word` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `sendtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `code` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='短信记录';

DROP TABLE IF EXISTS  `destoon_special_11`;
CREATE TABLE `destoon_special_11` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `tag` varchar(100) NOT NULL DEFAULT '',
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `banner` varchar(255) NOT NULL DEFAULT '',
  `cfg_photo` smallint(4) unsigned NOT NULL DEFAULT '0',
  `cfg_video` smallint(4) unsigned NOT NULL DEFAULT '0',
  `cfg_type` smallint(4) unsigned NOT NULL DEFAULT '0',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `template_type` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `domain` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='专题';

DROP TABLE IF EXISTS  `destoon_special_data_11`;
CREATE TABLE `destoon_special_data_11` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` longtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='专题内容';

DROP TABLE IF EXISTS  `destoon_special_item_11`;
CREATE TABLE `destoon_special_item_11` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `specialid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `addtime` (`addtime`),
  KEY `specialid` (`specialid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='专题信息';

DROP TABLE IF EXISTS  `destoon_sphinx`;
CREATE TABLE `destoon_sphinx` (
  `moduleid` int(10) unsigned NOT NULL DEFAULT '0',
  `maxid` bigint(20) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `moduleid` (`moduleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Sphinx';

DROP TABLE IF EXISTS  `destoon_spread`;
CREATE TABLE `destoon_spread` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `tid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `word` varchar(50) NOT NULL DEFAULT '',
  `price` float NOT NULL DEFAULT '0',
  `currency` varchar(30) NOT NULL DEFAULT '',
  `company` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='排名推广';

DROP TABLE IF EXISTS  `destoon_spread_price`;
CREATE TABLE `destoon_spread_price` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `word` varchar(50) NOT NULL DEFAULT '',
  `price` float NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='排名起价';

DROP TABLE IF EXISTS  `destoon_style`;
CREATE TABLE `destoon_style` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `skin` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(50) NOT NULL DEFAULT '',
  `author` varchar(30) NOT NULL DEFAULT '',
  `groupid` varchar(30) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `currency` varchar(20) NOT NULL DEFAULT '',
  `money` float NOT NULL DEFAULT '0',
  `credit` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='公司主页模板';

insert into `destoon_style`(`itemid`,`typeid`,`title`,`skin`,`template`,`author`,`groupid`,`fee`,`currency`,`money`,`credit`,`hits`,`addtime`,`editor`,`edittime`,`listorder`) values
('1','0','默认模板','default','homepage','DESTOON.COM',',6,7,','0','money','0','0','0','1569851008','admin','1569851008','0'),
('2','0','深蓝模板','blue','homepage','DESTOON.COM',',6,7,','0','money','0','0','0','1569851008','admin','1569851008','0'),
('3','0','绿色模板','green','homepage','DESTOON.COM',',6,7,','0','money','0','0','0','1569851008','admin','1569851008','0'),
('4','0','紫色模板','purple','homepage','DESTOON.COM',',6,7,','0','money','0','0','0','1569851008','admin','1569851008','0'),
('5','0','橙色模板','orange','homepage','DESTOON.COM',',6,7,','0','money','0','0','0','1569851008','admin','1569851008','0');
DROP TABLE IF EXISTS  `destoon_type`;
CREATE TABLE `destoon_type` (
  `typeid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) NOT NULL DEFAULT '0',
  `typename` varchar(255) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `item` varchar(20) NOT NULL DEFAULT '',
  `cache` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`typeid`),
  KEY `listorder` (`listorder`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='分类';

DROP TABLE IF EXISTS  `destoon_upgrade`;
CREATE TABLE `destoon_upgrade` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `gid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `groupid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `amount` float NOT NULL DEFAULT '0',
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `company` varchar(100) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `reason` text NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员升级';

DROP TABLE IF EXISTS  `destoon_upload_0`;
CREATE TABLE `destoon_upload_0` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录0';

DROP TABLE IF EXISTS  `destoon_upload_1`;
CREATE TABLE `destoon_upload_1` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='上传记录1';

insert into `destoon_upload_1`(`pid`,`item`,`tb`,`moduleid`,`itemid`,`fileurl`,`filesize`,`fileext`,`upfrom`,`width`,`height`,`addtime`,`username`,`ip`) values
('1','a8426ccd540dfde98a538a4ca7fd9125','setting','1','1','http://qingchuangjie.gotoip2.com/file/upload/201910/01/215051881.jpg','32084','jpg','thumb','180','60','1569937851','admin','182.148.91.176'),
('3','d8cebe0304afeba45f73e8a04ea3ed32','','8','5','http://qingchuangjie.gotoip2.com/file/upload/201910/01/225343331.jpg','19236','jpg','thumb','300','225','1569941623','admin','182.148.91.176'),
('4','07bb4d2a11a9f15060fe4d304e56a181','','22','6','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000205661.jpg.thumb.jpg','37797','jpg','album','259','350','1569945725','admin','182.148.91.176'),
('5','8a127d0e0db0e9aa8a01e4bd445f3bdc','','22','7','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000333931.jpg.thumb.jpg','47877','jpg','album','350','274','1569945813','admin','182.148.91.176'),
('6','15cb851d1e56db52526177a5eec0336c','','22','8','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000408751.jpg.thumb.jpg','69666','jpg','album','347','350','1569945848','admin','182.148.91.176'),
('7','939d9663bdc09bf6fb795a814ef73f63','','22','9','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000449871.jpg.thumb.jpg','35428','jpg','album','228','350','1569945889','admin','182.148.91.176'),
('8','0fdd8b58165178e553d12a998415748a','','22','10','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000523181.jpg.thumb.jpg','68140','jpg','album','350','224','1569945923','admin','182.148.91.176'),
('9','845737682c7f4fd14f9ee0d779d4e1b6','','22','12','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000744961.jpg.thumb.jpg','14554','jpg','album','332','228','1569946064','admin','182.148.91.176'),
('10','145f78cccef0ba38bcad2665fecb691c','','22','13','http://qingchuangjie.gotoip2.com/file/upload/201910/02/000917581.jpg.thumb.jpg','26944','jpg','album','344','314','1569946157','admin','182.148.91.176'),
('11','924a7486bb6d60cd201295835344e674','','22','14','http://qingchuangjie.gotoip2.com/file/upload/201910/02/001022791.jpg.thumb.jpg','82319','jpg','album','350','350','1569946222','admin','182.148.91.176'),
('12','69b9ae56dbb50dc703b32b4f2c99a6b5','','22','15','http://qingchuangjie.gotoip2.com/file/upload/201910/02/001204901.jpg.thumb.jpg','74514','jpg','album','350','347','1569946324','admin','182.148.91.176'),
('13','17f80024fda485585a58585e5290563c','','22','16','http://qingchuangjie.gotoip2.com/file/upload/201910/02/001241731.jpg.thumb.jpg','31832','jpg','album','214','350','1569946361','admin','182.148.91.176'),
('14','52ed1b5dd4e9d29940f531fa8ec86791','','6','1','http://qingchuangjie.gotoip2.com/file/upload/201910/02/003526681.jpg.thumb.jpg','44154','jpg','album','350','236','1569947726','admin','182.148.91.176'),
('15','1aea49dbb686b26fd8c5f785a2a732eb','','6','2','http://qingchuangjie.gotoip2.com/file/upload/201910/02/003623291.jpg.thumb.jpg','50746','jpg','album','350','330','1569947783','admin','182.148.91.176'),
('16','99b8a208072ebe0b353311c4dbd1a5e6','','6','3','http://qingchuangjie.gotoip2.com/file/upload/201910/02/003704661.jpg.thumb.jpg','70543','jpg','album','350','350','1569947824','admin','182.148.91.176'),
('17','0ca732e7ccbfecbbc9747caabbc136f2','','6','4','http://qingchuangjie.gotoip2.com/file/upload/201910/02/003740631.jpg.thumb.jpg','52431','jpg','album','292','350','1569947860','admin','182.148.91.176'),
('18','442ccc6aa50a64794986bc7f9b2610d3','','6','5','http://cgylxx.cdbtdl.cn/file/upload/201910/10/111859111.jpg.thumb.jpg','12899','jpg','album','300','250','1570677539','admin','182.151.233.54'),
('19','c14c494e4c808b021a10a7b7897d949d','','6','0','http://cgylxx.cdbtdl.cn/file/upload/201910/10/111948821.jpg.thumb.jpg','12688','jpg','album','400','300','1570677588','admin','182.151.233.54'),
('20','426a6b4ace8702ab5da9c706e1b48711','','6','6','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112017511.jpg.thumb.jpg','12688','jpg','album','400','300','1570677617','admin','182.151.233.54'),
('21','6829efe43aac0b78a55d955a6e18de3d','','6','7','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112112581.jpg.thumb.jpg','12899','jpg','album','300','250','1570677672','admin','182.151.233.54'),
('22','7cbdd1db3ee7bc07ec7f350c0d5abe88','','6','8','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112231111.jpg.thumb.jpg','15106','jpg','album','400','300','1570677751','admin','182.151.233.54'),
('23','adad776c76685f992f06ed3e670d8a20','','6','9','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112346861.jpg.thumb.jpg','22327','jpg','album','400','300','1570677826','admin','182.151.233.54'),
('24','b6022a2e8cdffe9558556e3920a5ec8d','','6','10','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112424351.jpg.thumb.jpg','20823','jpg','album','400','300','1570677864','admin','182.151.233.54'),
('25','ab48403c87e463dec01df38e946da2c4','','6','11','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112523591.jpg.thumb.jpg','19539','jpg','album','400','300','1570677923','admin','182.151.233.54'),
('26','28d09308aa69cb219389690c8e0c7a27','','6','12','http://cgylxx.cdbtdl.cn/file/upload/201910/10/112836831.jpg.thumb.jpg','19140','jpg','album','400','300','1570678116','admin','182.151.233.54'),
('29','f083330bb2db4a7c953bd8da4f3f0d09','','6','14','http://solotioncomcn.gotoip1.com/file/upload/202006/13/234012781.gif.thumb.gif','43915','gif','album','600','450','1592062812','admin','223.198.226.112'),
('28','09437dbd53293325487a5ec6bd42fb8d','','6','13','http://solotioncomcn.gotoip1.com/file/upload/202006/13/233906921.gif.thumb.gif','73920','gif','album','600','450','1592062746','admin','223.198.226.112'),
('30','72f7ff8b578265d6f96d642b3e735fb9','','6','16','http://solotioncomcn.gotoip1.com/file/upload/202006/13/234249771.jpg.thumb.jpg','84711','jpg','album','500','420','1592062969','admin','223.198.226.112');
DROP TABLE IF EXISTS  `destoon_upload_2`;
CREATE TABLE `destoon_upload_2` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录2';

DROP TABLE IF EXISTS  `destoon_upload_3`;
CREATE TABLE `destoon_upload_3` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录3';

DROP TABLE IF EXISTS  `destoon_upload_4`;
CREATE TABLE `destoon_upload_4` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录4';

DROP TABLE IF EXISTS  `destoon_upload_5`;
CREATE TABLE `destoon_upload_5` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录5';

DROP TABLE IF EXISTS  `destoon_upload_6`;
CREATE TABLE `destoon_upload_6` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录6';

DROP TABLE IF EXISTS  `destoon_upload_7`;
CREATE TABLE `destoon_upload_7` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录7';

DROP TABLE IF EXISTS  `destoon_upload_8`;
CREATE TABLE `destoon_upload_8` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录8';

DROP TABLE IF EXISTS  `destoon_upload_9`;
CREATE TABLE `destoon_upload_9` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(32) NOT NULL DEFAULT '',
  `tb` varchar(30) NOT NULL,
  `moduleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `fileurl` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` varchar(10) NOT NULL DEFAULT '',
  `upfrom` varchar(10) NOT NULL DEFAULT '',
  `width` int(10) unsigned NOT NULL DEFAULT '0',
  `height` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  KEY `item` (`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='上传记录9';

DROP TABLE IF EXISTS  `destoon_validate`;
CREATE TABLE `destoon_validate` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL DEFAULT '',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `thumb1` varchar(255) NOT NULL DEFAULT '',
  `thumb2` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='资料认证';

DROP TABLE IF EXISTS  `destoon_video_14`;
CREATE TABLE `destoon_video_14` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `fee` float NOT NULL DEFAULT '0',
  `tag` varchar(255) NOT NULL DEFAULT '',
  `album` varchar(100) NOT NULL,
  `keyword` varchar(255) NOT NULL DEFAULT '',
  `pptword` varchar(255) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(255) NOT NULL DEFAULT '',
  `video` varchar(255) NOT NULL DEFAULT '',
  `mobile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `introduce` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`),
  KEY `username` (`username`),
  KEY `addtime` (`addtime`),
  KEY `catid` (`catid`),
  KEY `album` (`album`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='视频';

DROP TABLE IF EXISTS  `destoon_video_data_14`;
CREATE TABLE `destoon_video_data_14` (
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='视频内容';

DROP TABLE IF EXISTS  `destoon_vote`;
CREATE TABLE `destoon_vote` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `groupid` varchar(255) NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `choose` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vote_min` smallint(2) unsigned NOT NULL DEFAULT '0',
  `vote_max` smallint(2) unsigned NOT NULL DEFAULT '0',
  `votes` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromtime` int(10) unsigned NOT NULL DEFAULT '0',
  `totime` int(10) unsigned NOT NULL DEFAULT '0',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `linkto` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `template_vote` varchar(30) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '',
  `s1` varchar(255) NOT NULL DEFAULT '',
  `s2` varchar(255) NOT NULL DEFAULT '',
  `s3` varchar(255) NOT NULL DEFAULT '',
  `s4` varchar(255) NOT NULL DEFAULT '',
  `s5` varchar(255) NOT NULL DEFAULT '',
  `s6` varchar(255) NOT NULL DEFAULT '',
  `s7` varchar(255) NOT NULL DEFAULT '',
  `s8` varchar(255) NOT NULL DEFAULT '',
  `s9` varchar(255) NOT NULL DEFAULT '',
  `s10` varchar(255) NOT NULL DEFAULT '',
  `v1` int(10) unsigned NOT NULL DEFAULT '0',
  `v2` int(10) unsigned NOT NULL DEFAULT '0',
  `v3` int(10) unsigned NOT NULL DEFAULT '0',
  `v4` int(10) unsigned NOT NULL DEFAULT '0',
  `v5` int(10) unsigned NOT NULL DEFAULT '0',
  `v6` int(10) unsigned NOT NULL DEFAULT '0',
  `v7` int(10) unsigned NOT NULL DEFAULT '0',
  `v8` int(10) unsigned NOT NULL DEFAULT '0',
  `v9` int(10) unsigned NOT NULL DEFAULT '0',
  `v10` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='投票';

DROP TABLE IF EXISTS  `destoon_vote_record`;
CREATE TABLE `destoon_vote_record` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) NOT NULL DEFAULT '',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `votetime` int(10) unsigned NOT NULL DEFAULT '0',
  `votes` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`rid`),
  KEY `itemid` (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='投票记录';

DROP TABLE IF EXISTS  `destoon_webpage`;
CREATE TABLE `destoon_webpage` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(30) NOT NULL DEFAULT '',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `style` varchar(50) NOT NULL DEFAULT '',
  `content` mediumtext NOT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_keywords` varchar(255) NOT NULL DEFAULT '',
  `seo_description` varchar(255) NOT NULL DEFAULT '',
  `editor` varchar(30) NOT NULL DEFAULT '',
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(4) NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `domain` varchar(255) NOT NULL DEFAULT '',
  `template` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='单网页';

insert into `destoon_webpage`(`itemid`,`item`,`areaid`,`level`,`title`,`style`,`content`,`seo_title`,`seo_keywords`,`seo_description`,`editor`,`edittime`,`listorder`,`hits`,`islink`,`linkurl`,`domain`,`template`) values
('1','1','0','0','关于我们','','关于我们','','','','destoon','1319006891','5','0','0','about/index.html','',''),
('2','1','0','0','联系方式','','联系方式','','','','destoon','1310696453','4','1','0','about/contact.html','',''),
('3','1','0','0','使用协议','','使用协议','','','','destoon','1310696460','3','0','0','about/agreement.html','',''),
('4','1','0','0','版权隐私','','版权隐私','','','','destoon','1310696468','2','0','0','about/copyright.html','','');
DROP TABLE IF EXISTS  `destoon_weixin_auto`;
CREATE TABLE `destoon_weixin_auto` (
  `itemid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) NOT NULL,
  `reply` text NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `keyword` (`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='微信回复';

DROP TABLE IF EXISTS  `destoon_weixin_bind`;
CREATE TABLE `destoon_weixin_bind` (
  `username` varchar(30) NOT NULL DEFAULT '',
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='微信扫码绑定';

DROP TABLE IF EXISTS  `destoon_weixin_chat`;
CREATE TABLE `destoon_weixin_chat` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `editor` varchar(30) NOT NULL,
  `openid` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL,
  `event` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `misc` mediumtext NOT NULL,
  PRIMARY KEY (`itemid`),
  KEY `openid` (`openid`),
  KEY `addtime` (`addtime`),
  KEY `event` (`event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='微信消息';

DROP TABLE IF EXISTS  `destoon_weixin_user`;
CREATE TABLE `destoon_weixin_user` (
  `itemid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `nickname` varchar(255) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `headimgurl` varchar(255) NOT NULL,
  `edittime` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `visittime` int(10) unsigned NOT NULL DEFAULT '0',
  `credittime` int(10) unsigned NOT NULL DEFAULT '0',
  `subscribe` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `push` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`itemid`),
  UNIQUE KEY `openid` (`openid`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='微信用户';

SET FOREIGN_KEY_CHECKS = 1;

